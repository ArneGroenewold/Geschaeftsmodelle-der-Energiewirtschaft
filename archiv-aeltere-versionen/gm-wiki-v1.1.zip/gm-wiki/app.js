// ============================================================
// ENERGIEWIRTSCHAFT GESCHÄFTSMODELL-WIKI  v1.1
// app.js — Navigation, Rendering, Radar, Matrix, Akteure
// ============================================================
(function () {
  'use strict';

  // ── State ──────────────────────────────────────────────
  let currentView     = 'hero';
  let currentDomainId = null;
  let currentCapId    = null;
  let currentTab      = 'wiki';
  let searchTimeout   = null;

  // ── DOM refs ───────────────────────────────────────────
  const sidebarNav     = document.getElementById('sidebarNav');
  const hero           = document.getElementById('hero');
  const domainView     = document.getElementById('domainView');
  const detailView     = document.getElementById('detailView');
  const domainHeader   = document.getElementById('domainHeader');
  const capabilityGrid = document.getElementById('capabilityGrid');
  const detailContent  = document.getElementById('detailContent');
  const backBtn        = document.getElementById('backBtn');
  const searchInput    = document.getElementById('searchInput');
  const heroStats      = document.getElementById('heroStats');
  const versionTag     = document.getElementById('versionTag');
  const mobileToggle   = document.getElementById('mobileToggle');
  const sidebar        = document.getElementById('sidebar');
  const main           = document.getElementById('main');
  const matrixView     = document.getElementById('matrixView');
  const akteureView    = document.getElementById('akteureView');
  const tabBtns        = document.querySelectorAll('.tab-btn');

  // ── Init ───────────────────────────────────────────────
  function init() {
    versionTag.textContent = GM_WIKI_VERSION;
    renderHeroStats();
    buildSidebarNav();
    bindEvents();
    renderMatrix();
    renderAkteure();
  }

  // ── Hero Stats ─────────────────────────────────────────
  function renderHeroStats() {
    let totalCaps = 0, totalItems = 0;
    GM_DATA.forEach(d => {
      totalCaps += d.capabilities.length;
      d.capabilities.forEach(c => { totalItems += c.items.length; });
    });
    heroStats.innerHTML = `
      <div class="stat-item">
        <span class="stat-number">${GM_DATA.length}</span>
        <span class="stat-label">Wertschöpfungsstufen</span>
      </div>
      <div class="stat-item">
        <span class="stat-number">${totalCaps}</span>
        <span class="stat-label">Capability-Gruppen</span>
      </div>
      <div class="stat-item">
        <span class="stat-number">${totalItems}</span>
        <span class="stat-label">Geschäftsmodelle</span>
      </div>
      <div class="stat-item">
        <span class="stat-number">${Object.keys(GM_ACTORS_INDEX).length}</span>
        <span class="stat-label">Akteure vernetzt</span>
      </div>
    `;
  }

  // ── Sidebar Nav ────────────────────────────────────────
  function buildSidebarNav() {
    sidebarNav.innerHTML = '';
    GM_DATA.forEach(domain => {
      const wrap = document.createElement('div');
      wrap.className = 'nav-domain';
      wrap.dataset.id = domain.id;

      const btn = document.createElement('button');
      btn.className = 'nav-domain-btn';
      btn.dataset.id = domain.id;
      btn.innerHTML = `
        <span class="nav-domain-icon">${domain.icon}</span>
        <span>${domain.title}</span>
        <span class="nav-domain-dot" style="background:${domain.color}"></span>
      `;
      btn.addEventListener('click', () => { switchTab('wiki'); showDomain(domain.id); });

      const capList = document.createElement('div');
      capList.className = 'nav-capabilities';
      capList.id = `nav-caps-${domain.id}`;

      domain.capabilities.forEach(cap => {
        const capBtn = document.createElement('button');
        capBtn.className = 'nav-cap-btn';
        capBtn.textContent = cap.title;
        capBtn.dataset.capId = cap.id;
        capBtn.title = cap.title;
        capBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          switchTab('wiki');
          showCapability(domain.id, cap.id);
        });
        capList.appendChild(capBtn);
      });

      wrap.appendChild(btn);
      wrap.appendChild(capList);
      sidebarNav.appendChild(wrap);
    });
  }

  // ── Tabs ───────────────────────────────────────────────
  function switchTab(tab) {
    currentTab = tab;
    tabBtns.forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
    hero.classList.add('hidden');
    domainView.classList.add('hidden');
    detailView.classList.add('hidden');
    matrixView.classList.add('hidden');
    akteureView.classList.add('hidden');
    const old = document.getElementById('searchResults');
    if (old) old.remove();

    if (tab === 'matrix')  { matrixView.classList.remove('hidden'); return; }
    if (tab === 'akteure') { akteureView.classList.remove('hidden'); return; }
    // wiki tab: restore previous state
    if (tab === 'wiki') {
      if (currentCapId)    { setView('detail'); return; }
      if (currentDomainId) { setView('domain'); return; }
      setView('hero');
    }
  }

  // ── View: Domain ───────────────────────────────────────
  function showDomain(domainId) {
    const domain = GM_DATA.find(d => d.id === domainId);
    if (!domain) return;
    currentDomainId = domainId;
    currentCapId    = null;
    updateNavActive(domainId, null);
    setView('domain');

    domainHeader.innerHTML = `
      <div class="domain-eyebrow" style="color:${domain.color}">
        ${domain.icon} Wertschöpfungsstufe
      </div>
      <h2>${domain.title}</h2>
      <p class="domain-desc">${domain.description}</p>
    `;

    capabilityGrid.innerHTML = '';
    domain.capabilities.forEach(cap => {
      const card = document.createElement('div');
      card.className = 'cap-card';
      card.style.setProperty('--card-color', domain.color);
      const actorTags = cap.actors.slice(0, 3).map(a => `<span class="cap-actor-tag">${a}</span>`).join('');
      const more = cap.actors.length > 3 ? `<span class="cap-actor-tag">+${cap.actors.length - 3}</span>` : '';
      card.innerHTML = `
        <div class="cap-card-header">
          <h3 class="cap-card-title">${cap.title}</h3>
          <span class="cap-card-count">${cap.items.length} GM</span>
        </div>
        <p class="cap-card-desc">${cap.description}</p>
        <div class="cap-actors">${actorTags}${more}</div>
      `;
      card.addEventListener('click', () => showCapability(domainId, cap.id));
      capabilityGrid.appendChild(card);
    });
    closeMobileNav();
  }

  // ── View: Capability Detail ────────────────────────────
  function showCapability(domainId, capId) {
    const domain = GM_DATA.find(d => d.id === domainId);
    if (!domain) return;
    const cap = domain.capabilities.find(c => c.id === capId);
    if (!cap) return;
    currentDomainId = domainId;
    currentCapId    = capId;
    updateNavActive(domainId, capId);
    setView('detail');

    const actorTags = cap.actors.map(a => `<span class="detail-actor-tag">${a}</span>`).join('');
    const itemsHtml = cap.items.map(item => renderItemCard(item, domain.color)).join('');

    detailContent.innerHTML = `
      <div class="detail-cap-header">
        <div class="detail-cap-eyebrow">${domain.icon} ${domain.title}</div>
        <h2 class="detail-cap-title">${cap.title}</h2>
        <p class="detail-cap-desc">${cap.description}</p>
        <div class="detail-actors">${actorTags}</div>
      </div>
      <div class="items-list">${itemsHtml}</div>
    `;
    closeMobileNav();
  }

  function renderItemCard(item, color) {
    const statusLabel = { aktiv: 'Aktiv', emerging: 'Emerging', planned: 'Geplant' }[item.status] || item.status;
    const radarSvg = item.radar ? buildRadarSVG(item.radar, color) : '';
    const akteurLinks = item.akteure ? item.akteure.map(a =>
      `<span class="akteur-chip" data-akteur="${a}">${a}</span>`
    ).join('') : '';

    return `
      <div class="item-card">
        <div class="item-header">
          <h3 class="item-title">${item.title}</h3>
          <span class="item-status ${item.status}">${statusLabel}</span>
        </div>
        <div class="item-body">
          <div class="item-left">
            <div class="item-definition">${item.definition}</div>
            <div class="item-meta">
              ${metaRow('Erlösmodell', item.erloesmodell)}
              ${metaRow('Erlöstyp', item.erloesTyp ? `<span class="erloestyp-badge et-${item.erloesTyp.toLowerCase().replace('-','')}">${item.erloesTyp}</span>` : '')}
              ${metaRow('Regulierung', item.regulierung)}
              ${metaRow('Kundensegment', item.kundensegment)}
              ${metaRow('Differenzierung', item.differenzierung)}
            </div>
            ${akteurLinks ? `<div class="akteur-chips-row"><span class="meta-label-inline">Akteure:</span>${akteurLinks}</div>` : ''}
          </div>
          ${radarSvg ? `<div class="item-radar">${radarSvg}</div>` : ''}
        </div>
      </div>
    `;
  }

  function metaRow(label, value) {
    if (!value) return '';
    return `<div class="meta-row"><div class="meta-label">${label}</div><div class="meta-value">${value}</div></div>`;
  }

  // ── Radar SVG ──────────────────────────────────────────
  function buildRadarSVG(radar, color) {
    const dims = ['regulierung','skalierbarkeit','marktrisiko','digitalisierung','wettbewerb','nachhaltigkeit'];
    const labels = ['Regulierungs-schutz','Skalier-barkeit','Markt-risiko','Digitali-sierung','Wettbewerbs-intensität','Nachhaltig-keit'];
    const n = dims.length;
    const cx = 110, cy = 110, r = 80;
    const max = 5;

    function pt(i, val) {
      const angle = (Math.PI * 2 * i / n) - Math.PI / 2;
      const rr = (val / max) * r;
      return [cx + rr * Math.cos(angle), cy + rr * Math.sin(angle)];
    }
    function ptFull(i) {
      const angle = (Math.PI * 2 * i / n) - Math.PI / 2;
      return [cx + r * Math.cos(angle), cy + r * Math.sin(angle)];
    }

    // grid circles
    let gridLines = '';
    for (let g = 1; g <= 5; g++) {
      const pts = dims.map((_, i) => { const angle = (Math.PI * 2 * i / n) - Math.PI / 2; const rr = (g / max) * r; return `${cx + rr * Math.cos(angle)},${cy + rr * Math.sin(angle)}`; }).join(' ');
      gridLines += `<polygon points="${pts}" fill="none" stroke="#E5E0D5" stroke-width="1"/>`;
    }

    // axes
    let axes = dims.map((_, i) => { const [x, y] = ptFull(i); return `<line x1="${cx}" y1="${cy}" x2="${x}" y2="${y}" stroke="#E5E0D5" stroke-width="1"/>`; }).join('');

    // data polygon
    const dataPoints = dims.map((d, i) => pt(i, radar[d] || 0).join(',')).join(' ');
    const dataPolygon = `<polygon points="${dataPoints}" fill="${color}33" stroke="${color}" stroke-width="2" stroke-linejoin="round"/>`;

    // dots
    const dots = dims.map((d, i) => { const [x, y] = pt(i, radar[d] || 0); return `<circle cx="${x}" cy="${y}" r="3.5" fill="${color}"/>`; }).join('');

    // labels
    const labelEls = dims.map((d, i) => {
      const [x, y] = ptFull(i);
      const dx = (x - cx); const dy = (y - cy);
      const lx = cx + (dx / r) * (r + 22);
      const ly = cy + (dy / r) * (r + 18);
      const anchor = dx > 5 ? 'start' : dx < -5 ? 'end' : 'middle';
      const lines = labels[i].split('-');
      return lines.map((line, li) => `<text x="${lx}" y="${ly + li * 12}" text-anchor="${anchor}" fill="#888" font-size="9.5" font-family="DM Sans,sans-serif">${line}</text>`).join('');
    }).join('');

    return `<svg viewBox="0 0 220 220" width="180" height="180" style="flex-shrink:0">
      ${gridLines}${axes}${dataPolygon}${dots}${labelEls}
    </svg>`;
  }

  // ── Vergleichsmatrix ───────────────────────────────────
  function renderMatrix() {
    const container = document.getElementById('matrixContainer');
    if (!container) return;

    const allItems = [];
    GM_DATA.forEach(domain => {
      domain.capabilities.forEach(cap => {
        cap.items.forEach(item => {
          allItems.push({ domain, cap, item });
        });
      });
    });

    const filterBar = document.createElement('div');
    filterBar.className = 'matrix-filter-bar';
    filterBar.innerHTML = `
      <span class="matrix-filter-label">Filter:</span>
      ${['Alle', ...GM_ERLOESTYPEN].map(t =>
        `<button class="matrix-filter-btn${t === 'Alle' ? ' active' : ''}" data-type="${t}">${t}</button>`
      ).join('')}
      <span class="matrix-filter-label" style="margin-left:16px">Status:</span>
      <button class="matrix-filter-btn active" data-status="alle">Alle</button>
      <button class="matrix-filter-btn" data-status="aktiv">Aktiv</button>
      <button class="matrix-filter-btn" data-status="emerging">Emerging</button>
    `;

    const tableWrap = document.createElement('div');
    tableWrap.className = 'matrix-table-wrap';
    tableWrap.id = 'matrixTableWrap';

    container.appendChild(filterBar);
    container.appendChild(tableWrap);

    function rebuildTable(typeFilter, statusFilter) {
      const filtered = allItems.filter(({ item }) => {
        const typeOk = typeFilter === 'Alle' || item.erloesTyp === typeFilter;
        const statusOk = statusFilter === 'alle' || item.status === statusFilter;
        return typeOk && statusOk;
      });

      const dims = ['regulierung','skalierbarkeit','marktrisiko','digitalisierung','wettbewerb','nachhaltigkeit'];
      const dimLabels = ['Reg.-schutz','Skalierbar.','Marktrisiko','Digitalisierung','Wettbewerb','Nachhaltigkeit'];

      const rows = filtered.map(({ domain, cap, item }) => {
        const statusLabel = { aktiv: 'Aktiv', emerging: 'Emerging', planned: 'Geplant' }[item.status] || item.status;
        const radarCells = dims.map(d => {
          const v = item.radar ? (item.radar[d] || 0) : 0;
          return `<td class="radar-cell"><div class="radar-bar"><div class="radar-fill" style="width:${v * 20}%;background:${domain.color}"></div></div><span class="radar-val">${v}</span></td>`;
        }).join('');
        return `
          <tr class="matrix-row" data-domain="${domain.id}" data-cap="${cap.id}">
            <td class="mx-icon">${domain.icon}</td>
            <td class="mx-title"><strong>${item.title}</strong><br/><span class="mx-sub">${cap.title}</span></td>
            <td><span class="erloestyp-badge et-${(item.erloesTyp||'').toLowerCase().replace('-','')}">${item.erloesTyp || '—'}</span></td>
            <td><span class="item-status ${item.status}">${statusLabel}</span></td>
            ${radarCells}
          </tr>
        `;
      }).join('');

      tableWrap.innerHTML = `
        <table class="matrix-table">
          <thead>
            <tr>
              <th></th>
              <th>Geschäftsmodell</th>
              <th>Erlöstyp</th>
              <th>Status</th>
              ${dimLabels.map(l => `<th class="dim-header">${l}</th>`).join('')}
            </tr>
          </thead>
          <tbody>${rows || '<tr><td colspan="10" style="text-align:center;padding:32px;color:#999">Keine Treffer</td></tr>'}</tbody>
        </table>
      `;

      // Row click → navigate to detail
      tableWrap.querySelectorAll('.matrix-row').forEach(row => {
        row.addEventListener('click', () => {
          switchTab('wiki');
          showCapability(row.dataset.domain, row.dataset.cap);
        });
      });
    }

    let activeType = 'Alle', activeStatus = 'alle';
    rebuildTable(activeType, activeStatus);

    filterBar.addEventListener('click', e => {
      const btn = e.target.closest('.matrix-filter-btn');
      if (!btn) return;
      if (btn.dataset.type) {
        activeType = btn.dataset.type;
        filterBar.querySelectorAll('[data-type]').forEach(b => b.classList.toggle('active', b === btn));
      }
      if (btn.dataset.status) {
        activeStatus = btn.dataset.status;
        filterBar.querySelectorAll('[data-status]').forEach(b => b.classList.toggle('active', b === btn));
      }
      rebuildTable(activeType, activeStatus);
    });
  }

  // ── Akteurs-Vernetzung ─────────────────────────────────
  function renderAkteure() {
    const container = document.getElementById('akteureContainer');
    if (!container) return;

    const sorted = Object.entries(GM_ACTORS_INDEX).sort((a, b) => b[1].length - a[1].length);

    const searchWrap = document.createElement('div');
    searchWrap.className = 'akteur-search-wrap';
    searchWrap.innerHTML = `<input type="text" id="akteurSearch" placeholder="Akteur suchen…" class="akteur-search-input"/>`;

    const grid = document.createElement('div');
    grid.className = 'akteur-grid';
    grid.id = 'akteurGrid';

    container.appendChild(searchWrap);
    container.appendChild(grid);

    function renderCards(filter) {
      const filtered = filter
        ? sorted.filter(([name]) => name.toLowerCase().includes(filter.toLowerCase()))
        : sorted;
      grid.innerHTML = filtered.map(([name, entries]) => {
        const maxCount = Math.max(...sorted.map(e => e[1].length));
        const domains = [...new Set(entries.map(e => e.domainIcon + ' ' + e.domainTitle))];
        const items = entries.map(e => `
          <div class="akteur-item-link" data-domain="${e.domainId}" data-cap="${entries.find(x => x.itemId === e.itemId)?.domainId}">
            <span class="ail-icon">${e.domainIcon}</span>
            <span class="ail-text">${e.itemTitle}</span>
            <span class="ail-sub">${e.capTitle}</span>
          </div>
        `).join('');
        return `
          <div class="akteur-card">
            <div class="akteur-card-header">
              <div class="akteur-name">${name}</div>
              <div class="akteur-count-bar">
                <div class="akteur-count-fill" style="width:${(entries.length / maxCount) * 100}%"></div>
              </div>
              <div class="akteur-count-label">${entries.length} GM${entries.length !== 1 ? 's' : ''}</div>
            </div>
            <div class="akteur-domains">${domains.map(d => `<span class="akteur-domain-tag">${d}</span>`).join('')}</div>
            <div class="akteur-items-list">${items}</div>
          </div>
        `;
      }).join('');

      // click to navigate
      grid.querySelectorAll('.akteur-item-link').forEach(el => {
        el.addEventListener('click', () => {
          // find the matching entry
          const name = el.closest('.akteur-card').querySelector('.akteur-name').textContent;
          const title = el.querySelector('.ail-text').textContent;
          let targetDomain = null, targetCap = null;
          GM_DATA.forEach(domain => {
            domain.capabilities.forEach(cap => {
              cap.items.forEach(item => {
                if (item.titel === title || item.title === title) {
                  if (item.akteure && item.akteure.includes(name)) {
                    targetDomain = domain.id;
                    targetCap = cap.id;
                  }
                }
              });
            });
          });
          if (targetDomain) { switchTab('wiki'); showCapability(targetDomain, targetCap); }
        });
      });
    }

    renderCards('');
    document.getElementById('akteurSearch').addEventListener('input', e => renderCards(e.target.value));
  }

  // ── View Manager ───────────────────────────────────────
  function setView(view) {
    hero.classList.add('hidden');
    domainView.classList.add('hidden');
    detailView.classList.add('hidden');
    matrixView.classList.add('hidden');
    akteureView.classList.add('hidden');
    const old = document.getElementById('searchResults');
    if (old) old.remove();
    currentView = view;
    if (view === 'hero')   hero.classList.remove('hidden');
    if (view === 'domain') domainView.classList.remove('hidden');
    if (view === 'detail') detailView.classList.remove('hidden');
  }

  function showHero() {
    currentDomainId = null; currentCapId = null;
    updateNavActive(null, null);
    setView('hero');
  }

  // ── Nav Active ─────────────────────────────────────────
  function updateNavActive(domainId, capId) {
    document.querySelectorAll('.nav-domain-btn').forEach(btn => {
      const active = btn.dataset.id === domainId;
      btn.classList.toggle('active', active);
      const cl = document.getElementById(`nav-caps-${btn.dataset.id}`);
      if (cl) cl.classList.toggle('open', active);
    });
    document.querySelectorAll('.nav-cap-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.capId === capId);
    });
  }

  // ── Search ─────────────────────────────────────────────
  function showSearch(query) {
    const q = query.toLowerCase().trim();
    if (!q) { showHero(); return; }

    const results = [];
    GM_DATA.forEach(domain => {
      domain.capabilities.forEach(cap => {
        cap.items.forEach(item => {
          const hay = [item.title, item.definition, item.erloesmodell,
            item.regulierung, item.kundensegment, item.differenzierung,
            cap.title, domain.title, (item.akteure||[]).join(' ')].join(' ').toLowerCase();
          if (hay.includes(q)) results.push({ domain, cap, item, q });
        });
      });
    });

    updateNavActive(null, null);
    setView('hero'); // temporarily
    hero.classList.add('hidden');

    const container = document.createElement('div');
    container.className = 'search-results';
    container.id = 'searchResults';

    const snippet = (text, q) => {
      if (!text) return '';
      const idx = text.toLowerCase().indexOf(q);
      if (idx === -1) return text.substring(0, 100) + '…';
      const s = Math.max(0, idx - 40), e = Math.min(text.length, idx + q.length + 60);
      return (s > 0 ? '…' : '') + escHtml(text.substring(s, idx)) +
        `<mark>${escHtml(text.substring(idx, idx + q.length))}</mark>` +
        escHtml(text.substring(idx + q.length, e)) + (e < text.length ? '…' : '');
    };

    container.innerHTML = `
      <h3>Suchergebnisse</h3>
      <p class="result-count">${results.length} Treffer für „${escHtml(query)}"</p>
      ${results.length > 0 ? results.map(r => `
        <div class="search-result-item" data-domain="${r.domain.id}" data-cap="${r.cap.id}">
          <div class="sri-title">${r.item.title}</div>
          <div class="sri-path">${r.domain.icon} ${r.domain.title} › ${r.cap.title}</div>
          <div class="sri-snippet">${snippet(r.item.definition, r.q)}</div>
        </div>
      `).join('') : '<p style="color:var(--ink-light);font-size:14px">Keine Treffer gefunden.</p>'}
    `;
    main.appendChild(container);
    container.querySelectorAll('.search-result-item').forEach(el => {
      el.addEventListener('click', () => {
        showCapability(el.dataset.domain, el.dataset.cap);
        searchInput.value = '';
        container.remove();
      });
    });
  }

  // ── Events ─────────────────────────────────────────────
  function bindEvents() {
    backBtn.addEventListener('click', () => {
      if (currentCapId && currentDomainId) showDomain(currentDomainId);
      else showHero();
    });

    searchInput.addEventListener('input', e => {
      clearTimeout(searchTimeout);
      const q = e.target.value.trim();
      searchTimeout = setTimeout(() => {
        if (q.length >= 2) showSearch(q);
        else {
          const old = document.getElementById('searchResults');
          if (old) old.remove();
          if (currentTab !== 'wiki') return;
          if (currentCapId) setView('detail');
          else if (currentDomainId) setView('domain');
          else setView('hero');
        }
      }, 200);
    });

    tabBtns.forEach(btn => {
      btn.addEventListener('click', () => switchTab(btn.dataset.tab));
    });

    mobileToggle.addEventListener('click', () => sidebar.classList.toggle('open'));
    main.addEventListener('click', () => { if (sidebar.classList.contains('open')) sidebar.classList.remove('open'); });

    // Akteur-Chips in detail view (delegated)
    document.addEventListener('click', e => {
      const chip = e.target.closest('.akteur-chip');
      if (!chip) return;
      switchTab('akteure');
      setTimeout(() => {
        const search = document.getElementById('akteurSearch');
        if (search) { search.value = chip.dataset.akteur; search.dispatchEvent(new Event('input')); }
      }, 50);
    });
  }

  function closeMobileNav() { sidebar.classList.remove('open'); }

  function escHtml(str) {
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  // ── Boot ───────────────────────────────────────────────
  init();
})();
