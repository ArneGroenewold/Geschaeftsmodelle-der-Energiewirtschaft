// ============================================================
// ENERGIEWIRTSCHAFT GESCHÄFTSMODELL-WIKI
// data.js — alle Inhalte, v1.1 Juni 2026
// ============================================================

const GM_WIKI_VERSION = "v1.1 · Juni 2026";

// Radar-Dimensionen (0–5) pro Geschäftsmodell
// regulierung   = Regulierungsschutz (5 = volles Monopol/ARegV)
// skalierbarkeit= Skalierbarkeit ohne linearen Capex
// marktrisiko   = Marktpreisrisiko (5 = maximales Exposure)
// digitalisierung= Digitalisierungsgrad / Tech-Intensität
// wettbewerb    = Wettbewerbsintensität (5 = hyper-kompetitiv)
// nachhaltigkeit= ESG-/Nachhaltigkeitsprofil

const GM_DATA = [
  // ══════════════════════════════════════════════════════════
  // L1: ERZEUGUNG & SPEICHERUNG
  // ══════════════════════════════════════════════════════════
  {
    id: "L1-ERZ",
    title: "Erzeugung & Speicherung",
    icon: "⚡",
    color: "#F59E0B",
    description: "Akteure, die physische Energie erzeugen, wandeln oder speichern – von konventionellen Großkraftwerken bis zu dezentralen Speichersystemen.",
    capabilities: [
      {
        id: "L2-ERZ-KONV",
        title: "Konventionelle Großerzeugung",
        description: "Betrieb thermischer Kraftwerke (Gas, Kohle, Öl) im Merit-Order-Wettbewerb.",
        actors: ["RWE Generation", "Uniper", "LEAG", "EnBW Kernkraft (Auslauf)"],
        items: [
          {
            id: "L3-ERZ-KONV-01",
            title: "Merchant-Erzeugung (Spotmarkt)",
            definition: "Kraftwerksbetreiber verkaufen Strom an der Strombörse (EPEX SPOT). Erlös = Spread zwischen Erzeugungskosten (Brennstoff + CO₂-Zertifikat) und Day-Ahead/Intraday-Preis. Hochvolatil, da vollständig dem Marktrisiko ausgesetzt.",
            erloesmodell: "Merchant / Spot",
            regulierung: "EnWG §12, EU ETS (CO₂), REMIT",
            kundensegment: "Großhandel / Börse",
            differenzierung: "Grenzkosten, Flexibilität (Ramping), Verfügbarkeit",
            status: "aktiv",
            radar: { regulierung: 1, skalierbarkeit: 2, marktrisiko: 5, digitalisierung: 2, wettbewerb: 4, nachhaltigkeit: 1 },
            erloesTyp: "Merchant",
            akteure: ["RWE Generation", "Uniper", "LEAG"]
          },
          {
            id: "L3-ERZ-KONV-02",
            title: "Regelenergie & Systemdienstleistungen",
            definition: "Zusatzerlöse durch Bereitstellung von FCR/aFRR/mFRR. Leistungspreis für Vorhaltung, Arbeitspreis bei Abruf. Präqualifikation über regelleistung.net. In Deutschland noch kein formaler Kapazitätsmarkt.",
            erloesmodell: "Leistungspreis (Kapazität) + Arbeitspreis (Abruf)",
            regulierung: "SO GL Art. 154ff., SOGL Annex, regelleistung.net",
            kundensegment: "ÜNB (TSO)",
            differenzierung: "Reaktionsgeschwindigkeit, Präqualifikation, Portfoliogröße",
            status: "aktiv",
            radar: { regulierung: 3, skalierbarkeit: 2, marktrisiko: 2, digitalisierung: 3, wettbewerb: 3, nachhaltigkeit: 1 },
            erloesTyp: "Fee-based",
            akteure: ["RWE Generation", "Uniper", "Statkraft"]
          },
          {
            id: "L3-ERZ-KONV-03",
            title: "Power Purchase Agreement – konventionell",
            definition: "Langfristiger bilateraler Liefervertrag mit Industriekunden oder Lieferanten. Fixiert Preis und Menge über 5–15 Jahre. Reduziert Marktrisiko, erfordert kreditwürdigen Abnehmer. Klassisches Instrument für Baseload-Vermarktung.",
            erloesmodell: "Langfristiger Festpreis / Floor-Price-Modell",
            regulierung: "BGB, EnWG §42a",
            kundensegment: "B2B Industrie, Lieferanten",
            differenzierung: "Preissicherheit, Lieferzuverlässigkeit, Bonitätsmanagement",
            status: "aktiv",
            radar: { regulierung: 1, skalierbarkeit: 2, marktrisiko: 2, digitalisierung: 1, wettbewerb: 3, nachhaltigkeit: 2 },
            erloesTyp: "Merchant",
            akteure: ["RWE", "Uniper", "EnBW"]
          }
        ]
      },
      {
        id: "L2-ERZ-EE",
        title: "Erneuerbare Energien",
        description: "Wind-, Solar- und Wasserkraftanlagen im Förder- und Marktumfeld. Zunehmend merchant-basiert nach EEG-Auslauf.",
        actors: ["RWE Renewables", "EnBW", "Ørsted", "Encavis", "ABO Wind", "Baywa r.e."],
        items: [
          {
            id: "L3-ERZ-EE-01",
            title: "EEG-Marktprämienmodell",
            definition: "Anlagenbetreiber vermarkten Strom selbst (Direktvermarktung) und erhalten gleitende Marktprämie = EEG-Vergütung minus Referenzmarktwert. Direktvermarkter bündeln Portfolios und optimieren Vermarktung. Kernmechanismus der deutschen Energiewende.",
            erloesmodell: "Marktprämie (staatlich) + Spotmarkterlös",
            regulierung: "EEG 2023, §20–§53, BNetzA Überwachung",
            kundensegment: "Direktvermarkter, ÜNB (EinsMan)",
            differenzierung: "Prognosegüte, Portfoliooptimierung, Direktvermarktungskosten",
            status: "aktiv",
            radar: { regulierung: 4, skalierbarkeit: 3, marktrisiko: 2, digitalisierung: 3, wettbewerb: 2, nachhaltigkeit: 5 },
            erloesTyp: "Reguliert",
            akteure: ["RWE Renewables", "EnBW", "Ørsted", "Encavis"]
          },
          {
            id: "L3-ERZ-EE-02",
            title: "Corporate PPA (Erneuerbare)",
            definition: "Direktliefervertrag zwischen EE-Anlagenbetreiber und Industriekunden (oft Financial PPA = CfD). Ermöglicht Projektfinanzierung ohne EEG-Förderung. Stark wachsendes Segment, getrieben durch RE100-Commitments von Industrie und Tech-Konzernen.",
            erloesmodell: "Strike Price (Differenzvertrag) oder physischer Festpreis",
            regulierung: "BGB, EU RED III",
            kundensegment: "B2B Industrie (DAX, Tech-Konzerne)",
            differenzierung: "Laufzeit, Profil-Matching, Additionality-Nachweis",
            status: "aktiv",
            radar: { regulierung: 1, skalierbarkeit: 3, marktrisiko: 2, digitalisierung: 2, wettbewerb: 3, nachhaltigkeit: 5 },
            erloesTyp: "Merchant",
            akteure: ["Ørsted", "RWE Renewables", "Baywa r.e.", "Encavis"]
          },
          {
            id: "L3-ERZ-EE-03",
            title: "Bürgerenergiegenossenschaft",
            definition: "Genossenschaftlich organisierter EE-Betrieb (z.B. EWS Schönau, BürgerEnergie Berlin). Mitglieder sind Kapitalgeber und Kunden zugleich. Erlös aus Stromverkauf fließt in Dividende und Gemeinwohl. Stärker ideologisch als renditegetrieben.",
            erloesmodell: "Genossenschaftsdividende, Direktlieferung an Mitglieder",
            regulierung: "EEG, GenG, EnWG §3 Nr. 15",
            kundensegment: "B2C Bürger / Mitglieder",
            differenzierung: "Gemeinwohl, Lokalität, Mitbestimmung",
            status: "aktiv",
            radar: { regulierung: 2, skalierbarkeit: 1, marktrisiko: 2, digitalisierung: 1, wettbewerb: 1, nachhaltigkeit: 5 },
            erloesTyp: "Fee-based",
            akteure: ["EWS Schönau", "BürgerEnergie Berlin", "Greenpeace Energy"]
          },
          {
            id: "L3-ERZ-EE-04",
            title: "Offshore-Wind-Projektentwicklung",
            definition: "Spezialisiertes Geschäftsmodell: Entwicklung, Bau und Betrieb von Offshore-Windparks. Kapitalintensiv (>1.500 €/kW), langfristige Projektlaufzeiten (20–30 Jahre). In Deutschland über Ausschreibungen (BNetzA) vergeben. Erlös aus reguliertem Gebotspreis. Differenzierung über Projektentwicklungskompetenz, Genehmigungsmanagement und Netzanschluss-Know-how.",
            erloesmodell: "Ausschreibungsgebotspreis (€/MWh) + ggf. Marktprämie",
            regulierung: "WindSeeG, EEG 2023, BNetzA-Ausschreibungen, DENA Netzgutachten",
            kundensegment: "ÜNB (Netzanschluss), Börse (Stromverkauf)",
            differenzierung: "Genehmigungskompetenz, Serienentwicklung, O&M-Effizienz",
            status: "aktiv",
            radar: { regulierung: 4, skalierbarkeit: 2, marktrisiko: 2, digitalisierung: 3, wettbewerb: 2, nachhaltigkeit: 5 },
            erloesTyp: "Reguliert",
            akteure: ["Ørsted", "RWE Offshore", "EnBW Offshore", "Vattenfall"]
          }
        ]
      },
      {
        id: "L2-ERZ-SPEICHER",
        title: "Speicher & Flexibilität",
        description: "Batterie-, Pumpspeicher- und sonstige Speichertechnologien als eigenständiges Geschäftsmodell.",
        actors: ["Fluence", "NEOEN", "Sonnen", "EnBW (Pumpspeicher)", "Uniper (CAES)"],
        items: [
          {
            id: "L3-ERZ-SPEICHER-01",
            title: "Grid-Scale Battery (BESS) – Arbitrage + Regelenergie",
            definition: "Großbatteriespeicher (>1 MW) arbitrieren zwischen günstigen und teuren Stunden (Intraday-Spread) und bieten gleichzeitig FCR/aFRR an. Erlösstacking aus mehreren Märkten ist Kern des Business Case. In Deutschland stark durch FCR-Preis getrieben.",
            erloesmodell: "Spread-Arbitrage + Regelenergieleistungspreis",
            regulierung: "EnWG §118, SOGL Art. 154, MsbG (Metering)",
            kundensegment: "Großhandel, ÜNB",
            differenzierung: "Zyklenanzahl, Response Time, Stacking-Fähigkeit",
            status: "aktiv",
            radar: { regulierung: 1, skalierbarkeit: 3, marktrisiko: 4, digitalisierung: 4, wettbewerb: 3, nachhaltigkeit: 4 },
            erloesTyp: "Merchant",
            akteure: ["Fluence", "NEOEN", "EnBW", "RWE"]
          },
          {
            id: "L3-ERZ-SPEICHER-02",
            title: "Heimspeicher als VPP-Baustein",
            definition: "Hersteller wie Sonnen bündeln Heimspeicher zu einem virtuellen Kraftwerk. Kunden kaufen das Gerät, treten aber Kapazität an den Aggregator ab. Erlös aus Regelenergiemärkten wird geteilt. Kundenbindung durch Flat-Rate-Stromtarif.",
            erloesmodell: "Geräteverkauf + Revenue-Share (Regelenergie) + Tarifbindung",
            regulierung: "EEG §9, MsbG, EnWG §14a",
            kundensegment: "B2C Prosumer",
            differenzierung: "Community-Größe, Flatrate-Attraktivität, Integrationsgüte",
            status: "aktiv",
            radar: { regulierung: 2, skalierbarkeit: 4, marktrisiko: 2, digitalisierung: 5, wettbewerb: 3, nachhaltigkeit: 4 },
            erloesTyp: "Subscription",
            akteure: ["Sonnen", "E3/DC", "SENEC"]
          }
        ]
      }
    ]
  },

  // ══════════════════════════════════════════════════════════
  // L1: ÜBERTRAGUNGSNETZ (ÜNB / TSO)
  // ══════════════════════════════════════════════════════════
  {
    id: "L1-UNB",
    title: "Übertragungsnetz (ÜNB / TSO)",
    icon: "🔌",
    color: "#3B82F6",
    description: "Die vier deutschen ÜNBs (50Hertz, Amprion, TenneT, TransnetBW) betreiben das Höchstspannungsnetz unter regulierter Monopolstruktur.",
    capabilities: [
      {
        id: "L2-UNB-NETZ",
        title: "Netzbetrieb & Systemführung",
        description: "Kernaufgabe: sicherer Netzbetrieb, Frequenzhaltung, Engpassmanagement.",
        actors: ["50Hertz Transmission", "Amprion", "TenneT TSO", "TransnetBW"],
        items: [
          {
            id: "L3-UNB-NETZ-01",
            title: "Reguliertes Netznutzungsentgelt (ARegV)",
            definition: "ÜNBs finanzieren sich über staatlich regulierte Netzentgelte. BNetzA genehmigt Erlösobergrenze auf Basis des Regulatory Asset Base (RAB). Effizienzvergleich zwischen Netzbetreibern bestimmt individuelle Rendite. Kein Marktrisiko, aber Regulierungsrisiko.",
            erloesmodell: "Regulierte Netzentgelte (ARegV, §21 EnWG)",
            regulierung: "ARegV, StromNEV, EnWG §21ff., BNetzA",
            kundensegment: "Netzkunden (VNB, Direktkunden)",
            differenzierung: "Effizienzgrad im BNetzA-Benchmarking, Investitionsprogramm",
            status: "aktiv",
            radar: { regulierung: 5, skalierbarkeit: 1, marktrisiko: 1, digitalisierung: 2, wettbewerb: 1, nachhaltigkeit: 3 },
            erloesTyp: "Reguliert",
            akteure: ["50Hertz", "Amprion", "TenneT TSO", "TransnetBW"]
          },
          {
            id: "L3-UNB-NETZ-02",
            title: "Redispatch 2.0 & Engpassmanagement",
            definition: "Seit 2021 koordinieren ÜNBs und VNBs Einspeisemanagement und Redispatch gemeinsam über standardisierte Prozesse. Netzbetreiber erstatten Anlagenbetreibern entgangene Einspeisevergütung. Aufwändiges Informationssystem via GABI/SMARD.",
            erloesmodell: "Kostenerstattung (regulierter Kostenblock, kein Erlös)",
            regulierung: "EnWG §13, §14, RedispatchVO, BDEW-Leitfaden",
            kundensegment: "VNB, Direktanlagenbetreiber",
            differenzierung: "Prozessqualität, Systemintegration, Automatisierungsgrad",
            status: "aktiv",
            radar: { regulierung: 5, skalierbarkeit: 1, marktrisiko: 1, digitalisierung: 3, wettbewerb: 1, nachhaltigkeit: 3 },
            erloesTyp: "Reguliert",
            akteure: ["50Hertz", "Amprion", "TenneT TSO", "TransnetBW"]
          },
          {
            id: "L3-UNB-NETZ-03",
            title: "Bilanzkreismanagement & Ausgleichsenergie",
            definition: "ÜNBs betreiben das Bilanzkreissystem. Unausgeglichene Bilanzkreise zahlen Ausgleichsenergie (AE-Preis). Kein direktes Erlösmodell – aber administrativer Aufwand erheblich. Reform MaBiS BK6-24-174 modernisiert Prozesse.",
            erloesmodell: "Durchleitungsmodell / Kostenerstattung",
            regulierung: "MaBiS (BK6-18-048, BK6-24-174), StromNZV §4ff.",
            kundensegment: "Bilanzkreisverantwortliche (BKV)",
            differenzierung: "Prozessautomatisierung, Datenqualität, API-Reife",
            status: "aktiv",
            radar: { regulierung: 5, skalierbarkeit: 1, marktrisiko: 1, digitalisierung: 4, wettbewerb: 1, nachhaltigkeit: 2 },
            erloesTyp: "Reguliert",
            akteure: ["50Hertz", "Amprion", "TenneT TSO", "TransnetBW"]
          }
        ]
      }
    ]
  },

  // ══════════════════════════════════════════════════════════
  // L1: VERTEILNETZ (VNB / DSO)
  // ══════════════════════════════════════════════════════════
  {
    id: "L1-VNB",
    title: "Verteilnetz (VNB / DSO)",
    icon: "🏘️",
    color: "#10B981",
    description: "Verteilnetzbetreiber auf Mittel- und Niederspannungsebene – von großen überregionalen DSOs bis zu kommunalen Stadtwerken.",
    capabilities: [
      {
        id: "L2-VNB-KLASSISCH",
        title: "Klassischer Netzbetrieb",
        description: "Betrieb und Instandhaltung des Verteilnetzes unter regulierter Monopolstruktur.",
        actors: ["Bayernwerk Netz", "Westnetz", "E.DIS Netz", "SWM Infrastruktur", "Netz Leipzig"],
        items: [
          {
            id: "L3-VNB-KLASSISCH-01",
            title: "Reguliertes Netzentgelt (Verteilnetz)",
            definition: "ARegV-basierte Erlösobergrenze, BNetzA-Genehmigung. Für VNBs entscheidend: Kapitalkosten auf Niederspannungsnetz dominieren durch hohe Leitungslänge pro kWh. Eigenkapitalrendite ca. 5,07% nominal (BNetzA-Festlegung).",
            erloesmodell: "ARegV-Netzentgelte (§21 EnWG, StromNEV)",
            regulierung: "ARegV, StromNEV, EnWG §21, BNetzA Beschlusskammern",
            kundensegment: "Endverbraucher (indirekt via Lieferant)",
            differenzierung: "Effizienz-Benchmark, Netzqualität, Capex-Timing",
            status: "aktiv",
            radar: { regulierung: 5, skalierbarkeit: 1, marktrisiko: 1, digitalisierung: 2, wettbewerb: 1, nachhaltigkeit: 3 },
            erloesTyp: "Reguliert",
            akteure: ["Bayernwerk Netz", "Westnetz", "E.DIS Netz", "Netze BW"]
          },
          {
            id: "L3-VNB-KLASSISCH-02",
            title: "Messstellenbetrieb (iMSB / gMSB)",
            definition: "Seit MsbG 2016/2023 ist Messstellenbetrieb separiertes Geschäft. Grundzuständiger MSB (gMSB) = VNB per Default. Wettbewerblicher MSB (iMSB) kann Kunden gewinnen. Smart-Meter-Rollout Pflicht ab 2025 für >6.000 kWh/a.",
            erloesmodell: "MSB-Entgelte (reguliert, §31 MsbG) + ggf. Zusatzdienste",
            regulierung: "MsbG, BSI TR-03109, EnWG §21b",
            kundensegment: "Letztverbraucher, Anlagenbetreiber",
            differenzierung: "Rollout-Geschwindigkeit, Gateway-Admin, Datenservices",
            status: "aktiv",
            radar: { regulierung: 4, skalierbarkeit: 2, marktrisiko: 1, digitalisierung: 4, wettbewerb: 2, nachhaltigkeit: 2 },
            erloesTyp: "Reguliert",
            akteure: ["Bayernwerk Netz", "Westnetz", "discovergy", "emonvia"]
          }
        ]
      },
      {
        id: "L2-VNB-NEU",
        title: "Neue DSO-Geschäftsfelder",
        description: "Emerging Business: Flexibilitätsplattformen, Ladeinfrastruktur, Smart Grid Services.",
        actors: ["Bayernwerk Netz", "Stromnetz Berlin", "mitnetz strom", "Netze BW"],
        items: [
          {
            id: "L3-VNB-NEU-01",
            title: "§14a EnWG – Steuerbare Verbrauchseinrichtungen",
            definition: "Ab 2024: VNBs können Wärmepumpen, EV-Lader und Batteriespeicher bei Netzengpässen dimmen (max. 3,5 kW Durchsteuerleistung). Gegenleistung: 20% Netzentgeltnachlass. Eröffnet DSOs erstmals echte Flexibilitätsverwertung im eigenen Netz.",
            erloesmodell: "Netzentgelteinsparung (indirekt) + Capex-Vermeidung",
            regulierung: "EnWG §14a, BNetzA-Festlegung (BK6-22-300)",
            kundensegment: "Prosumer / Haushaltskunden",
            differenzierung: "Rollout-Geschwindigkeit, CLS-Integration, Kundenakzeptanz",
            status: "aktiv",
            radar: { regulierung: 4, skalierbarkeit: 3, marktrisiko: 1, digitalisierung: 4, wettbewerb: 1, nachhaltigkeit: 4 },
            erloesTyp: "Reguliert",
            akteure: ["Bayernwerk Netz", "Netze BW", "Stromnetz Berlin", "E.DIS"]
          },
          {
            id: "L3-VNB-NEU-02",
            title: "Öffentliche Ladeinfrastruktur (eMobility DSO)",
            definition: "VNBs investieren in Ladeinfrastruktur als Netzdienstleister oder via Tochtergesellschaften. Regulatorisch unklar: BNetzA tendiert zu Trennung. Stadtwerke-Töchter umgehen dies strukturell.",
            erloesmodell: "Ladegebühren (ct/kWh oder €/h) + Fördermittel (BEV, AFID)",
            regulierung: "EnWG, AFID (EU-VO 2023/1804), LSV",
            kundensegment: "B2C EV-Fahrer, B2B Flotten",
            differenzierung: "Standortnetz, Ladeleistung, Interoperabilität (OCPP/OCPI)",
            status: "aktiv",
            radar: { regulierung: 2, skalierbarkeit: 3, marktrisiko: 2, digitalisierung: 4, wettbewerb: 3, nachhaltigkeit: 4 },
            erloesTyp: "Fee-based",
            akteure: ["SWM E-Mobilität", "EnBW mobility+", "Bayernwerk Natur"]
          }
        ]
      }
    ]
  },

  // ══════════════════════════════════════════════════════════
  // L1: GAS & WASSERSTOFF-INFRASTRUKTUR
  // ══════════════════════════════════════════════════════════
  {
    id: "L1-GAS",
    title: "Gas & Wasserstoffnetz",
    icon: "🔵",
    color: "#6366F1",
    description: "Fernleitungsnetzbetreiber (FNB Gas) und Verteilernetze für Erdgas sowie aufkommende Wasserstoff-Infrastruktur.",
    capabilities: [
      {
        id: "L2-GAS-FNB",
        title: "Fernleitungsnetzbetreiber Gas (FNB)",
        description: "Betrieb des Hochdruckgasnetzes unter reguliertem Monopol, analog zu Strom-TSOs.",
        actors: ["Open Grid Europe (OGE)", "Gascade", "Bayernets", "Terranets BW", "GASCADE Gastransport"],
        items: [
          {
            id: "L3-GAS-FNB-01",
            title: "Reguliertes Gastransportnetz",
            definition: "FNB Gas betreiben das Hochdruckfernleitungsnetz und erheben regulierte Netzentgelte (GasNEV, ARegV). BNetzA-Erlösobergrenze analog Strom. Kapazitätsbuchungen über PRISMA-Plattform. Zunehmend unter Transformationsdruck: Wasserstoff-Readiness als strategische Investition.",
            erloesmodell: "Regulierte Netzentgelte (GasNEV, ARegV)",
            regulierung: "EnWG §21, GasNEV, ARegV, BNetzA, EU-Gasmarkt-VO",
            kundensegment: "Gaslieferanten, Industrie, VNB Gas",
            differenzierung: "Netzkapazität, H2-Readiness, Druckzonen",
            status: "aktiv",
            radar: { regulierung: 5, skalierbarkeit: 1, marktrisiko: 1, digitalisierung: 2, wettbewerb: 1, nachhaltigkeit: 2 },
            erloesTyp: "Reguliert",
            akteure: ["OGE", "Gascade", "Bayernets", "Terranets BW"]
          },
          {
            id: "L3-GAS-FNB-02",
            title: "Wasserstoff-Kernnetz (H2-Backbone)",
            definition: "Geplantes 9.700-km-H2-Kernnetz bis 2032 (BNetzA-Genehmigung 2024). Finanzierungsmodell: Anschubfinanzierung durch Staat, reguliertes Entgelt nach Ramp-up. Bestehende Gasleitungen werden umgewidmet (repurposing). Geschäftsmodell noch im Aufbau; FNB Gas als natürliche Betreiber.",
            erloesmodell: "Regulierte H2-Netzentgelte (geplant) + staatliche Anschubfinanzierung",
            regulierung: "EnWG (H2-Novelle), EU-Wasserstoffverordnung, BNetzA H2-Regulierung",
            kundensegment: "H2-Erzeuger (Elektrolyse), H2-Abnehmer (Industrie, Mobilität)",
            differenzierung: "Netzlage (Nordsee-Windstrom-Achse), Repurposing-Kompetenz",
            status: "emerging",
            radar: { regulierung: 5, skalierbarkeit: 2, marktrisiko: 2, digitalisierung: 3, wettbewerb: 1, nachhaltigkeit: 5 },
            erloesTyp: "Reguliert",
            akteure: ["OGE", "Gascade", "Bayernets", "Ontras"]
          }
        ]
      },
      {
        id: "L2-GAS-LIEFERANT",
        title: "Gaslieferung & LNG",
        description: "Beschaffung, Transport und Lieferung von Erdgas und Flüssiggas an Industrie und Haushaltskunden.",
        actors: ["Uniper", "RWE Supply & Trading", "VNG", "Wintershall Dea", "Deutsche ReGas"],
        items: [
          {
            id: "L3-GAS-LIEFERANT-01",
            title: "Gasimport & LNG-Terminal",
            definition: "Nach Wegfall russischer Pipeline-Gaslieferungen haben LNG-Terminals (Brunsbüttel, Wilhelmshaven, Lubmin) strategische Bedeutung. Betreiber (Deutsche Energy Terminal) vermieten Regasifizierungskapazität. Erlös aus Kapazitätsbuchungen. Commodity-Risiko liegt bei Lieferanten.",
            erloesmodell: "Kapazitätsbuchungsgebühr (€/MWh/Tag) + Handling-Fees",
            regulierung: "EnWG, LNG-Infrastrukturverordnung (EU), BNetzA",
            kundensegment: "Gaslieferanten, Industrie",
            differenzierung: "Terminalkapazität, Standort, Regasifizierungsgeschwindigkeit",
            status: "aktiv",
            radar: { regulierung: 4, skalierbarkeit: 2, marktrisiko: 2, digitalisierung: 2, wettbewerb: 2, nachhaltigkeit: 2 },
            erloesTyp: "Fee-based",
            akteure: ["Deutsche Energy Terminal", "RWE", "Uniper"]
          }
        ]
      }
    ]
  },

  // ══════════════════════════════════════════════════════════
  // L1: ENERGIEHANDEL & PORTFOLIOMANAGEMENT
  // ══════════════════════════════════════════════════════════
  {
    id: "L1-HANDEL",
    title: "Energiehandel & Portfoliomanagement",
    icon: "📊",
    color: "#8B5CF6",
    description: "Akteure, die Strom, Gas und Flexibilität an Großhandelsmärkten handeln – von Börsen über Trader bis zu integrierten Portfoliomanagern.",
    capabilities: [
      {
        id: "L2-HANDEL-BOERSE",
        title: "Börsenhandel & Clearing",
        description: "Marktplätze für standardisierte Energieprodukte (Spot, Futures, Intraday).",
        actors: ["EPEX SPOT", "EEX (European Energy Exchange)", "Nasdaq Commodities"],
        items: [
          {
            id: "L3-HANDEL-BOERSE-01",
            title: "Energiebörse (Exchange-Modell)",
            definition: "EPEX SPOT und EEX betreiben Marktplätze als regulierte Börsen. Erlös = Transaktionsgebühren pro MWh gehandeltes Volumen + Clearinggebühren (via ECC). Netzwerkeffekte entscheidend: Liquidität zieht Liquidität. Kein Marktpreisrisiko – reine Infrastrukturrolle.",
            erloesmodell: "Transaktionsgebühren + Clearinggebühren + Mitgliedsbeiträge",
            regulierung: "MiFID II, REMIT (ACER), EnWG §26, EMIR",
            kundensegment: "Erzeuger, Lieferanten, Trader, ÜNBs",
            differenzierung: "Liquidität, Produktpalette, Clearing-Sicherheit",
            status: "aktiv",
            radar: { regulierung: 3, skalierbarkeit: 5, marktrisiko: 1, digitalisierung: 5, wettbewerb: 2, nachhaltigkeit: 2 },
            erloesTyp: "Fee-based",
            akteure: ["EPEX SPOT", "EEX", "ECC"]
          }
        ]
      },
      {
        id: "L2-HANDEL-PORTFOLIO",
        title: "Proprietärer Handel & Portfolio-Optimierung",
        description: "Unternehmen handeln auf eigene Rechnung und/oder verwalten Kundenportfolios.",
        actors: ["Axpo", "Alpiq", "BKW Trading", "Vitol", "Statkraft Markets"],
        items: [
          {
            id: "L3-HANDEL-PORTFOLIO-01",
            title: "Proprietärer Energiehandel (Prop Trading)",
            definition: "Trader nehmen Marktpreisrisiko auf eigene Bücher: Arbitrage zwischen Märkten, Zeitzonen, Produkten. Hochgradig quantitativ, risikogesteuert. Differenzierung durch Algorithmik, Prognosefähigkeit (Wind/Solar), Informationsvorsprung. Unterliegt REMIT-Überwachung durch ACER.",
            erloesmodell: "Handelsmarge (P&L aus offenen Positionen)",
            regulierung: "REMIT, MiFID II, EMIR, EnWG §5",
            kundensegment: "Eigenbuch",
            differenzierung: "Quantitative Modelle, Datenvorteil, Risikokultur",
            status: "aktiv",
            radar: { regulierung: 2, skalierbarkeit: 4, marktrisiko: 5, digitalisierung: 5, wettbewerb: 4, nachhaltigkeit: 1 },
            erloesTyp: "Merchant",
            akteure: ["Axpo", "Alpiq", "Vitol", "Trafigura"]
          },
          {
            id: "L3-HANDEL-PORTFOLIO-02",
            title: "Direktvermarktung & Portfoliomanagement (B2B)",
            definition: "Direktvermarkter (Next Kraftwerke, Statkraft, Axpo) bündeln EE-Anlagen und optimieren deren Vermarktung. Erlös = Managementgebühr (€/MWh) + Outperformance vs. Referenzmarktwert. Skaliert durch Portfolioeffekte.",
            erloesmodell: "Managementfee + Erfolgsbeteiligung (Outperformance)",
            regulierung: "EEG §21b (Direktvermarktung), MaBiS, REMIT",
            kundensegment: "EE-Anlagenbetreiber",
            differenzierung: "Prognosegüte, Portfoliogröße, IT-Plattform",
            status: "aktiv",
            radar: { regulierung: 2, skalierbarkeit: 4, marktrisiko: 2, digitalisierung: 5, wettbewerb: 3, nachhaltigkeit: 4 },
            erloesTyp: "Fee-based",
            akteure: ["Next Kraftwerke (RWE)", "Statkraft", "Axpo", "BKW"]
          },
          {
            id: "L3-HANDEL-PORTFOLIO-03",
            title: "Strukturierte Energieprodukte (Industrieversorgung)",
            definition: "Maßgeschneiderte Produkte: Vollversorgung mit Preisgarantien, Bandlieferungen, Peak/Off-Peak-Profile, Grünstromzertifikate. Margen aus Structuring + Hedging. Komplexes Risikomanagement erforderlich.",
            erloesmodell: "Strukturierungsmarge + Volumengebühr",
            regulierung: "EnWG §42a, REMIT, MiFID II",
            kundensegment: "B2B Industrie (energieintensiv)",
            differenzierung: "Strukturierungskompetenz, Bonitätsmanagement, Grünprodukte",
            status: "aktiv",
            radar: { regulierung: 2, skalierbarkeit: 3, marktrisiko: 3, digitalisierung: 3, wettbewerb: 3, nachhaltigkeit: 3 },
            erloesTyp: "Fee-based",
            akteure: ["Axpo", "MVV Energie", "BKW", "E.ON Business"]
          }
        ]
      },
      {
        id: "L2-HANDEL-ZERTIFIKATE",
        title: "Zertifikate & CO₂-Märkte",
        description: "Handel mit Herkunftsnachweisen, GO/HKN, EUAs und freiwilligen CO₂-Zertifikaten.",
        actors: ["EEX (EUA)", "DZ-4", "Southpole", "atmosfair", "ClimatePartner"],
        items: [
          {
            id: "L3-HANDEL-ZERTIF-01",
            title: "Herkunftsnachweise (HKN / GO)",
            definition: "Herkunftsnachweise (HKN) zertifizieren, dass Strom aus erneuerbaren Quellen stammt. Lieferanten kaufen HKN zur Stromkennzeichnung (EnWG §42). Separater Markt vom physischen Strom: HKN können grenzüberschreitend gehandelt werden (RECS). Kritisiert als 'Greenwashing' wenn ohne physische Zusätzlichkeit.",
            erloesmodell: "HKN-Handelsmarge + Zertifizierungsgebühren",
            regulierung: "EnWG §42, EU-Richtlinie 2018/2001 (RED II), RECS",
            kundensegment: "Energielieferanten, Industrie (ESG-Berichterstattung)",
            differenzierung: "Zusätzlichkeit, Regionalität, Jahrgang der Anlage",
            status: "aktiv",
            radar: { regulierung: 3, skalierbarkeit: 5, marktrisiko: 2, digitalisierung: 3, wettbewerb: 3, nachhaltigkeit: 4 },
            erloesTyp: "Merchant",
            akteure: ["RECS International", "EEX", "DZ-4", "Naturstrom"]
          },
          {
            id: "L3-HANDEL-ZERTIF-02",
            title: "EU-Emissionshandel (EUA / EU ETS)",
            definition: "Pflichtmarkt für stromintensive Industrie und Energiesektor. Anlagen müssen CO₂-Zertifikate (EUAs) für ihre Emissionen vorhalten. Trader arbitrieren zwischen Spotmarkt und Futures. Phase 4 (2021–2030): Linear Reduction Factor 2,2% p.a. Stromerzeuger erhalten keine kostenlosen Zuteilungen mehr.",
            erloesmodell: "Handelsmargen auf EUA-Spot/Futures + Beratungsgebühren",
            regulierung: "EU ETS-Richtlinie (2003/87/EG), TEHG (Deutschland), ACER",
            kundensegment: "Energieerzeuger, energieintensive Industrie",
            differenzierung: "Preisprognose, Timing, Compliance-Beratung",
            status: "aktiv",
            radar: { regulierung: 4, skalierbarkeit: 4, marktrisiko: 4, digitalisierung: 4, wettbewerb: 3, nachhaltigkeit: 5 },
            erloesTyp: "Merchant",
            akteure: ["EEX", "ICE Endex", "Axpo", "RWE Supply & Trading"]
          }
        ]
      }
    ]
  },

  // ══════════════════════════════════════════════════════════
  // L1: VERTRIEB & ENERGIELIEFERUNG
  // ══════════════════════════════════════════════════════════
  {
    id: "L1-VERTRIEB",
    title: "Vertrieb & Energielieferung",
    icon: "🏠",
    color: "#EF4444",
    description: "Das vielfältigste Segment: von integrierten Vollversorgern über digitale Neolieferanten bis zu Ökostrom-Genossenschaften.",
    capabilities: [
      {
        id: "L2-VERTRIEB-VOLL",
        title: "Integrierter Vollversorger",
        description: "Große Energiekonzerne mit vollständiger Wertschöpfungskette: Erzeugung, Netz, Vertrieb, Services.",
        actors: ["E.ON / E.ON Energie Deutschland", "EnBW", "RWE / innogy", "Vattenfall"],
        items: [
          {
            id: "L3-VERTRIEB-VOLL-01",
            title: "Massenmarkt B2C – Grundversorgung & Sondertarife",
            definition: "Grundversorger (§36 EnWG) beliefern Haushaltskunden zum regulierten Grundversorgungstarif. Zusätzlich wettbewerbliche Sondertarife. Erlöse aus Einzelhandelsspanne. Marge under pressure durch Vergleichsportale (Verivox, Check24) und Neolieferanten.",
            erloesmodell: "Einzelhandelsspanne (Retail Margin) auf Strom/Gas",
            regulierung: "EnWG §36/§38, StromGVV, GasGVV, Preistransparenz-VO",
            kundensegment: "B2C Haushaltskunden",
            differenzierung: "Marke, Bundling (Strom+Gas+Wärme), Treueprogramme",
            status: "aktiv",
            radar: { regulierung: 3, skalierbarkeit: 4, marktrisiko: 2, digitalisierung: 2, wettbewerb: 5, nachhaltigkeit: 2 },
            erloesTyp: "Merchant",
            akteure: ["E.ON Energie", "EnBW", "RWE/innogy", "Vattenfall"]
          }
        ]
      },
      {
        id: "L2-VERTRIEB-NEO",
        title: "Digitale Neolieferanten",
        description: "API-first Anbieter mit datengetriebenen Tarifen, Community-Modellen und dynamischer Preisgestaltung.",
        actors: ["Tibber", "Ostrom", "Fünf Grad", "aWATTar"],
        items: [
          {
            id: "L3-VERTRIEB-NEO-01",
            title: "Tibber – Dynamic Pricing & Energy Community",
            definition: "Tibber verkauft kein Commodity Strom – sondern Software-Abos. Kunden zahlen monatliche App-Gebühr (9,95 €/Monat), erhalten Strom zum variablen Stundentarif (EPEX Spot + Aufschlag). Tibber verdient nicht an der kWh, sondern am Abo. Die App steuert Wärmepumpe, EV-Lader, Batteriespeicher automatisch in günstige Stunden. Community-Funktion: Nutzer teilen Einsparungen.",
            erloesmodell: "Subscription-Fee (SaaS) + ggf. kleiner Energieaufschlag",
            regulierung: "EnWG §41b (dynamische Tarife Pflicht ab 2025), MsbG (iMSB)",
            kundensegment: "B2C Tech-affine Prosumer (EV, WP, PV)",
            differenzierung: "UX/App-Qualität, Automatisierung, Community, Transparenz",
            status: "aktiv",
            radar: { regulierung: 1, skalierbarkeit: 5, marktrisiko: 1, digitalisierung: 5, wettbewerb: 3, nachhaltigkeit: 4 },
            erloesTyp: "Subscription",
            akteure: ["Tibber"]
          },
          {
            id: "L3-VERTRIEB-NEO-02",
            title: "Fünf Grad – Klimainvestitionsmodell",
            definition: "Fünf Grad kombiniert Stromlieferung mit direkter Klimainvestition: Pro kWh fließt ein fixer Betrag in zertifizierte Klimaschutzprojekte (Torfmoor-Renaturierung, Agroforstwirtschaft). Positioning: nicht Ökostrom-Zertifikat, sondern messbare Zusatzwirkung. Stärker Purpose-Marke als Preisanbieter.",
            erloesmodell: "Retail Margin + Klimaaufschlag (fixer Betrag/kWh)",
            regulierung: "EnWG, UBA-Zertifizierungsstandards",
            kundensegment: "B2C klimabewusste Konsumenten",
            differenzierung: "Impact Reporting, Additionalität, Purpose-Marke",
            status: "aktiv",
            radar: { regulierung: 1, skalierbarkeit: 4, marktrisiko: 2, digitalisierung: 3, wettbewerb: 3, nachhaltigkeit: 5 },
            erloesTyp: "Merchant",
            akteure: ["Fünf Grad"]
          },
          {
            id: "L3-VERTRIEB-NEO-03",
            title: "Ostrom – Kostenbasierter Direkttarif",
            definition: "Ostrom operiert auf radikaler Preistransparenz: Tarif = Großhandelspreis + exakt ausgewiesene Marge (ca. 1 ct/kWh). Keine Lockangebote, keine Preisgarantien. Zielgruppe: preisbewusste Verbraucher, die Vergleichsportale misstrauen. Differenzierung über Vertrauen und Einfachheit statt über Produktfeatures.",
            erloesmodell: "Fixer Marge-Aufschlag auf Großhandelspreis (transparent kommuniziert)",
            regulierung: "EnWG §41 (Preistransparenz)",
            kundensegment: "B2C preisbewusste Digital-Natives",
            differenzierung: "Radikale Transparenz, Einfachheit, Anti-Greenwashing-Positioning",
            status: "aktiv",
            radar: { regulierung: 1, skalierbarkeit: 4, marktrisiko: 2, digitalisierung: 3, wettbewerb: 4, nachhaltigkeit: 3 },
            erloesTyp: "Merchant",
            akteure: ["Ostrom"]
          },
          {
            id: "L3-VERTRIEB-NEO-04",
            title: "aWATTar – Stundentarif (EPEX-basiert)",
            definition: "Pionier des dynamischen Stundentarifs in DE/AT. Kunden zahlen exakt den stündlichen EPEX-Spot-Preis + fixer Aufschlag. Explizit für Smart-Home-Nutzer: API-Schnittstelle erlaubt Eigenautomatisierung. Kein App-Abo – reine Durchleitung des Marktpreises. Bewusst für DIY-Nutzer konzipiert.",
            erloesmodell: "Fixer Aufschlag (€/MWh) auf stündliche Spotpreise",
            regulierung: "EnWG §41b, MsbG (Smart Meter Pflicht für dynamische Tarife)",
            kundensegment: "B2C DIY-Automatisierer, Entwickler, Early Adopter",
            differenzierung: "API-Offenheit, Transparenz, keine Vendor-Lock-in",
            status: "aktiv",
            radar: { regulierung: 1, skalierbarkeit: 4, marktrisiko: 2, digitalisierung: 5, wettbewerb: 3, nachhaltigkeit: 3 },
            erloesTyp: "Merchant",
            akteure: ["aWATTar"]
          }
        ]
      },
      {
        id: "L2-VERTRIEB-OEKO",
        title: "Ökostrom-Spezialisten & Genossenschaften",
        description: "Anbieter, deren Alleinstellungsmerkmal Herkunft, Qualität oder Gemeinschaft ist.",
        actors: ["Naturstrom AG", "EWS Schönau", "Green Planet Energy", "BürgerEnergie Berlin"],
        items: [
          {
            id: "L3-VERTRIEB-OEKO-01",
            title: "Premium-Ökostrom mit Zusatzkriterien",
            definition: "Naturstrom und Green Planet Energy liefern zertifizierten Ökostrom mit strengen Zusatzkriterien: Direktlieferverträge mit Neuanlagen, Waldschutz-Projekte, keine Atomkraft-Mutterkonzerne. Preisaufschlag gegenüber konventionellem Ökostrom. Kunden zahlen für Glaubwürdigkeit, nicht nur für Strom.",
            erloesmodell: "Retail Margin + Nachhaltigkeits-Premium",
            regulierung: "EnWG §42 (Stromkennzeichnung), RECS/HKN-System",
            kundensegment: "B2C werteorientierte Kunden",
            differenzierung: "Glaubwürdigkeitskriterien, Kein-Konzern-Versprechen, Transparenzbericht",
            status: "aktiv",
            radar: { regulierung: 1, skalierbarkeit: 3, marktrisiko: 2, digitalisierung: 2, wettbewerb: 3, nachhaltigkeit: 5 },
            erloesTyp: "Merchant",
            akteure: ["Naturstrom AG", "Green Planet Energy", "EWS Schönau"]
          },
          {
            id: "L3-VERTRIEB-OEKO-02",
            title: "EWS Schönau – Genossenschaftliches Bürgerwerk",
            definition: "EWS Schönau ist Ikone der Energiewende: 1994 nach Tschernobyl als Bürgerinitiative gegründet. Heute bundesweiter Ökostromanbieter mit Genossenschaftsstruktur. Gewinne fließen in Förderprojekte. Keine Gewinnmaximierung. Differenzierung: Identifikation, Geschichte, politisches Profil.",
            erloesmodell: "Mitgliedsbeiträge + Retail Margin (reinvestiert in Mission)",
            regulierung: "GenG, EnWG, EEG",
            kundensegment: "B2C politisch-ökologisch motivierte Kunden",
            differenzierung: "Geschichte/Authentizität, Mitbestimmung, Gemeinnützigkeit",
            status: "aktiv",
            radar: { regulierung: 1, skalierbarkeit: 2, marktrisiko: 2, digitalisierung: 1, wettbewerb: 2, nachhaltigkeit: 5 },
            erloesTyp: "Merchant",
            akteure: ["EWS Schönau"]
          }
        ]
      },
      {
        id: "L2-VERTRIEB-STADTWERK",
        title: "Stadtwerke & regionale Versorger",
        description: "Kommunal geprägte Mehrsparten-Versorger mit starker lokaler Verankerung.",
        actors: ["SWM", "ENTEGA", "badenova", "enercity", "Stadtwerke Köln"],
        items: [
          {
            id: "L3-VERTRIEB-STADTWERK-01",
            title: "Kommunales Mehrsparten-Modell",
            definition: "Stadtwerke liefern Strom, Gas, Wärme, Wasser und betreiben oft ÖPNV. Quersubventionierung zwischen profitablen Netzen und defizitären ÖPNV ist strukturelles Kernmerkmal. Lokale Kundenbindung durch Nähe, Service vor Ort, kommunale Identität.",
            erloesmodell: "Multi-Sparten-Bundling; Querschuss ÖPNV ↔ Energie",
            regulierung: "EnWG, GemO der Bundesländer, kommunales Wirtschaftsrecht",
            kundensegment: "B2C lokal + B2B Gewerbe",
            differenzierung: "Lokale Identität, Service, Wärmenetz, Bundling",
            status: "aktiv",
            radar: { regulierung: 3, skalierbarkeit: 2, marktrisiko: 2, digitalisierung: 2, wettbewerb: 2, nachhaltigkeit: 3 },
            erloesTyp: "Merchant",
            akteure: ["SWM", "enercity", "Stadtwerke Köln", "badenova"]
          },
          {
            id: "L3-VERTRIEB-STADTWERK-02",
            title: "ENTEGA – Digitales Stadtwerk 2.0",
            definition: "ENTEGA (Darmstadt) positioniert sich als digitaler Versorger mit 100% Ökostrom, digitalen Self-Service-Kanälen und nachhaltiger Stadtentwicklung. Eigenständige Marke neben Muttergesellschaft HEAG. Interessant: stabiler Heimatmarkt + wachstumsorientierter Überregionalvertrieb.",
            erloesmodell: "Retail Margin + Ökostrom-Premium + Cross-Selling (Solar, E-Mobilität)",
            regulierung: "EnWG, MsbG",
            kundensegment: "B2C überregional + B2B Gewerbe",
            differenzierung: "Digitalität, Ökostrom, Wissenschaftsstadt-Branding",
            status: "aktiv",
            radar: { regulierung: 2, skalierbarkeit: 3, marktrisiko: 2, digitalisierung: 4, wettbewerb: 3, nachhaltigkeit: 4 },
            erloesTyp: "Merchant",
            akteure: ["ENTEGA", "HEAG"]
          }
        ]
      },
      {
        id: "L2-VERTRIEB-B2B",
        title: "B2B & Industrielieferung",
        description: "Spezialisierte Versorger für Gewerbe, Mittelstand und Großindustrie.",
        actors: ["Axpo Deutschland", "BKW Energie", "MVV Energie", "E.ON Business Solutions"],
        items: [
          {
            id: "L3-VERTRIEB-B2B-01",
            title: "Vollversorgung Industrie mit Preisstrukturierung",
            definition: "Industriekunden >100 MWh/a werden mit strukturierten Produkten versorgt: Festpreise, gleitende Indexierungen (EPEX-Month-Ahead), Vollversorgungsverträge mit Mehr-/Mindermengenregelungen. Procurement-Consulting als Teil des Angebots.",
            erloesmodell: "Strukturierungsmarge + Risikopremium",
            regulierung: "EnWG §42a, REMIT (ab 1 MWh), EEG-Umlagenbefreiung (§64)",
            kundensegment: "B2B Industrie / Gewerbe",
            differenzierung: "Strukturierungskompetenz, Kreditrating, Grünprodukte",
            status: "aktiv",
            radar: { regulierung: 2, skalierbarkeit: 3, marktrisiko: 3, digitalisierung: 3, wettbewerb: 3, nachhaltigkeit: 2 },
            erloesTyp: "Fee-based",
            akteure: ["Axpo", "MVV Energie", "BKW", "E.ON Business"]
          }
        ]
      }
    ]
  },

  // ══════════════════════════════════════════════════════════
  // L1: AGGREGATION & FLEXIBILITÄT
  // ══════════════════════════════════════════════════════════
  {
    id: "L1-AGG",
    title: "Aggregation & Flexibilität",
    icon: "🔋",
    color: "#06B6D4",
    description: "Aggregatoren bündeln dezentrale Erzeugungs- und Verbrauchsflexibilität zu handelbaren Einheiten.",
    capabilities: [
      {
        id: "L2-AGG-VPP",
        title: "Virtual Power Plants (VPP)",
        description: "Softwaregestützte Bündelung dezentraler Anlagen zu einem handelbaren Portfolio.",
        actors: ["Next Kraftwerke (RWE)", "Sonnen", "Enspired", "Sympower", "Statkraft"],
        items: [
          {
            id: "L3-AGG-VPP-01",
            title: "EE-Direktvermarktungs-VPP",
            definition: "Next Kraftwerke (Teil von RWE) hat Europas größtes VPP aufgebaut: >14.000 Anlagen, >10 GW. Kerngeschäft: EEG-Direktvermarktung. Wettbewerbsvorteil durch Portfoliogröße (Ausgleichseffekte) und ML-basierte Prognosemodelle.",
            erloesmodell: "Direktvermarktungsfee (€/MWh) + Outperformance-Share",
            regulierung: "EEG §21b, MaBiS, regelleistung.net-Präqualifikation",
            kundensegment: "EE-Anlagenbetreiber (B2B)",
            differenzierung: "Portfoliogröße, ML-Prognosen, Reaktionsgeschwindigkeit",
            status: "aktiv",
            radar: { regulierung: 2, skalierbarkeit: 5, marktrisiko: 2, digitalisierung: 5, wettbewerb: 3, nachhaltigkeit: 4 },
            erloesTyp: "Fee-based",
            akteure: ["Next Kraftwerke (RWE)", "Statkraft", "Axpo"]
          },
          {
            id: "L3-AGG-VPP-02",
            title: "Demand-Response-Aggregation (Industrie)",
            definition: "Industrielle Lasten (Elektrolyseure, Aluminiumhütten, Kühlhäuser) werden flexibilisiert und als virtuelles Regelenergie-Asset vermarktet. Aggregator teilt Regelenergiemärkte mit Industrie. EU-weit regulatorisch noch heterogen.",
            erloesmodell: "Revenue-Share (Regelenergiemärkte) mit Industriekunden",
            regulierung: "SOGL Art. 182 (unabhängige Aggregatoren), EnWG §12g",
            kundensegment: "B2B Industrie (energieintensiv)",
            differenzierung: "Reaktionszeit, Volumen, Präqualifikationszuverlässigkeit",
            status: "aktiv",
            radar: { regulierung: 2, skalierbarkeit: 4, marktrisiko: 2, digitalisierung: 5, wettbewerb: 2, nachhaltigkeit: 3 },
            erloesTyp: "Fee-based",
            akteure: ["Sympower", "Enspired", "E.ON Demand Response"]
          },
          {
            id: "L3-AGG-VPP-03",
            title: "Peer-to-Peer Energie-Community (P2P)",
            definition: "Prosumer verkaufen Überschussstrom direkt an Nachbarn über eine Plattform. Aggregator/Plattformbetreiber vermittelt und monetarisiert Transaktionsgebühren. Regulatorisch herausfordernd. Sonnen Community, Lichtblick SchwarmEnergie als Vorläufer.",
            erloesmodell: "Transaktionsgebühren + Plattformabo",
            regulierung: "EU EMD, EnWG §3 Nr. 38 (Eigenversorgung)",
            kundensegment: "B2C Prosumer",
            differenzierung: "Community-Größe, lokale Nähe, Plattformtransparenz",
            status: "emerging",
            radar: { regulierung: 1, skalierbarkeit: 4, marktrisiko: 1, digitalisierung: 5, wettbewerb: 2, nachhaltigkeit: 5 },
            erloesTyp: "Fee-based",
            akteure: ["Sonnen", "Lichtblick"]
          }
        ]
      },
      {
        id: "L2-AGG-FLEX",
        title: "Flexibilitätsplattformen",
        description: "Software-Plattformen für algorithmischen Intraday-Handel und Netzflexibilität.",
        actors: ["Enspired", "Habitat Energy", "gridX", "NODES"],
        items: [
          {
            id: "L3-AGG-FLEX-01",
            title: "Intraday-Automatisierungsplattform",
            definition: "Enspired und ähnliche Anbieter betreiben algorithmische Handelsplattformen für den Intraday-Markt. Kunden mieten den Algorithmus; die Plattform optimiert kontinuierlich Kauf/Verkauf basierend auf Prognose-Abweichungen. SaaS-Modell mit Performance-Fee.",
            erloesmodell: "SaaS-Fee + Performance-Fee (auf Outperformance)",
            regulierung: "REMIT, MiFID II (Algo-Trading), EnWG",
            kundensegment: "EE-Betreiber, Speicher-Asset-Manager",
            differenzierung: "Algorithmus-Güte, Latenz, Integrationstiefe",
            status: "aktiv",
            radar: { regulierung: 2, skalierbarkeit: 5, marktrisiko: 1, digitalisierung: 5, wettbewerb: 3, nachhaltigkeit: 3 },
            erloesTyp: "Subscription",
            akteure: ["Enspired", "Habitat Energy", "Axpo Digital"]
          }
        ]
      }
    ]
  },

  // ══════════════════════════════════════════════════════════
  // L1: MESSUNG, DATEN & DIGITALE SERVICES
  // ══════════════════════════════════════════════════════════
  {
    id: "L1-DIGITAL",
    title: "Messung, Daten & Digitale Services",
    icon: "📡",
    color: "#F97316",
    description: "Neue Geschäftsmodelle rund um Smart Metering, Energiedaten-Management und digitale Plattformservices.",
    capabilities: [
      {
        id: "L2-DIGITAL-METER",
        title: "Wettbewerblicher Messstellenbetrieb (iMSB)",
        description: "Seit MsbG 2016 können unabhängige MSBs den grundzuständigen VNB-MSB verdrängen.",
        actors: ["discovergy (Innogy)", "emonvia", "Wirelane", "EMH metering"],
        items: [
          {
            id: "L3-DIGITAL-METER-01",
            title: "iMSB – Smart Meter Gateway Administration",
            definition: "Wettbewerbliche MSBs installieren iMSys und betreiben das Smart Meter Gateway (SMGW). Erlös aus regulierten MSB-Entgelten (§31 MsbG) plus Mehrwertdiensten (Lastgangdaten, PV-Monitoring). BSI-Zertifizierung (TR-03109) als Markteintrittsbarriere.",
            erloesmodell: "Regulierte MSB-Entgelte + Mehrwertdienste",
            regulierung: "MsbG, BSI TR-03109, §21b EnWG",
            kundensegment: "Letztverbraucher, EE-Anlagenbetreiber",
            differenzierung: "BSI-Zertifizierung, Rollout-Geschwindigkeit, Datenservices",
            status: "aktiv",
            radar: { regulierung: 4, skalierbarkeit: 3, marktrisiko: 1, digitalisierung: 5, wettbewerb: 2, nachhaltigkeit: 2 },
            erloesTyp: "Reguliert",
            akteure: ["discovergy", "emonvia", "EMH metering", "Sagemcom"]
          }
        ]
      },
      {
        id: "L2-DIGITAL-PLATTFORM",
        title: "Energie-Plattformservices & Smart Home",
        description: "Software-Plattformen, die Energie-Hardware und -daten orchestrieren.",
        actors: ["gridX", "Tado", "Loxone", "Solarwatt", "Viessmann One"],
        items: [
          {
            id: "L3-DIGITAL-PLATTFORM-01",
            title: "HEMS / EMS-Plattform (B2B2C)",
            definition: "gridX und ähnliche Anbieter verkaufen ein Energy Management System: Hardware-Box + Cloud-Plattform orchestriert PV, Batterie, Wärmepumpe, EV-Lader. B2B2C-Modell: Installateure/Stadtwerke sind Kunden, Endkunden sind Nutzer. Erlös: Hardware + monatliche SaaS-Lizenz.",
            erloesmodell: "Hardware-Marge + SaaS-Abo (B2B) + Daten-API-Zugang",
            regulierung: "EnWG §14a (Pflicht-Steuerbarkeit), MsbG, BSI IT-Grundschutz",
            kundensegment: "B2B2C: Stadtwerke, Installateure → Endkunden",
            differenzierung: "Integrationsgüte (Hersteller-Protokolle), API, VPP-Anbindung",
            status: "aktiv",
            radar: { regulierung: 1, skalierbarkeit: 5, marktrisiko: 1, digitalisierung: 5, wettbewerb: 4, nachhaltigkeit: 4 },
            erloesTyp: "Subscription",
            akteure: ["gridX", "Loxone", "Solarwatt", "SMA"]
          },
          {
            id: "L3-DIGITAL-PLATTFORM-02",
            title: "Thermondo – Wärmewende-as-a-Service",
            definition: "Thermondo baut und finanziert Wärmepumpen und Heizungsanlagen auf Mietbasis. Kunden zahlen monatliche Rate statt Investitionskosten. Thermondo trägt Investitions- und Wartungsrisiko. Klassisches Contracting-Modell, digital skaliert.",
            erloesmodell: "Mietrate (monatlich) + Wartungsvertrag + ggf. Energielieferung",
            regulierung: "BGB (Mietrecht), GEG (Heizgesetz), BEG-Förderung",
            kundensegment: "B2C Eigenheimbesitzer",
            differenzierung: "Finanzierungsmodell, Full-Service, Installationsnetz",
            status: "aktiv",
            radar: { regulierung: 1, skalierbarkeit: 3, marktrisiko: 2, digitalisierung: 3, wettbewerb: 3, nachhaltigkeit: 5 },
            erloesTyp: "Subscription",
            akteure: ["Thermondo", "Viessmann", "Bosch Home Comfort"]
          }
        ]
      },
      {
        id: "L2-DIGITAL-BERATUNG",
        title: "Energieberatung & ESG-Services",
        description: "Beratungs- und Daten-Dienstleistungen rund um Energieeffizienz, ESG-Reporting und Nachhaltigkeitsstrategie.",
        actors: ["Capgemini Invent", "McKinsey Energy", "dena", "E.ON Consulting", "Siemens Energy Advisory"],
        items: [
          {
            id: "L3-DIGITAL-BERATUNG-01",
            title: "Energieeffizienz-Contracting (EPC)",
            definition: "Energy Performance Contracting: Dienstleister finanziert Effizienzmaßnahmen (Beleuchtung, Heizung, Druckluft) und refinanziert sich aus den garantierten Energieeinsparungen. Kunde hat kein Investitionsrisiko. Klassisch im kommunalen Sektor und Industrie. Laufzeiten 10–20 Jahre.",
            erloesmodell: "Einsparungsgarantie (shared savings oder guaranteed savings)",
            regulierung: "EnWG §3 Nr. 24a (Energiedienstleistungsunternehmen), EDL-G",
            kundensegment: "Kommunen, Industrie, Krankenhäuser, Schulen",
            differenzierung: "Garantierter Einsparbetrag, Finanzierungskompetenz, Technik-Portfolio",
            status: "aktiv",
            radar: { regulierung: 2, skalierbarkeit: 2, marktrisiko: 2, digitalisierung: 3, wettbewerb: 3, nachhaltigkeit: 5 },
            erloesTyp: "Fee-based",
            akteure: ["Siemens Smart Infrastructure", "Johnson Controls", "Engie", "Cofely"]
          },
          {
            id: "L3-DIGITAL-BERATUNG-02",
            title: "ESG-Datenplattform & Nachhaltigkeitsreporting",
            definition: "Softwareplattformen (z.B. Engie Impact, Schneider Electric EcoStruxure) aggregieren Energieverbrauchsdaten, berechnen CO₂-Footprints und erstellen automatisierte CSRD/ESRS-Reports. SaaS-Modell mit Datenkonnektoren zu ERP-Systemen. Stark wachsendes Segment durch EU-Nachhaltigkeitsberichterstattungspflichten.",
            erloesmodell: "SaaS-Abo (Plattformgebühr) + Implementierungsdienstleistung",
            regulierung: "CSRD, ESRS E1 (Klimawandel), EU-Taxonomieverordnung",
            kundensegment: "B2B Industrie, Konzerne mit CSRD-Pflicht",
            differenzierung: "Datenqualität, CSRD-Compliance, ERP-Konnektoren, Auditierbarkeit",
            status: "aktiv",
            radar: { regulierung: 3, skalierbarkeit: 5, marktrisiko: 1, digitalisierung: 5, wettbewerb: 4, nachhaltigkeit: 5 },
            erloesTyp: "Subscription",
            akteure: ["Engie Impact", "Schneider EcoStruxure", "Sphera", "Measurabl"]
          }
        ]
      }
    ]
  },

  // ══════════════════════════════════════════════════════════
  // L1: WÄRME & SEKTORKOPPLUNG
  // ══════════════════════════════════════════════════════════
  {
    id: "L1-WAERME",
    title: "Wärme & Sektorkopplung",
    icon: "🔥",
    color: "#DC2626",
    description: "Fernwärme, industrielle Wärme, Power-to-X und die Verknüpfung von Strom-, Wärme- und Gassektor.",
    capabilities: [
      {
        id: "L2-WAERME-FERN",
        title: "Fernwärme & KWK",
        description: "Netzgebundene Wärmeversorgung über Kraft-Wärme-Kopplung, industrielle Abwärme oder Großwärmepumpen.",
        actors: ["Vattenfall Wärme Berlin", "E.ON Wärme", "enercity Wärme", "MVV Energie"],
        items: [
          {
            id: "L3-WAERME-FERN-01",
            title: "Fernwärme-Monopol (Konzessionsgebiet)",
            definition: "Fernwärme ist natürliches Netzmonopol: einmal Netz verlegt, kein Wettbewerb möglich. Preisgestaltung weitgehend unkontrolliert (GWB §19-Missbrauch einziger Schutz). Ab 2026/2027 verpflichtende kommunale Wärmeplanung (WPG) verändert Investitionsrahmen massiv.",
            erloesmodell: "Wärmepreis (weitgehend frei setzbar) + Grundpreis",
            regulierung: "AVBFernwärmeV, GWB, WPG (2024), KWKG",
            kundensegment: "B2C / B2B im Netzgebiet",
            differenzierung: "Netzausdehnung, Dekarbonisierungspfad, Preisstabilität",
            status: "aktiv",
            radar: { regulierung: 4, skalierbarkeit: 1, marktrisiko: 2, digitalisierung: 2, wettbewerb: 1, nachhaltigkeit: 3 },
            erloesTyp: "Merchant",
            akteure: ["Vattenfall Wärme", "E.ON Wärme", "enercity", "MVV"]
          },
          {
            id: "L3-WAERME-FERN-02",
            title: "KWK-Anlage mit KWKG-Förderung",
            definition: "Kraft-Wärme-Kopplung erzeugt gleichzeitig Strom und Wärme. Strom an Börse vermarktet, Wärme ins Netz. KWKG-Zuschlag (staatlich) auf KWK-Strom verbessert Business Case. Zunehmend durch Großwärmepumpen + Windstrom (Power-to-Heat) konkurrenziert.",
            erloesmodell: "Spotmarkt-Erlös (Strom) + KWKG-Zuschlag + Wärmepreis",
            regulierung: "KWKG 2020, EnWG, EEG (Ausnahmen)",
            kundensegment: "Fernwärmenetz, Eigenversorgung",
            differenzierung: "Brennstoffflexibilität (Gas/H2-ready), Wirkungsgrad",
            status: "aktiv",
            radar: { regulierung: 3, skalierbarkeit: 2, marktrisiko: 3, digitalisierung: 2, wettbewerb: 2, nachhaltigkeit: 3 },
            erloesTyp: "Merchant",
            akteure: ["enercity", "Stadtwerke München", "TEAG", "EVN"]
          }
        ]
      },
      {
        id: "L2-WAERME-PTX",
        title: "Power-to-X & grüner Wasserstoff",
        description: "Sektorkopplung durch Elektrolyse: Strom → Wasserstoff → Wärme/Mobilität/Industrie.",
        actors: ["Linde", "thyssenkrupp nucera", "RWE Hydrogen", "Enapter", "H2 Mobility"],
        items: [
          {
            id: "L3-WAERME-PTX-01",
            title: "Elektrolyse & Grüner Wasserstoff (PtH2)",
            definition: "Elektrolyseure wandeln überschüssigen EE-Strom in Wasserstoff um. Geschäftsmodell hängt von EE-Strompreis-Exzessen ab (negative Preise, Curtailment-Stunden). Abnehmer: Industrie (Stahl, Chemie), Mobilität (H2-LKW), Einspeisung Gasnetz. Business Case 2026 noch subventionsabhängig (IPCEI, H2Global).",
            erloesmodell: "Wasserstoffpreis (€/kg) minus Stromkosten minus Capex-Rate",
            regulierung: "EU-Wasserstoffstrategie, RED III §27, IPCEI Wasserstoff",
            kundensegment: "B2B Industrie, Mobilität",
            differenzierung: "Stromkosten, Elektrolyseur-Effizienz, Zertifizierung (CertifHy)",
            status: "emerging",
            radar: { regulierung: 3, skalierbarkeit: 3, marktrisiko: 4, digitalisierung: 3, wettbewerb: 2, nachhaltigkeit: 5 },
            erloesTyp: "Merchant",
            akteure: ["RWE Hydrogen", "Linde", "thyssenkrupp nucera", "Enapter"]
          },
          {
            id: "L3-WAERME-PTX-02",
            title: "Power-to-Heat (Großwärmepumpe)",
            definition: "Großwärmepumpen (>1 MW) nutzen überschüssigen EE-Strom (besonders bei negativen Preisen) zur Wärmeerzeugung für Fernwärmenetze. Kombinierbar mit Wärmespeicher. Wirtschaftlich attraktiv bei hohen negativen Preiszeiten. Vattenfall Berlin und Hamburg sind Vorreiter in Deutschland.",
            erloesmodell: "Wärmepreis (Fernwärmenetz) + Stromkostenvorteil (negative Preise)",
            regulierung: "KWKG, AVBFernwärmeV, WPG (kommunale Wärmeplanung)",
            kundensegment: "Fernwärmeversorger, Industrielle Prozesswärme",
            differenzierung: "COP-Effizienz, Wärmespeicher-Integration, Netzanbindung",
            status: "aktiv",
            radar: { regulierung: 2, skalierbarkeit: 3, marktrisiko: 2, digitalisierung: 3, wettbewerb: 2, nachhaltigkeit: 5 },
            erloesTyp: "Merchant",
            akteure: ["Vattenfall Wärme", "enercity", "SWM", "Hamburg Wärme"]
          }
        ]
      }
    ]
  }
];

// ══════════════════════════════════════════════════════════
// AKTEURS-INDEX — für Cross-Referenz-Ansicht
// ══════════════════════════════════════════════════════════
const GM_ACTORS_INDEX = (function() {
  const index = {};
  GM_DATA.forEach(domain => {
    domain.capabilities.forEach(cap => {
      cap.items.forEach(item => {
        if (item.akteure) {
          item.akteure.forEach(a => {
            if (!index[a]) index[a] = [];
            index[a].push({ domainId: domain.id, domainTitle: domain.title, domainIcon: domain.icon, capTitle: cap.title, itemId: item.id, itemTitle: item.title });
          });
        }
      });
    });
  });
  return index;
})();

// ══════════════════════════════════════════════════════════
// ERLÖSTYP-INDEX — für Vergleichsmatrix
// ══════════════════════════════════════════════════════════
const GM_ERLOESTYPEN = ["Reguliert", "Merchant", "Fee-based", "Subscription"];

// ══════════════════════════════════════════════════════════
// NEUE DOMÄNEN v1.2 — Projektentwicklung, Finanzierung,
//                     eMobility-Plattformen
// Werden in GM_DATA gepusht nach Initialisierung
// ══════════════════════════════════════════════════════════
GM_DATA.push(
  // ── L1: PROJEKTENTWICKLUNG & EPC ──────────────────────
  {
    id: "L1-PROJ",
    title: "Projektentwicklung & EPC",
    icon: "🏗️",
    color: "#0EA5E9",
    description: "Unternehmen, die Energieprojekte entwickeln, genehmigen, bauen und schlüsselfertig übergeben – von Windparks bis zu Großspeichern.",
    capabilities: [
      {
        id: "L2-PROJ-WIND",
        title: "Wind- & Solar-Projektentwicklung",
        description: "Identifikation, Genehmigung und Veräußerung von EE-Projektrechten.",
        actors: ["ABO Wind", "Baywa r.e.", "wpd", "Enercon", "juwi", "Encavis", "Notus Energy"],
        items: [
          {
            id: "L3-PROJ-WIND-01",
            title: "Develop-to-Sell (Projektrechte-Handel)",
            definition: "Projektierer sichern Flächen, holen Genehmigungen ein (BImSchG, Regionalplanung) und verkaufen das fertig genehmigte Projekt an Investoren oder Betreiber. Kernwert ist die Genehmigung. Erlös = Projektverkaufspreis minus Entwicklungskosten. Risiko liegt im Genehmigungsprozess (Dauer: 4–8 Jahre in Deutschland). Differenzierung durch Flächennetzwerk, Behördenkenntnisse, Artenschutz-Know-how.",
            erloesmodell: "Einmaliger Projektverkaufserlös (Development Fee)",
            regulierung: "BImSchG, BauGB, WindBG, EEG 2023, §2 WindBG (2%-Flächenziel)",
            kundensegment: "Infrastrukturfonds, Energieversorger, Stadtwerke",
            differenzierung: "Flächennetzwerk, Genehmigungskompetenz, Artenschutz, Schnelligkeit",
            status: "aktiv",
            radar: { regulierung: 2, skalierbarkeit: 2, marktrisiko: 3, digitalisierung: 2, wettbewerb: 4, nachhaltigkeit: 5 },
            erloesTyp: "Fee-based",
            akteure: ["ABO Wind", "wpd", "juwi", "Notus Energy", "PNE"]
          },
          {
            id: "L3-PROJ-WIND-02",
            title: "Develop-to-Own (Eigenbestand)",
            definition: "Projektierer behält fertige Anlagen im Eigenbestand und erzielt langfristige Erzeugungserlöse. Erfordert Projektfinanzierung (Non-Recourse). Encavis und Baywa r.e. verfolgen dieses Modell: Portfolioaufbau mit stabilen Cash Flows. Risiko: Kapitalbindung, Zinsänderungsrisiko.",
            erloesmodell: "EEG-Marktprämie + Spot-Erlöse (über Projektlebensdauer)",
            regulierung: "EEG 2023, BImSchG, KWK-Gesetz, Finanzierungsrecht",
            kundensegment: "Eigenbetrieb / Investoren (Co-Investment)",
            differenzierung: "Portfolioqualität, Fremdkapitalkosten, O&M-Effizienz",
            status: "aktiv",
            radar: { regulierung: 3, skalierbarkeit: 3, marktrisiko: 2, digitalisierung: 2, wettbewerb: 3, nachhaltigkeit: 5 },
            erloesTyp: "Merchant",
            akteure: ["Encavis", "Baywa r.e.", "Norderney Energie", "Aquila Capital"]
          }
        ]
      },
      {
        id: "L2-PROJ-EPC",
        title: "EPC-Contractor & Turnkey-Bau",
        description: "Schlüsselfertige Errichtung von Energieanlagen auf Festpreisbasis.",
        actors: ["Siemens Gamesa", "Vestas", "Enercon", "Belectric", "Alstom Grid", "Pfisterer"],
        items: [
          {
            id: "L3-PROJ-EPC-01",
            title: "EPC-Vertrag (Engineering, Procurement, Construction)",
            definition: "Totalunternehmer übernimmt komplette Projektrealisierung zu Festpreis und Fixtermin. Risiko: Baukosten, Lieferketten, Subunternehmer. Marge typisch 8–15% auf Baukosten. Differenzierung durch Lieferkettensicherheit, Eigenproduktion kritischer Komponenten (Nacellen, Wechselrichter). EPC-Modell dominiert bei Großprojekten (Offshore-Wind, Großspeicher).",
            erloesmodell: "EPC-Vertragssumme (Festpreis) minus Baukosten = Marge",
            regulierung: "VOB/B, FIDIC-Verträge, BImSchG, CE-Kennzeichnung",
            kundensegment: "Projektentwickler, Infrastrukturfonds, Versorger",
            differenzierung: "Lieferkettensicherheit, Terminzuverlässigkeit, Garantieleistungen",
            status: "aktiv",
            radar: { regulierung: 1, skalierbarkeit: 3, marktrisiko: 3, digitalisierung: 2, wettbewerb: 3, nachhaltigkeit: 4 },
            erloesTyp: "Fee-based",
            akteure: ["Siemens Gamesa", "Vestas", "Enercon", "Belectric", "Fichtner"]
          },
          {
            id: "L3-PROJ-EPC-02",
            title: "O&M-Dienstleistungen (Betrieb & Wartung)",
            definition: "Nach Inbetriebnahme übernehmen Hersteller oder unabhängige Dienstleister (ISP) den laufenden Betrieb. Full-Service-O&M: Hersteller garantiert Verfügbarkeit (z.B. 97%). Erlös: jährliche Wartungspauschale (€/MW/Jahr). Attraktives Geschäftsmodell mit hoher Wiederkehrrate und Wechselhürden durch proprietäre SCADA-Systeme.",
            erloesmodell: "Jährliche O&M-Pauschale (€/MW/a) + Performanceboni",
            regulierung: "Wartungsvertrag nach BGB, EEG-Verfügbarkeitsanforderungen",
            kundensegment: "Windpark-/Solarparkbetreiber, Infrastrukturfonds",
            differenzierung: "Verfügbarkeitsgarantie, SCADA-Integration, Ersatzteillogistik",
            status: "aktiv",
            radar: { regulierung: 1, skalierbarkeit: 4, marktrisiko: 1, digitalisierung: 4, wettbewerb: 2, nachhaltigkeit: 4 },
            erloesTyp: "Subscription",
            akteure: ["Siemens Gamesa", "Vestas Services", "Enercon IWES", "Deutsche Windtechnik"]
          }
        ]
      }
    ]
  },

  // ── L1: ENERGIEFINANZIERUNG & INVESTOREN ──────────────
  {
    id: "L1-FINANZ",
    title: "Energiefinanzierung & Investoren",
    icon: "💰",
    color: "#10B981",
    description: "Finanzierungsmodelle für Energieprojekte – von Projektfinanzierung über Green Bonds bis zu Infrastrukturfonds.",
    capabilities: [
      {
        id: "L2-FINANZ-PROJEKT",
        title: "Projektfinanzierung & Fremdkapital",
        description: "Nicht-rückgriffsberechtigte Finanzierung (Non-Recourse) von Energieanlagen über Cashflow-Pfändung.",
        actors: ["KfW", "European Investment Bank (EIB)", "DZ Bank", "Commerzbank", "ING"],
        items: [
          {
            id: "L3-FINANZ-PROJEKT-01",
            title: "Non-Recourse Projektfinanzierung",
            definition: "Finanzierung ausschließlich auf Basis der Projekt-Cashflows (Debt Service Coverage Ratio typisch >1,3x). Keine Rückgriffsmöglichkeit auf Sponsoren. Bank prüft Technik, Vertragstruktur, Windgutachten. Typische Struktur: 70–80% Fremdkapital, 20–30% Eigenkapital. EEG-gesicherte Cashflows ermöglichen günstiges Fremdkapital.",
            erloesmodell: "Zinsmarge auf Projektdarlehen (Spread über EURIBOR)",
            regulierung: "KWG, CRR/Basel IV, EEG (Cashflow-Absicherung), EU-Taxonomie",
            kundensegment: "Projektentwickler, Eigenbestand-Betreiber",
            differenzierung: "Zinssatz, Flexibilität (Covenants), Sektorexpertise",
            status: "aktiv",
            radar: { regulierung: 3, skalierbarkeit: 4, marktrisiko: 1, digitalisierung: 2, wettbewerb: 3, nachhaltigkeit: 3 },
            erloesTyp: "Fee-based",
            akteure: ["KfW", "EIB", "DZ Bank", "ING", "Commerzbank"]
          },
          {
            id: "L3-FINANZ-PROJEKT-02",
            title: "Green Bonds & Sustainability-Linked Bonds",
            definition: "Emittenten (Versorger, Projektgesellschaften) begeben Anleihen, deren Erlöse ausschließlich für grüne Projekte verwendet werden (Green Bond Principles, ICMA). Sustainability-Linked Bonds knüpfen Kupon an ESG-KPIs (z.B. installierte EE-Kapazität). Günstigerer Zinssatz gegenüber konventionellen Bonds ('Greenium') als Geschäftsmodell-Treiber.",
            erloesmodell: "Greenium (Zinsersparnis) + Reputationsgewinn + ESG-Investorenzugang",
            regulierung: "EU Green Bond Standard (EuGB), ICMA GBP, EU-Taxonomieverordnung",
            kundensegment: "Institutionelle ESG-Investoren (Pensionsfonds, Versicherungen)",
            differenzierung: "Second-Party Opinion, Impact Reporting, Taxonomie-Konformität",
            status: "aktiv",
            radar: { regulierung: 3, skalierbarkeit: 5, marktrisiko: 1, digitalisierung: 2, wettbewerb: 3, nachhaltigkeit: 5 },
            erloesTyp: "Fee-based",
            akteure: ["E.ON", "RWE", "EnBW", "KfW", "EIB"]
          }
        ]
      },
      {
        id: "L2-FINANZ-FONDS",
        title: "Infrastrukturfonds & Eigenkapital",
        description: "Institutionelle Investoren als Eigentümer von Energieanlagen.",
        actors: ["Aquila Capital", "Encavis", "Copenhagen Infrastructure Partners", "Blackrock", "DWS Infrastruktur"],
        items: [
          {
            id: "L3-FINANZ-FONDS-01",
            title: "Geschlossener Infrastrukturfonds (EE-Assets)",
            definition: "Fonds kaufen fertige EE-Projekte (Windparks, Solarparks, Speicher) und erzielen stabile, regulierungsgesicherte Cashflows. Renditeerwartung: 5–8% IRR. Attraktiv für Pensionsfonds durch Inflation-Linkage (EEG-Vergütung) und geringe Korrelation mit Aktienmärkten. Fondsmanager verdienen Managementgebühr (1–2% p.a.) + Carried Interest (20% über Hurdle Rate).",
            erloesmodell: "Managementfee (% AuM) + Carried Interest (Erfolgsbeteiligung)",
            regulierung: "AIFMD, KAGB, EU-Taxonomieverordnung, EEG",
            kundensegment: "Institutionelle Investoren (Pensionsfonds, Versicherungen, Family Offices)",
            differenzierung: "Track Record, Dealflow, Asset Management Kompetenz",
            status: "aktiv",
            radar: { regulierung: 3, skalierbarkeit: 4, marktrisiko: 1, digitalisierung: 2, wettbewerb: 3, nachhaltigkeit: 5 },
            erloesTyp: "Fee-based",
            akteure: ["Aquila Capital", "Copenhagen Infrastructure Partners", "DWS", "Blackrock"]
          },
          {
            id: "L3-FINANZ-FONDS-02",
            title: "Bürger-Energiefonds (Crowdinvesting)",
            definition: "Plattformen wie Bettervest, Econeers oder Wiwin ermöglichen Kleinanlegern ab 250 € die Investition in EE-Projekte. Projektbetreiber erhält Mezzanine-Finanzierung (Nachrangdarlehen), Investor erhält 4–7% p.a. Zinsen. Plattform verdient Vermittlungsgebühr. Regulatorisch unter Schwarmfinanzierungsverordnung (EU 2020/1503).",
            erloesmodell: "Vermittlungsgebühr (1–3%) + Listing Fees",
            regulierung: "EU-Schwarmfinanzierungsverordnung (2020/1503), KAGB, VermAnlG",
            kundensegment: "Privatanleger (Retail), EE-Projektgesellschaften",
            differenzierung: "Projektqualität, Rendite-Risiko-Profil, Plattform-UX",
            status: "aktiv",
            radar: { regulierung: 3, skalierbarkeit: 4, marktrisiko: 2, digitalisierung: 4, wettbewerb: 3, nachhaltigkeit: 5 },
            erloesTyp: "Fee-based",
            akteure: ["Bettervest", "Econeers", "Wiwin", "Greeninvest"]
          }
        ]
      }
    ]
  },

  // ── L1: EMOBILITY & SEKTORKOPPLUNG MOBILITÄT ──────────
  {
    id: "L1-EMOB",
    title: "eMobility & Ladeinfrastruktur",
    icon: "🚗",
    color: "#8B5CF6",
    description: "Geschäftsmodelle rund um Elektromobilität: Ladeinfrastruktur-Betreiber, eMSP-Plattformen, V2G-Aggregation und Flottenlösungen.",
    capabilities: [
      {
        id: "L2-EMOB-CPO",
        title: "Charge Point Operator (CPO)",
        description: "Betrieb öffentlicher und halböffentlicher Ladeinfrastruktur.",
        actors: ["EnBW mobility+", "Ionity", "Allego", "EWE Go", "Eon Drive", "Vattenfall InCharge"],
        items: [
          {
            id: "L3-EMOB-CPO-01",
            title: "Öffentliches Ladenetz (HPC & AC)",
            definition: "CPOs bauen und betreiben öffentliche Ladepunkte (AC: 22 kW, DC HPC: 150–350 kW). Erlösmodell: Ladegebühr (ct/kWh oder €/Minute) + Roaming-Einnahmen (via eMSP). EnBW mobility+ als führender CPO in Deutschland mit >6.000 Ladepunkten. Profitabilität noch schwierig: hohe Capex, niedrige Auslastung. EU-AFID schreibt Mindestdichte vor.",
            erloesmodell: "Ladegebühr (ct/kWh) + Roaming-Einnahmen von eMSPs",
            regulierung: "AFID (EU-VO 2023/1804), LSV, EnWG, Eichrecht (MessEG)",
            kundensegment: "B2C EV-Fahrer, B2B Flotten (über eMSP)",
            differenzierung: "Netzabdeckung, Ladeleistung, Zuverlässigkeit, App-UX",
            status: "aktiv",
            radar: { regulierung: 3, skalierbarkeit: 3, marktrisiko: 2, digitalisierung: 4, wettbewerb: 4, nachhaltigkeit: 4 },
            erloesTyp: "Merchant",
            akteure: ["EnBW mobility+", "Ionity", "EWE Go", "Allego", "Vattenfall InCharge"]
          },
          {
            id: "L3-EMOB-CPO-02",
            title: "Depot- & Flottenladung (B2B)",
            definition: "CPOs oder Direktinstallation für Busdepots (ÖPNV), Logistikzentren, Firmenflotten. Individuell dimensioniert, oft mit Lastmanagement. Erlös: Hardwareverkauf + Installation + Software-Abo (Lademanagementsystem). Stadtwerke dominieren ÖPNV-Segment, Speziallösungen von Charge Amps, ABB E-mobility.",
            erloesmodell: "Hardware-Verkauf + Installation + SaaS-Lademanagement",
            regulierung: "EnWG §14a, AFID, Förderprogramme (BMDV Kommunalrichtlinie)",
            kundensegment: "B2B: ÖPNV, Logistik, Fuhrparkbetreiber",
            differenzierung: "Lastmanagement, Backend-Integration (Flotten-Software), Wartungsservice",
            status: "aktiv",
            radar: { regulierung: 2, skalierbarkeit: 4, marktrisiko: 1, digitalisierung: 5, wettbewerb: 3, nachhaltigkeit: 4 },
            erloesTyp: "Subscription",
            akteure: ["ABB E-mobility", "Charge Amps", "SWM Infrastruktur", "enercity Netz"]
          }
        ]
      },
      {
        id: "L2-EMOB-EMSP",
        title: "eMobility Service Provider (eMSP)",
        description: "Plattformen, die EV-Fahrern Zugang zu fremden Ladenetzen per Roaming ermöglichen.",
        actors: ["Hubject", "Gireve", "ARAL Pulse", "Shell Recharge", "Plug Surfing"],
        items: [
          {
            id: "L3-EMOB-EMSP-01",
            title: "eMSP-Roaming-Plattform",
            definition: "eMSPs aggregieren Ladezugänge verschiedener CPOs über OCPI-Protokoll und bieten EV-Fahrern einen einzigen Vertrag für alle Ladenetze. Erlös aus Marge zwischen CPO-Einkaufspreis und Fahrer-Verkaufspreis. Hubject betreibt die größte europäische Interoperabilitätsplattform (eRoaming via ISO 15118). B2C-eMSPs: ARAL Pulse, Shell Recharge, EnBW.",
            erloesmodell: "Roaming-Marge (ct/kWh-Spread zwischen CPO und Endkunde)",
            regulierung: "AFID Art. 5 (Preistransparenz), OCPI-Standard, EICHRECHT",
            kundensegment: "B2C EV-Fahrer (Endkunden)",
            differenzierung: "Netzabdeckung, Preis-Transparenz, App-UX, Vertragskonditionen",
            status: "aktiv",
            radar: { regulierung: 2, skalierbarkeit: 5, marktrisiko: 1, digitalisierung: 5, wettbewerb: 4, nachhaltigkeit: 4 },
            erloesTyp: "Merchant",
            akteure: ["Hubject", "ARAL Pulse", "Shell Recharge", "EnBW mobility+"]
          },
          {
            id: "L3-EMOB-EMSP-02",
            title: "Vehicle-to-Grid (V2G) Aggregation",
            definition: "EV-Batterien werden bidirektional genutzt: Fahrzeuge speisen bei Netzüberlastung zurück. Aggregator bündelt V2G-fähige Fahrzeuge (Nissan Leaf, Hyundai Ioniq 5 V2G) zu virtuellem Regelenergie-Asset. Erlösteilung zwischen Fahrer, OEM und Aggregator. Regulatorisch noch im Aufbau; EnWG §14a schafft Grundlage. Hohes Potenzial, aber Markt sehr früh.",
            erloesmodell: "Revenue-Share (Regelenergiemärkte / Netzdienstleistungen) mit EV-Haltern",
            regulierung: "EnWG §14a, EU EMD Art. 20 (V2G-Pflicht für neue Wallboxen), MsbG",
            kundensegment: "B2C EV-Halter, B2B Flotten",
            differenzierung: "V2G-fähige OEM-Partnerschaften, Aggregationsvolumen, Regelenergie-Präqual.",
            status: "emerging",
            radar: { regulierung: 2, skalierbarkeit: 5, marktrisiko: 2, digitalisierung: 5, wettbewerb: 2, nachhaltigkeit: 5 },
            erloesTyp: "Fee-based",
            akteure: ["Volkswagen / Elli", "Nissan x Nuvve", "E.ON Drive", "Jedlix"]
          }
        ]
      }
    ]
  }
);

// ══════════════════════════════════════════════════════════
// REGULIERUNGS-TIMELINE v1.2
// Meilensteine und Fristen für Geschäftsmodelle
// ══════════════════════════════════════════════════════════
const GM_TIMELINE = [
  {
    year: 2021,
    events: [
      { id: "TL-2021-01", title: "Redispatch 2.0 in Kraft", desc: "Verpflichtende ÜNB-VNB-Koordination für Einspeisemanagement und Redispatch. Alle Anlagen >100 kW müssen fernsteuerbar sein.", domains: ["L1-UNB","L1-VNB"], tags: ["Netzbetrieb","Regulierung"] },
      { id: "TL-2021-02", title: "EEG 2021: Ausbauziele & Direktvermarktung", desc: "65% EE bis 2030 als Ziel. Direktvermarktungspflicht ab 100 kW. Neue Ausschreibungsregeln für Wind und Solar.", domains: ["L1-ERZ","L1-AGG"], tags: ["EEG","Markt"] }
    ]
  },
  {
    year: 2022,
    events: [
      { id: "TL-2022-01", title: "EU ETS Phase 4 verschärft", desc: "Linear Reduction Factor auf 2,2% p.a. erhöht. Kostenloses Zuteilung für Strom-Erzeuger entfällt vollständig. CO₂-Preise steigen auf >80 €/t.", domains: ["L1-HANDEL"], tags: ["CO₂","Emissionshandel"] },
      { id: "TL-2022-02", title: "LNG-Terminals: Notfallbeschleunigung", desc: "Nach Russland-Gaslieferstopp: Bundesregierung genehmigt FSRU-Terminals in Brunsbüttel, Wilhelmshaven, Lubmin im Schnellverfahren (LNG-BeschlG).", domains: ["L1-GAS"], tags: ["Gasversorgung","Versorgungssicherheit"] },
      { id: "TL-2022-03", title: "WindBG: 2%-Flächenziel", desc: "Windenergieflächenbedarfsgesetz verpflichtet Bundesländer, 2% der Landesfläche für Windenergie auszuweisen bis 2032. Beschleunigt Genehmigungen.", domains: ["L1-ERZ","L1-PROJ"], tags: ["Wind","Genehmigung"] }
    ]
  },
  {
    year: 2023,
    events: [
      { id: "TL-2023-01", title: "EEG 2023: 80% EE bis 2030", desc: "Zielerhöhung auf 80% EE. Solar-Ausbauziel 215 GW bis 2030. Agri-PV und Floating-PV als neue Kategorien. Balkonkraftwerke vereinfacht (800 W).", domains: ["L1-ERZ"], tags: ["EEG","Solar","Wind"] },
      { id: "TL-2023-02", title: "MsbG-Reform: Rollout-Beschleunigung", desc: "Änderungen zum iMSys-Rollout: Pflicht für Verbrauchsstellen >6.000 kWh/a ab 2025. MSB-Entgelte neu geregelt. BSI-Zertifizierungsprozess vereinfacht.", domains: ["L1-VNB","L1-DIGITAL"], tags: ["Smart Meter","MSB"] },
      { id: "TL-2023-03", title: "EU AFID: Ladeinfrastruktur-Mindestdichte", desc: "Alternative Fuels Infrastructure Regulation: Mindest-Ladekapazität alle 60 km auf TEN-T-Kernnetz ab 2025. HPC-Pflicht ab 2027.", domains: ["L1-EMOB"], tags: ["eMobility","Ladeinfrastruktur"] },
      { id: "TL-2023-04", title: "CSRD in Kraft getreten", desc: "Corporate Sustainability Reporting Directive: Berichtspflicht für >500 Mitarbeiter ab 2024, für >250 ab 2025. Treibt ESG-Datenplattform-Markt.", domains: ["L1-DIGITAL"], tags: ["ESG","Reporting"] },
      { id: "TL-2023-05", title: "Wärmeplanungsgesetz (WPG) beschlossen", desc: "Kommunen >100.000 Einwohner müssen bis 2026, alle Kommunen bis 2028 kommunale Wärmepläne erstellen. Grundlage für Fernwärme-Investitionsentscheidungen.", domains: ["L1-WAERME"], tags: ["Wärme","Kommunal"] }
    ]
  },
  {
    year: 2024,
    events: [
      { id: "TL-2024-01", title: "§14a EnWG: Steuerbare Verbrauchseinrichtungen", desc: "DSOs dürfen Wärmepumpen, EV-Lader und Heimspeicher bei Netzengpässen auf 3,5 kW dimmen. Pflicht für Neuinstallationen. Kunden erhalten 20% Netzentgeltnachlass.", domains: ["L1-VNB","L1-DIGITAL"], tags: ["DSO","Flexibilität"] },
      { id: "TL-2024-02", title: "H2-Kernnetz genehmigt (BNetzA)", desc: "Genehmigung des 9.700-km-Wasserstoff-Kernnetzes durch BNetzA. Finanzierungsrahmen: Amortisationsmodell über H2-Netzentgelt mit staatlicher Rückendeckung.", domains: ["L1-GAS"], tags: ["Wasserstoff","Infrastruktur"] },
      { id: "TL-2024-03", title: "EU Green Bond Standard (EuGB) in Kraft", desc: "Einheitlicher Standard für europäische grüne Anleihen mit Taxonomie-Konformitätsprüfung und obligatorischem Impact Reporting.", domains: ["L1-FINANZ"], tags: ["Green Finance","Taxonomie"] },
      { id: "TL-2024-04", title: "MaBiS-Reform BK6-24-174", desc: "Neue Marktkommunikationsregeln für Bilanzkreismanagement. Modernisierung der Datenaustauschprozesse zwischen ÜNBs und Lieferanten/BKV.", domains: ["L1-UNB","L1-VERTRIEB"], tags: ["MaBiS","Marktkommunikation"] }
    ]
  },
  {
    year: 2025,
    events: [
      { id: "TL-2025-01", title: "Smart Meter Rollout-Pflicht (>6.000 kWh/a)", desc: "Alle Verbrauchsstellen >6.000 kWh/a müssen mit iMSys ausgestattet sein. gMSB (=VNB) trägt Rollout-Verantwortung. Wettbewerblicher iMSB-Markt öffnet sich.", domains: ["L1-VNB","L1-DIGITAL"], tags: ["Smart Meter","Rollout"] },
      { id: "TL-2025-02", title: "EnWG §41b: Dynamische Tarife Pflicht", desc: "Alle Versorger mit >200.000 Kunden müssen dynamische Tarife (stündliche EPEX-Preise) anbieten. Grundlage für Tibber/aWATTar-Modelle als Massenmarkt.", domains: ["L1-VERTRIEB"], tags: ["Dynamische Tarife","Lieferant"] },
      { id: "TL-2025-03", title: "EU AFID HPC-Mindestdichte TEN-T Kernnetz", desc: "Mindestens 150 kW Ladekapazität alle 60 km auf TEN-T-Kernnetz. CPOs müssen Netzausbau beschleunigen.", domains: ["L1-EMOB"], tags: ["eMobility","HPC"] },
      { id: "TL-2025-04", title: "CSRD: Große Unternehmen (>250 MA)", desc: "Erweiterung der CSRD-Berichtspflicht auf Unternehmen >250 Mitarbeiter. ESRS E1 Klimastandard verpflichtend. Boost für ESG-Datenplattformen.", domains: ["L1-DIGITAL"], tags: ["CSRD","ESG"] }
    ]
  },
  {
    year: 2026,
    events: [
      { id: "TL-2026-01", title: "Kommunale Wärmeplanung >100.000 EW (Frist)", desc: "Alle Kommunen über 100.000 Einwohner müssen kommunale Wärmepläne vorgelegt haben. Entscheidet über Fernwärme-Ausbaukorridore und Wettbewerb Gas vs. Wärme.", domains: ["L1-WAERME"], tags: ["Wärme","Kommunal"] },
      { id: "TL-2026-02", title: "EU Elektrizitätsbinnenmarkt-Reform (EMD)", desc: "Neue Designelemente: Terminkontrakte für EE-Erzeuger, stärkere Nachfrageflexibilität, V2G-Pflicht für neue Wallboxen ab 2027. Stärkt Aggregatoren.", domains: ["L1-AGG","L1-EMOB","L1-VERTRIEB"], tags: ["Marktdesign","Flexibilität"] }
    ]
  },
  {
    year: 2027,
    events: [
      { id: "TL-2027-01", title: "AFID HPC alle 100 km auf Gesamtnetz", desc: "Ausweitung der HPC-Pflicht auf das gesamte TEN-T-Gesamtnetz (100 km). CPO-Markt unter Investitionsdruck.", domains: ["L1-EMOB"], tags: ["eMobility","AFID"] },
      { id: "TL-2027-02", title: "V2G-Pflicht neue Wallboxen (EU EMD)", desc: "Alle neu installierten privaten und gewerblichen Wallboxen müssen V2G-fähig (bidirektional) sein. Öffnet V2G-Aggregationsmarkt für Massenanwendung.", domains: ["L1-EMOB","L1-AGG"], tags: ["V2G","eMobility"] }
    ]
  },
  {
    year: 2028,
    events: [
      { id: "TL-2028-01", title: "Kommunale Wärmeplanung alle Kommunen (Frist)", desc: "Alle deutschen Kommunen müssen Wärmepläne vorliegen haben. Abschluss der Planungsphase; nun folgt Umsetzungsphase mit Fernwärme-Investitionen.", domains: ["L1-WAERME"], tags: ["Wärme","WPG"] },
      { id: "TL-2028-02", title: "EEG-Auslauf erste Altanlagen (20 Jahre)", desc: "Erste Windanlagen aus dem Jahr 2000er EEG (2000–2005) laufen aus der 20-Jahres-Förderung aus. Repowering oder merchant-Betrieb als Geschäftsmodell-Frage.", domains: ["L1-ERZ"], tags: ["EEG-Auslauf","Repowering"] }
    ]
  },
  {
    year: 2030,
    events: [
      { id: "TL-2030-01", title: "80% Erneuerbare im Strommix (Ziel)", desc: "Nationales Ziel: 80% des Bruttostromverbrauchs aus Erneuerbaren. 215 GW Solar, 115 GW Wind onshore, 30 GW Wind offshore.", domains: ["L1-ERZ","L1-PROJ"], tags: ["Energiewende","Ziel"] },
      { id: "TL-2030-02", title: "EU ETS: Carbon Border Adjustment vollständig", desc: "Carbon Border Adjustment Mechanism (CBAM) vollständig implementiert. Emissionsintensive Importe zahlen CO₂-Preis. Stärkt europäische EE-Wettbewerbsposition.", domains: ["L1-HANDEL"], tags: ["CBAM","CO₂"] },
      { id: "TL-2030-03", title: "H2-Kernnetz: Ramp-up-Phase abgeschlossen", desc: "Wasserstoff-Kernnetz soll bis 2032 vollständig operativ sein. 2030 erste Korridore (Nordsee-Ruhrgebiet) in Betrieb. H2-Netzentgelte greifen.", domains: ["L1-GAS","L1-WAERME"], tags: ["Wasserstoff","H2-Netz"] }
    ]
  },
  {
    year: 2032,
    events: [
      { id: "TL-2032-01", title: "H2-Kernnetz vollständig operativ", desc: "9.700 km Wasserstoff-Kernnetz soll vollständig in Betrieb sein. Verknüpfung mit europäischen H2-Korridoren (European Hydrogen Backbone). Neue Geschäftsmodelle für H2-Handel und -Speicherung.", domains: ["L1-GAS","L1-WAERME","L1-PROJ"], tags: ["Wasserstoff","H2-Backbone"] },
      { id: "TL-2032-02", title: "WindBG: 2%-Flächenziel der Länder (Frist)", desc: "Alle Bundesländer müssen 2% ihrer Landesfläche für Windenergie ausgewiesen haben. Vollständige Öffnung des Planungsraums für Windprojekte.", domains: ["L1-ERZ","L1-PROJ"], tags: ["Wind","Fläche"] }
    ]
  }
];
