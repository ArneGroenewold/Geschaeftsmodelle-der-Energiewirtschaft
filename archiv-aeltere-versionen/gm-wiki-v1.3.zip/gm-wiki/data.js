// ============================================================
// ENERGIEWIRTSCHAFT GESCHÄFTSMODELL-WIKI
// data.js — v1.3 Juni 2026  |  Erweiterte inhaltliche Tiefe
// Neue Felder: wertschoepfung, herausforderungen, ausblick
// ============================================================

const GM_WIKI_VERSION = "v1.3 · Juni 2026";

const GM_DATA = [

  // ══════════════════════════════════════════════════════════
  // L1: ERZEUGUNG & SPEICHERUNG
  // ══════════════════════════════════════════════════════════
  {
    id: "L1-ERZ", title: "Erzeugung & Speicherung", icon: "⚡", color: "#F59E0B",
    description: "Physische Energieerzeugung, -wandlung und -speicherung – von konventionellen Großkraftwerken bis zu dezentralen Speichersystemen und Offshore-Windparks.",
    capabilities: [
      {
        id: "L2-ERZ-KONV", title: "Konventionelle Großerzeugung",
        description: "Thermische Kraftwerke im Merit-Order-Wettbewerb – unter zunehmendem Dekarbonisierungsdruck.",
        actors: ["RWE Generation","Uniper","LEAG","EnBW","EP Energy"],
        items: [
          {
            id: "L3-ERZ-KONV-01", title: "Merchant-Erzeugung (Spotmarkt)",
            definition: "Kraftwerksbetreiber verkaufen Strom ungeplant an der Strombörse (EPEX SPOT Day-Ahead und Intraday). Erlös = Spread zwischen variablen Grenzkosten (Brennstoff + CO₂-Zertifikat + variable O&M) und Marktpreis. Bei CCGT-Gaskraftwerken: Clean Spark Spread typisch 5–20 €/MWh je nach Gaspreis und CO₂-Preis. Der Merit-Order-Wettbewerb bedeutet: Das teuerste noch benötigte Kraftwerk setzt den Preis; günstigere Erzeuger kassieren die Inframarginalrente.",
            wertschoepfung: "Marge entsteht aus dem Spread zwischen variablen Grenzkosten und dem Merit-Order-Räumungspreis. Flexibilisierung (schnelles Ramping, Mindestlastabsenkung) ist entscheidend, um Spitzenstunden zu nutzen. Bei steigendem EE-Anteil verschiebt sich der Wert zu kurzen Spitzenlastphasen mit hohen Preisen – Gaskraftwerke werden zu 'Preis-Spitzenmachern'.",
            herausforderungen: "Steigende EE-Kapazitäten drücken Residuallast und senken Volllaststunden thermischer Anlagen drastisch. CO₂-Kosten (EU ETS Phase 4: >80 €/t) erhöhen Grenzkosten. Fehlendes Kapazitätsmarktdesign in Deutschland verhindert Refinanzierung von Neubauten. Politisches Risiko: Kohleausstieg 2038, Gasausstiegsdiskussion ab 2030.",
            ausblick: "Gaskraftwerke bleiben unverzichtbar als Residuallastdecker und Ramp-up-Kapazität. Neue H2-ready CCGT-Anlagen werden nur bei gesicherter Kapazitätsvergütung gebaut. Kapazitätsmechanismus in Deutschland gilt als unausweichlich (EU-Beihilferecht erlaubt seit 2024). Langfristig: H2-Peaker ersetzen Gaskraftwerke.",
            erloesmodell: "Merchant / Spot (Day-Ahead + Intraday)",
            regulierung: "EnWG §12, EU ETS (CO₂, TEHG), REMIT, BImSchG",
            kundensegment: "Großhandel / Börse (EPEX SPOT)",
            differenzierung: "Grenzkosten, Ramping-Fähigkeit, Verfügbarkeit, H2-Readiness",
            status: "aktiv",
            radar: { regulierung:1, skalierbarkeit:2, marktrisiko:5, digitalisierung:2, wettbewerb:4, nachhaltigkeit:1 },
            erloesTyp: "Merchant", akteure: ["RWE Generation","Uniper","LEAG"]
          },
          {
            id: "L3-ERZ-KONV-02", title: "Regelenergie & Systemdienstleistungen",
            definition: "Präqualifizierte Kraftwerke nehmen an Regelenergiemärkten teil: FCR (±MW, Reaktion <30 s), aFRR (<5 min), mFRR (<15 min). Wöchentliche Ausschreibung (FCR) bzw. tagesaktuelle Auktionen (aFRR/mFRR) über regelleistung.net. Erlösstruktur: Leistungspreis (€/MW/h, für Vorhaltung) + Arbeitspreis (€/MWh, bei Abruf). FCR-Leistungspreis ist die attraktivste Komponente – war bis 2021 >25 €/MW/h, sank durch BESS-Markteintritt.",
            wertschoepfung: "Leistungspreis ist Haupttreiber: Kapazitätsvorhaltung ohne tatsächlichen Abruf = garantierter Erlös. Stacking mit Spotmarkt möglich. Präqualifikationsbarriere schützt etablierte Anbieter. Portfolioeffekte: Größere Pools erlauben feinere Bandbreiten-Aufteilung.",
            herausforderungen: "FCR-Preisverfall durch massive BESS-Eintritte (von 30 €/MW/h auf <10 €/MW/h in Schwächephasen 2024). Europäische Integration der Regelenergiemärkte (PICASSO, MARI, TERRE) erhöht Angebot und drückt Preise langfristig. Thermalkraftwerke verlieren FCR-Markt an Batterien.",
            ausblick: "Großkraftwerke fokussieren auf aFRR/mFRR (größere Bänder, weniger BESS-Konkurrenz). Neue Systemdienstleistungen wachsen: Trägheitsemulation (Inertia), Kurzschlussleistung, Blindleistung – für diese braucht man Synchronmaschinen, also Thermalkraftwerke.",
            erloesmodell: "Leistungspreis (€/MW/h) + Arbeitspreis (€/MWh bei Abruf)",
            regulierung: "SO GL Art. 154ff., SOGL Annex, regelleistung.net, PICASSO/MARI",
            kundensegment: "ÜNB (TSO)",
            differenzierung: "Reaktionsgeschwindigkeit, Präqualifikationsgüte, Portfoliogröße",
            status: "aktiv",
            radar: { regulierung:3, skalierbarkeit:2, marktrisiko:2, digitalisierung:3, wettbewerb:3, nachhaltigkeit:1 },
            erloesTyp: "Fee-based", akteure: ["RWE Generation","Uniper","Statkraft"]
          },
          {
            id: "L3-ERZ-KONV-03", title: "Power Purchase Agreement – konventionell",
            definition: "Langfristiger bilateraler Liefervertrag (5–15 Jahre) fixiert Preis und Menge. Strukturierungsformen: Baseload-PPA (24/7), Peak-PPA (Werktags 8–20 Uhr), indexierter PPA (±Formel auf Gaspreis/CO₂). Konventionelle PPAs geben dem Erzeuger Cashflow-Planungssicherheit und ermöglichen günstige Restnutzungszeit-Finanzierung. Abnehmer sichern sich gegen Preisspitzen ab.",
            wertschoepfung: "Erzeuger monetarisiert Planungssicherheit – bankfähige Cashflows senken Finanzierungskosten. Für konventionelle Anlagen: Restlebenszeit-Optimierung ohne EEG. Abnehmer zahlt Risikopremium für Preissicherheit. Strukturierungsmarge beim Lieferanten.",
            herausforderungen: "Sinkende Spotpreise durch EE-Zubau können PPAs rückwirkend teuer machen. CO₂-Kosten senken Wettbewerbsfähigkeit gegenüber EE-PPAs. Kreditrisiko des Abnehmers über 10+ Jahre schwer einzuschätzen.",
            ausblick: "Konventionelle PPAs werden durch EE-PPAs verdrängt. Nische: Industriekunden mit 24/7-Baseload-Bedarf ohne Profilkomplexität. H2-ready Gaskraftwerke als Grundlage für 'grüne Flexibilitäts-PPAs'.",
            erloesmodell: "Festpreis / Floor-Cap-Struktur über Vertragslaufzeit",
            regulierung: "BGB, EnWG §42a, REMIT (ab 1 MWh)",
            kundensegment: "B2B Industrie, Energielieferanten",
            differenzierung: "Preissicherheit, Lieferzuverlässigkeit, Laufzeit, Kreditmanagement",
            status: "aktiv",
            radar: { regulierung:1, skalierbarkeit:2, marktrisiko:2, digitalisierung:1, wettbewerb:3, nachhaltigkeit:2 },
            erloesTyp: "Merchant", akteure: ["RWE","Uniper","EnBW"]
          }
        ]
      },
      {
        id: "L2-ERZ-EE", title: "Erneuerbare Energien",
        description: "Wind-, Solar- und Wasserkraftanlagen – zunehmend merchant-basiert mit Corporate PPAs als dominierendem Wachstumssegment.",
        actors: ["RWE Renewables","EnBW","Ørsted","Encavis","ABO Wind","Baywa r.e.","Vattenfall"],
        items: [
          {
            id: "L3-ERZ-EE-01", title: "EEG-Marktprämienmodell",
            definition: "Kerninstrument der deutschen Energiewende: Anlagen >100 kW müssen Strom direkt vermarkten und erhalten gleitende Marktprämie = anzulegender Wert (AW, aus BNetzA-Ausschreibung) minus monatlicher Referenzmarktwert (RMW). AW ist für 20 Jahre gesichert. Direktvermarkter (Next Kraftwerke, Statkraft, Axpo) bündeln 5.000–14.000 Anlagen und optimieren via hochauflösende Wetter-ML-Modelle und Intraday-Handel. Verwaltungskosten: 0,1–0,5 ct/kWh.",
            wertschoepfung: "Kombination aus staatlich gesichertem AW (Planungssicherheit) + Upside bei hohen Spotpreisen. Für Direktvermarkter: Managementfee ~0,2 ct/kWh + Outperformance-Share. Outperformance entsteht durch bessere stündliche Prognosen als der pauschale Monats-RMW. Skaleneffekte: 10 GW-Portfolio reduziert Prognosefehler durch Diversifikation (Wind Nord/Solar Süd) auf ~2–3%.",
            herausforderungen: "AW aus Ausschreibungen sinken durch Wettbewerb – neue Anlagen erzielen niedrigere Förderung. §51 EEG: Kein AW bei negativen Preisen >6h – bei steigendem EE-Anteil immer häufiger. Redispatch-Ausfallarbeit belastet Erzeuger. Direktvermarktungsmarkt wird oligopolistisch (Next/RWE dominiert mit >35% Marktanteil).",
            ausblick: "Bis 2028 laufen erste EEG-Altanlagen (IBN 2000–2005) aus. Repowering-Welle oder Merchant-Betrieb. Solar-LCOE <25 €/MWh (2026) macht merchant economics attraktiv. Direktvermarktungsmarkt konsolidiert weiter auf 3–5 Anbieter.",
            erloesmodell: "EEG-Marktprämie (staatlich) + Spotmarkterlös + Intraday-Optimierung",
            regulierung: "EEG 2023 §20–§53, BNetzA-Ausschreibungen, MaBiS",
            kundensegment: "Direktvermarkter, ÜNB (EinsMan/Redispatch)",
            differenzierung: "Prognosegüte (ML-Wettermodell), Portfoliogröße, Intraday-Handelsautomatisierung",
            status: "aktiv",
            radar: { regulierung:4, skalierbarkeit:3, marktrisiko:2, digitalisierung:3, wettbewerb:2, nachhaltigkeit:5 },
            erloesTyp: "Reguliert", akteure: ["RWE Renewables","EnBW","Ørsted","Encavis"]
          },
          {
            id: "L3-ERZ-EE-02", title: "Corporate PPA (Erneuerbare)",
            definition: "Direktvertrag zwischen EE-Anlagenbetreiber und Industriekunden ohne staatliche Förderung. Zwei Formen: (1) Physical PPA – physische Lieferung, Anlage ist Lieferant. (2) Financial PPA (CfD) – Anlage verkauft an Markt, Differenz zwischen Strike Price und EPEX wird bilateral ausgeglichen. Financial PPAs dominieren in Deutschland. Laufzeit: 10–15 Jahre, Strike Price 2024: 40–70 €/MWh Onshore Wind. Getrieben durch RE100-Commitments (BASF, BMW, Deutsche Bahn, Microsoft, Google).",
            wertschoepfung: "Anlagenbetreiber: Bankfähige Cashflows für Projektfinanzierung ohne EEG, niedrigere Kapitalkosten als merchant (~1–2% Zinsvorteil = signifikant bei 20-j. Laufzeit). Industriekunde: Preishedge gegen steigende Energiekosten + RE100-Erfüllung + CSRD-Scope-2-Optimierung. Additionality (neue Anlage, kein Bestandsprojekt) als Differenzierungsmerkmal.",
            herausforderungen: "Shape-Risiko: EE-Profil passt selten zu Industrielast (Produktion nachts, Solar tagsüber). Residualbeschaffung notwendig. Bonitätsprüfung über 10+ Jahre aufwendig – Kreditversicherung verteuert Produkt. Sinkende Spot-Preise könnten Strike Price rückwirkend teuer erscheinen lassen.",
            ausblick: "PPA-Markt wächst stark (EU-Ziel >2 GW/Jahr neue PPA-Kapazität). EFET-Standardverträge senken Transaktionskosten. Aggregierte PPAs (mehrere kleinere Abnehmer = ein PPA) als neues Strukturierungsmodell für KMU. Sektorale PPAs (Stahl-H2-PPA, Rechenzentrum-PPA) entstehen.",
            erloesmodell: "Strike Price (CfD-Differenzausgleich) oder physischer Festpreis",
            regulierung: "BGB, EU RED III, REMIT (Meldepflicht), EnWG §42a",
            kundensegment: "B2B Industrie (DAX, Tech, RE100-Mitglieder)",
            differenzierung: "Additionality-Nachweis, Profilqualität, Laufzeit, Kreditstruktur",
            status: "aktiv",
            radar: { regulierung:1, skalierbarkeit:3, marktrisiko:2, digitalisierung:2, wettbewerb:3, nachhaltigkeit:5 },
            erloesTyp: "Merchant", akteure: ["Ørsted","RWE Renewables","Baywa r.e.","Encavis"]
          },
          {
            id: "L3-ERZ-EE-03", title: "Offshore-Wind-Projektentwicklung",
            definition: "Kapitalintensivste EE-Projektkategorie: 2.500–4.000 €/kW installierter Leistung, Projektlaufzeiten 20–30 Jahre. In Deutschland BNetzA-Ausschreibungen mit Gebotspreisverfahren. Wertschöpfungskette: Standortgutachten → BSH-Genehmigung → Ausschreibungsgewinn → Projektfinanzierung → EPC → 20 Jahre Betrieb → O&M. Volllaststunden Nordsee: 4.000–4.500 h/a. Deutsche Offshore-Ziele: 30 GW bis 2030, 70 GW bis 2045 (derzeit ~8 GW).",
            wertschoepfung: "Gesicherte 20-j. Cashflows aus EEG-Ausschreibungsgebotspreis. Skaleneffekte durch Serienentwicklung. Netzanschluss-Genehmigungen (Netzverknüpfungspunkte) als proprietärer Engpass. O&M-Marge (20–25% der Projekterlöse) ist profitabelste Phase. Floating-Wind-Entwicklungskompetenz als Zukunftsinvestition.",
            herausforderungen: "Lieferkettenengpässe: Siemens Gamesa-Qualitätsprobleme, Turbinenpreise +30–50% seit 2021. Gestiegene Zinsen machen Nullgebots-Projekte (Ørsted 2021) unrentabel. BSH-Genehmigungsverfahren dauern 3–5 Jahre trotz Beschleunigung. Naturschutz (Vogelzug, Riffschutz) als Genehmigungsrisiko.",
            ausblick: "Offshore-Boom unvermeidbar: 30 GW Ziel bis 2030. Floating Offshore Wind (FLOW) ab 2030+ kommerziell. 15–20 MW+ Turbinen senken LCOE auf <40 €/MWh. Nordsee als europäische Energiedrehscheibe (H2-Offshore-Produktion, direkte Gleichstromkabel nach Süddeutschland).",
            erloesmodell: "EEG-Ausschreibungsgebotspreis (€/MWh, 20 Jahre gesichert)",
            regulierung: "WindSeeG, EEG 2023, BSH (Bundesamt Seeschifffahrt), BNetzA-Ausschreibungen",
            kundensegment: "ÜNB (Offshore-Netzanschluss), Börse (Stromverkauf)",
            differenzierung: "Genehmigungskompetenz, Serieneffekte, Netzanschluss-Zugänge, O&M-Netz",
            status: "aktiv",
            radar: { regulierung:4, skalierbarkeit:2, marktrisiko:2, digitalisierung:3, wettbewerb:2, nachhaltigkeit:5 },
            erloesTyp: "Reguliert", akteure: ["Ørsted","RWE Offshore","EnBW Offshore","Vattenfall"]
          },
          {
            id: "L3-ERZ-EE-04", title: "Bürgerenergiegenossenschaft",
            definition: "Genossenschaftlich organisierter EE-Betrieb nach GenG. Mitglieder ab 100–500 € Einlage sind Kapitalgeber, Kunden und Mitbestimmungsberechtigte. EWS Schönau (1994 gegründet, ~55.000 Kunden), BürgerEnergie Berlin, Green Planet Energy als Beispiele. Besonderheit: Zweckrationalität statt Gewinnmaximierung. Überschüsse werden reinvestiert oder als moderate Dividende ausgeschüttet. Politisches Profil (Anti-Atomkraft, Energiewende-Pioniere) ist integraler Markenkern.",
            wertschoepfung: "Identifikations-Premium: Mitglieder zahlen mehr und wechseln kaum. Strukturell niedriger Churn (<5%/Jahr vs. 15–25% bei Discountern). Günstiger Kapitalzugang über Genossenschaftseinlagen. EU Energy Communities (§3 Nr. 38a EnWG) schaffen neue Geschäftsmodelloptionen: P2P-Handel, lokale Netzentgelteinsparungen.",
            herausforderungen: "Skalierungshürde durch demokratische Entscheidungsstrukturen. Professionalisierungsdruck durch digitale Neolieferanten (Tibber, Ostrom). Nachfolgeproblematik bei gründergetriebenen Genossenschaften (EWS Schönau: Bürgerinitiative von 1994 muss Generationenwechsel managen).",
            ausblick: "EU EMD Energy Communities als Wachstumstreiber: lokale Energiegemeinschaften können direkte Solarstromabrechnung innerhalb der Community organisieren. Politisches Momentum wächst. Kombination mit kommunaler Wärmeplanung (WPG) eröffnet Genossenschafts-Fernwärme als neues Feld.",
            erloesmodell: "EEG-Marktprämie + Retail Margin + Genossenschaftsdividende (reinvestiert)",
            regulierung: "EEG, GenG, EnWG §3 Nr. 15, EU EMD (Energy Communities)",
            kundensegment: "B2C Bürger / Mitglieder (werteorientiert)",
            differenzierung: "Gemeinwohl, Lokalität, demokratische Mitbestimmung, Authentizität",
            status: "aktiv",
            radar: { regulierung:2, skalierbarkeit:1, marktrisiko:2, digitalisierung:1, wettbewerb:1, nachhaltigkeit:5 },
            erloesTyp: "Fee-based", akteure: ["EWS Schönau","BürgerEnergie Berlin","Green Planet Energy"]
          }
        ]
      },
      {
        id: "L2-ERZ-SPEICHER", title: "Speicher & Flexibilität",
        description: "Batterietechnologien als eigenständige Geschäftsmodelle – Erlösstacking als Kernstrategie.",
        actors: ["Fluence","NEOEN","Sonnen (Shell)","EnBW","SENEC","E3/DC"],
        items: [
          {
            id: "L3-ERZ-SPEICHER-01", title: "Grid-Scale Battery (BESS)",
            definition: "Großbatteriespeicher (10–500 MW, 1–4h Kapazität) erzielen Erlöse durch simultanes Stacking: (1) FCR-Leistungspreis: 8–25 €/MW/h (2024), attraktivste Einzelkomponente. (2) Intraday-Arbitrage: Kauf bei niedrigen EE-Einspeisephasen, Verkauf in Abendpeaks – Spread 15–50 €/MWh. (3) aFRR/mFRR als Ergänzung. Optimierungssoftware entscheidet stündlich, welcher Markt höhere Grenzerlöse bietet. Capex 2024: 400–600 €/kWh (Li-Ion LFP), Lernrate ~15%/Verdopplung.",
            wertschoepfung: "Optimierungsalgorithmus ist der eigentliche Wettbewerbsvorteil, nicht die Hardware. Schlechte Software lässt 30–50% theoretischer Erlöse liegen. Arbitrage-Spread wächst mit EE-Anteil (mehr Phasen mit negativen Preisen, höhere Abendflanken). Degradationsmanagement (optimaler SOC, Temperaturbetrieb) verlängert Lebensdauer und verbessert IRR.",
            herausforderungen: "FCR-Preisverfall durch BESS-Überangebot ist strukturell: FCR-Preis von >30 €/MW/h (2021) auf <10 €/MW/h (Tiefs 2024). Batteriedegradation nach 3.000–5.000 Zyklen. Brandschutzanforderungen (VdS 3527) erhöhen Betriebskosten. Netzanschlussengpässe begrenzen Standortwahl.",
            ausblick: "BESS-Markt wächst explosiv (Europa: 100+ GW bis 2030). Arbitrage-Erlöse steigen mit Preisspread. Duration-Erweiterung auf 6–8h (Long Duration Storage) als nächste Stufe. Iron-Air- und Flow-Batterien für saisonale Speicherung. Co-location mit Solar/Wind reduziert Netzanschlusskosten erheblich.",
            erloesmodell: "FCR/aFRR Leistungspreis (€/MW/h) + Intraday-Arbitrage (€/MWh)",
            regulierung: "EnWG §118, SOGL Art. 154, MsbG (Metering), BNetzA Speicherregulierung",
            kundensegment: "Großhandel, ÜNBs (Regelenergiemärkte)",
            differenzierung: "Optimierungsalgorithmus, Response Time, Zyklenanzahl, Multi-Market-Stacking",
            status: "aktiv",
            radar: { regulierung:1, skalierbarkeit:3, marktrisiko:4, digitalisierung:5, wettbewerb:3, nachhaltigkeit:4 },
            erloesTyp: "Merchant", akteure: ["Fluence","NEOEN","EnBW","RWE","Habitat Energy"]
          },
          {
            id: "L3-ERZ-SPEICHER-02", title: "Heimspeicher als VPP-Baustein",
            definition: "Hersteller wie Sonnen (Shell-Tochter) und SENEC (EnBW) vermarkten Heimspeicher (5–20 kWh) als Eintritt in ein virtuelles Kraftwerk. Kunden kaufen Hardware (3.000–8.000 €) und treten einen Teil der freien Kapazität (z.B. 20% SOC) an den Aggregator ab. Aggregator bündelt Tausende Einheiten zu präqualifiziertem Regelenergie-Asset. Erlösteilung: Aggregator 60–70%, Endkunde 30–40%. Incentive: Sonnen-Flatrate-Tarif – Kunde zahlt fixen Monatsbetrag statt kWh-Preis.",
            wertschoepfung: "Hardware-Marge als Einmalerlös (20–30%). Langfristiger Wert: jede Einheit ist dauerhafter VPP-Baustein. Flatrate-Tarif bindet Kunden multi-jährig (Churn <5%). Portfolioeffekte: 10.000 Heimspeicher = ~100 MWh Flex-Kapazität für FCR-Präqualifikation. Ökosystemschranke: Hardware + Tarif + VPP = hohe Wechselhürde.",
            herausforderungen: "Skalenaufbau kostenintensiv (Installation, Netzanmeldung, SMGW-Anbindung je Einheit). §14a EnWG schafft VNB-seitige Steuerung – potenzielle Konflikte mit VPP-Aggregator. FCR-Preisverfall senkt VPP-Mehrwert für Kunden. Qualitätssicherung des VPP bei heterogener Hardware-Basis.",
            ausblick: "V2G als massive Erweiterung: EV-Batterie (~60 kWh) = 3–5× größer als Heimspeicher. Aggregatoren mit frühzeitigen OEM-Partnerschaften (VW/Elli, Hyundai) gewinnen strukturellen Vorteil. EU EMD Energy Communities ermöglichen P2P-Abrechnung zwischen Heimspeicher-Besitzern.",
            erloesmodell: "Geräteverkauf + Revenue-Share (Regelenergie) + Flatrate-Tarifbindung",
            regulierung: "EEG §9, MsbG, EnWG §14a, SOGL Präqualifikation",
            kundensegment: "B2C Prosumer (PV-Eigenheim)",
            differenzierung: "Community-Größe, Flatrate-Attraktivität, VPP-Optimierungsgüte, Hardware-Qualität",
            status: "aktiv",
            radar: { regulierung:2, skalierbarkeit:4, marktrisiko:2, digitalisierung:5, wettbewerb:3, nachhaltigkeit:4 },
            erloesTyp: "Subscription", akteure: ["Sonnen (Shell)","SENEC (EnBW)","E3/DC","Sungrow"]
          }
        ]
      }
    ]
  },

  // ══════════════════════════════════════════════════════════
  // L1: ÜBERTRAGUNGSNETZ (ÜNB / TSO)
  // ══════════════════════════════════════════════════════════
  {
    id: "L1-UNB", title: "Übertragungsnetz (ÜNB / TSO)", icon: "🔌", color: "#3B82F6",
    description: "Die vier deutschen ÜNBs stehen vor der größten Investitionsperiode ihrer Geschichte – 50+ Mrd. € Netzausbau bis 2035.",
    capabilities: [
      {
        id: "L2-UNB-NETZ", title: "Netzbetrieb & Systemführung",
        description: "50-Hz-Frequenzhaltung, Engpassmanagement und Systemstabilität – zunehmend komplex durch volatile EE-Einspeisung.",
        actors: ["50Hertz Transmission","Amprion","TenneT TSO","TransnetBW"],
        items: [
          {
            id: "L3-UNB-NETZ-01", title: "Reguliertes Netznutzungsentgelt (ARegV)",
            definition: "ÜNBs finanzieren sich über BNetzA-genehmigte Erlösobergrenze (EOG). Berechnung: anerkannte Kapitalkosten (kalkulatorische EK-Rendite: 6,91% vor Steuer Altanlagen, 5,07% Neuanlagen) + anerkannte Betriebskosten. Effizienzvergleich (Benchmarking) zwischen Netzbetreibern bestimmt individuellen Effizienzwert. Netzentgelt = EOG / transportierte Energiemenge. HGÜ-Investitionen (SuedLink 5 Mrd. €, SuedOstLink 3 Mrd. €, A-Nord 3 Mrd. €) erhöhen RAB und damit zulässige Erlöse.",
            wertschoepfung: "Regulierte EK-Rendite als gesicherter Return – kein Marktrisiko, aber Regulierungsrisiko. TOTEX-Regulierung (seit RP3) incentiviert Opex-Effizienz: Wer Betriebskosten senkt, behält Einsparungen 5 Jahre. Investitionsprogramme erhöhen RAB und damit Erlösbasis: Jeder € investiert in Netzinfrastruktur generiert regulierten Renditezufluss über 35-40 Jahre.",
            herausforderungen: "Netzausbau hinkt EE-Zubau 5–10 Jahre hinterher: Redispatch-Kosten >4 Mrd. €/Jahr (2023) belasten Verbraucher. Genehmigungsverfahren für neue Trassen: 10–15 Jahre (Planfeststellung). IT-Infrastruktur und Cybersecurity (KRITIS, NIS2) erfordern massive Investitionen. Personalmangel bei Netzplaningenieuren.",
            ausblick: "HGÜ-Backbone verändert Netzstruktur fundamental. OEAG (Offshore Energy Anschluss GmbH als Sondervermögen) für Offshore-Netzanbindung. Digitaler Zwilling des Übertragungsnetzes als Planungs- und Betriebsgrundlage. Europäische Vernetzung (NordLink, Cobra Cable) schafft neue Koordinationsaufgaben.",
            erloesmodell: "Regulierte Netzentgelte nach ARegV (§21 EnWG)",
            regulierung: "ARegV, StromNEV, EnWG §21ff., BNetzA Beschlusskammern",
            kundensegment: "VNB, Direktanschluss-Industrie, Kraftwerke",
            differenzierung: "Effizienzgrad im BNetzA-Benchmarking, Investitionsdisziplin, Netzqualität (SAIDI)",
            status: "aktiv",
            radar: { regulierung:5, skalierbarkeit:1, marktrisiko:1, digitalisierung:2, wettbewerb:1, nachhaltigkeit:3 },
            erloesTyp: "Reguliert", akteure: ["50Hertz","Amprion","TenneT TSO","TransnetBW"]
          },
          {
            id: "L3-UNB-NETZ-02", title: "Redispatch 2.0 & Engpassmanagement",
            definition: "Seit Oktober 2021: ÜNBs und VNBs koordinieren Einspeisemanagement und Redispatch über standardisierte Datenkommunikation. Alle Anlagen >100 kW sind meldepflichtig. ÜNB weist Erzeuger an: Einsatz-Up (Einspeisung erhöhen) oder Einsatz-Down (Einspeisung reduzieren) zur Netzentlastung. Ausfallarbeit wird erstattet (EEG-Vergütung auch bei Abregeln). Kosten 2023: ca. 4,1 Mrd. € – Rekord. Datenaustausch über GABI-Software, CLS-Kommunikation, BDEW-Leitfaden.",
            wertschoepfung: "Für ÜNBs kein Erlösmodell, sondern Kostenblock – wird über Netzentgelte socialisiert. ÜNBs mit besserer Prognose-/Optimierungssoftware minimieren Redispatch-Kosten. Systemeffizienz ist Regulierungsnachweis und politisches Signal. Datenqualität aus Redispatch ist Basis für Netzplanung (Schwachstellen identifizieren).",
            herausforderungen: "Kosten steigen exponentiell mit EE-Ausbau solange Netzausbau hinterherhinkt. Koordination mit 900+ VNBs datentechnisch extrem komplex. Anreizproblem: ÜNBs leiten Redispatch-Kosten durch – kein starker finanzieller Anreiz zur Minimierung. Haftungsfragen bei Fehlkoordination.",
            ausblick: "Automatisierung der Koordination via digitale Plattformen. Market-Based Congestion Management (EU-Diskussion) könnte Redispatch teilweise durch Marktmechanismen ersetzen. Mit SuedLink/SuedOstLink (2028) sollten Nord-Süd-Engpässe strukturell gelöst werden. §14a DSO-Steuerung entlastet ÜNBs auf unteren Netzebenen.",
            erloesmodell: "Kostenerstattung (regulierter Kostenblock, socialisiert via Netzentgelt)",
            regulierung: "EnWG §13, §14, RedispatchVO (Strom), BDEW-Leitfaden RD 2.0",
            kundensegment: "VNB, Direktanlagenbetreiber, EE-Direktvermarkter",
            differenzierung: "Prozessautomatisierung, Prognosequalität, Systemintegration",
            status: "aktiv",
            radar: { regulierung:5, skalierbarkeit:1, marktrisiko:1, digitalisierung:4, wettbewerb:1, nachhaltigkeit:3 },
            erloesTyp: "Reguliert", akteure: ["50Hertz","Amprion","TenneT TSO","TransnetBW"]
          },
          {
            id: "L3-UNB-NETZ-03", title: "Bilanzkreismanagement & Ausgleichsenergie",
            definition: "Bilanzkreissystem als finanzielle Architektur des Strommarkts: Jeder Lieferant/Händler führt Bilanzkreis beim ÜNB. Stündlicher Ausgleich von Einspeisung und Entnahme Pflicht. Abweichungen = Ausgleichsenergie (AE): Unterdeckung zahlt AE-Preis; Überdeckung erhält AE-Vergütung. MaBiS-Reform (BK6-24-174): EDIFACT-basierter Datenaustausch wird durch API-basierte Echtzeit-Kommunikation ersetzt. Schrittweise Einführung bis 2027.",
            wertschoepfung: "AE-System ist Nullsummen-Durchleitungsmodell für ÜNBs. Wert: ÜNBs mit modernen API-Systemen (MaBiS 2.0) senken Prozesskosten und erhöhen Datenqualität. Gut funktionierendes BKM ermöglicht günstigere Regelenergiebeschaffung durch präzisere Prognosebasis.",
            herausforderungen: "Datenqualität ist systemkritisch – fehlerhafte Einspeisemeldungen gefährden Netzsicherheit. Legacy-Systeme (SAP IS-U, EDIFACT) in allen ÜNBs erfordern massive IT-Transformation. Wachsende Marktteilnehmer (VPP-Aggregatoren, iMSBs) erhöhen Datenkomplexität exponentiell. Harmonisierung zwischen vier ÜNB-Systemen ist regulatorisch geboten, technisch komplex.",
            ausblick: "15-Minuten-Bilanzierung (statt stündlich) ist EU-Ziel – erfordert vollständig neue Abrechnungsinfrastruktur. Echtzeit-BKM als Basis für Dynamic-Line-Rating und N-1-Optimierung. EU-Harmonisierung der BKM-Prozesse über ENTSO-E als langfristiges Ziel.",
            erloesmodell: "Durchleitungsmodell (AE-Nullsumme); Prozesskosten via Netzentgelt",
            regulierung: "MaBiS (BK6-24-174), StromNZV §4ff., GPKE, EDI@Energy",
            kundensegment: "Bilanzkreisverantwortliche (BKV), Lieferanten, EE-Direktvermarkter",
            differenzierung: "API-Reife (MaBiS 2.0), Echtzeit-Fähigkeit, Datenqualität",
            status: "aktiv",
            radar: { regulierung:5, skalierbarkeit:1, marktrisiko:1, digitalisierung:4, wettbewerb:1, nachhaltigkeit:2 },
            erloesTyp: "Reguliert", akteure: ["50Hertz","Amprion","TenneT TSO","TransnetBW"]
          }
        ]
      }
    ]
  },

  // ══════════════════════════════════════════════════════════
  // L1: VERTEILNETZ (VNB / DSO)
  // ══════════════════════════════════════════════════════════
  {
    id: "L1-VNB", title: "Verteilnetz (VNB / DSO)", icon: "🏘️", color: "#10B981",
    description: "Ca. 900 VNBs in Deutschland – unter massivem Transformationsdruck durch Wärmepumpen, EV und Solarausbau. Investitionsbedarf bis 2045: 375 Mrd. €.",
    capabilities: [
      {
        id: "L2-VNB-KLASSISCH", title: "Klassischer Netzbetrieb",
        description: "Reguliertes Monopol auf MS/NS-Ebene – Kerngeschäft unter wachsendem Capex-Druck.",
        actors: ["Bayernwerk Netz","Westnetz","E.DIS Netz","SWM Infrastruktur","Netze BW","mitnetz"],
        items: [
          {
            id: "L3-VNB-KLASSISCH-01", title: "Reguliertes Netzentgelt (Verteilnetz)",
            definition: "ARegV-Regulierung analog ÜNBs, aber mit fundamental anderer Kostenstruktur: 85–90% der Kosten sind Kapital- und Fixkosten (netzlängenabhängig, nicht mengenabhängig). Deutschland: ~1,8 Mio. km Leitungsnetz auf Verteilnetzebene. EK-Rendite: 5,07% nominal (Neuanlagen). 4. Regulierungsperiode (ab 2024) stärkt Investitionsanreize durch verbesserte TOTEX-Regulierung und erhöhte kalkulatorische EK-Basis.",
            wertschoepfung: "Gesicherter Return auf RAB. Wertschöpfung durch: (1) Kapitalallokation – jeder investierte Euro erhöht RAB und erlaubte Erlöse. (2) Effizienz – Betrieb unterhalb Referenzwert erhöht individuelle Marge. (3) Netzqualität – SAIDI-Minuten sind regulatorisch incentiviert (Bonus bei Unterschreitung). Stabilste Erlösbasis aller Energiewirtschafts-Segmente.",
            herausforderungen: "Massiver Investitionsbedarf: Wärmepumpen und EV verdoppeln/verdreifachen NS-Netzlasten lokal. BNetzA schätzt VNB-Investitionsbedarf bis 2045 auf 375 Mrd. €. Fachkräftemangel (Elektriker, Netzplaner). Genehmigungsdauer für Netztrassen. Finanzierungslücke: Regulierung hinkt Investitionsbedarf systematisch hinterher.",
            ausblick: "DSOs entwickeln sich von passiven Netzbetreibern zu aktiven System-Operatoren (Active System Management, ASM). §14a EnWG ist erster regulatorischer Schritt. Digitalisierung bis NS-Ebene (Sensorik, SCADA, DER-Management) wird zur Pflicht. Konsolidierung: Kleine Stadtwerke geben Netze ab – 900 VNBs werden auf 200–300 konsolidieren bis 2040.",
            erloesmodell: "ARegV-Netzentgelte (§21 EnWG, StromNEV, 4. Regulierungsperiode)",
            regulierung: "ARegV, StromNEV, EnWG §21, BNetzA – 4. Regulierungsperiode ab 2024",
            kundensegment: "Letztverbraucher (indirekt via Lieferant), Anlagenbetreiber, Ladepunkte",
            differenzierung: "Effizienz-Benchmark, SAIDI-Qualität, Capex-Timing, Digitalisierungsgrad",
            status: "aktiv",
            radar: { regulierung:5, skalierbarkeit:1, marktrisiko:1, digitalisierung:2, wettbewerb:1, nachhaltigkeit:3 },
            erloesTyp: "Reguliert", akteure: ["Bayernwerk Netz","Westnetz","E.DIS Netz","Netze BW"]
          },
          {
            id: "L3-VNB-KLASSISCH-02", title: "Messstellenbetrieb (iMSB / gMSB)",
            definition: "MsbG trennt Messstellenbetrieb regulatorisch vom Netzbetrieb. Grundzuständiger MSB (gMSB) = VNB per Default. Wettbewerblicher iMSB kann durch Angebot an Letztverbraucher verdrängen. iMSys = SMGW (Smart Meter Gateway, BSI TR-03109 zertifiziert) + Zähler. SMGW kommuniziert über LMN mit Messtechnik, über WAN mit Marktkommunikationspartnern. Pflicht-Rollout: >6.000 kWh/a ab 2025, >3.000 kWh/a ab 2027, EE/KWK ab 7 kW ab 2025. MSB-Entgelte §31 MsbG: 20–100 €/Jahr je Messstelle.",
            wertschoepfung: "gMSB (VNB): Stabile regulierte Entgelte, niedriges Risiko. Mehrwert durch Datenservices (Lastganganalyse, PV-Monitoring, §14a-Integration) über Mindestentgelt hinaus. iMSB: Differenzierung über Service und Datenintegration. SMGW als IoT-Gateway: zukünftig Basis für Gas, Wärme, Wasser-Integration.",
            herausforderungen: "BSI-Zertifizierung (TR-03109) dauerte jahrelang und verzögerte Markteintritt massiv. Nur wenige SMGW-Hersteller auf Markt (Sagemcom, Theben, Landis+Gyr, EMH). LMN-Kommunikation im Altbaubestand technisch schwierig. DSGVO schränkt Nutzung hochauflösender Daten ein. Rollout bleibt hinter Plan.",
            ausblick: "SMGW als Infrastruktur für dynamische Tarife (§41b), §14a-Steuerung, V2G. Plattformökonomie: iMSBs mit integrierten EMS-Plattformen werden Multi-Utility-Gateways. Markt konsolidiert sich: wenige große iMSBs mit skalierten Plattformen dominieren.",
            erloesmodell: "MSB-Entgelte (§31 MsbG, reguliert) + Mehrwertdienste",
            regulierung: "MsbG, BSI TR-03109, §21b EnWG, DSGVO",
            kundensegment: "Letztverbraucher, EE-Anlagenbetreiber, Lieferanten",
            differenzierung: "BSI-Zertifizierung, Rollout-Tempo, Datenservices, §14a-Readiness",
            status: "aktiv",
            radar: { regulierung:4, skalierbarkeit:2, marktrisiko:1, digitalisierung:5, wettbewerb:2, nachhaltigkeit:2 },
            erloesTyp: "Reguliert", akteure: ["Bayernwerk Netz","Westnetz","discovergy","emonvia","EMH metering"]
          }
        ]
      },
      {
        id: "L2-VNB-NEU", title: "Neue DSO-Geschäftsfelder",
        description: "Aktives Netzmanagement und Infrastrukturservices – DSOs als Plattformbetreiber.",
        actors: ["Bayernwerk Netz","Stromnetz Berlin","mitnetz strom","Netze BW"],
        items: [
          {
            id: "L3-VNB-NEU-01", title: "§14a EnWG – Steuerbare Verbrauchseinrichtungen",
            definition: "BNetzA-Festlegung BK6-22-300 (in Kraft seit 1.1.2024): VNBs dürfen sVEs – Wärmepumpen, EV-Lader >11 kW, Klimaanlagen, Batteriespeicher – bei lokalen Netzengpässen temporär auf 4,2 kW dimmen ('Modulationsrahmen'). Limite: max. 2h am Stück, max. 50% Jahresstunden ohne Einhaltung der Mindestleistung. Gegenleistung für Kunden: 100–190 €/Jahr Netzentgelnachlass (Modell 1) oder reduzierter Arbeitspreis (Modell 2). Kommunikation via CLS über SMGW oder direkten CLS-Kanal.",
            wertschoepfung: "Direkte Kostenersparnis: Trafo-Upgrade (30.000–100.000 €) durch Lastmanagement vermieden. Smart-Grid-Investition (CLS-Infrastruktur) ist regulatorisch als 'besondere netztechnische Betriebsmittel' anerkannt – erhöht RAB. Indirekter Wert: Mehr sVE-Anschlüsse möglich ohne proportionalen Capex = Volumenwachstum bei flacherer Kostenkurve.",
            herausforderungen: "SMGW-basierte CLS-Kommunikation setzt flächendeckenden Smart-Meter-Rollout voraus. Alternative CLS-Kanäle (Mobilfunk, Direktverbindung) mit eigenen Hürden. Kundenkommunikation: 'Dimmung' erklärungsbedürftig. Koordination mit Aggregatoren (Doppelsteuerung vermeiden) regulatorisch noch nicht gelöst.",
            ausblick: "§14a ist Einstieg in 'Flex-first'-Netzbetrieb. Erweiterung auf industrielle Lasten und Großspeicher folgt. Lokale Flexibilitätsmärkte (VNB kauft Flex von Aggregatoren statt Netz auszubauen) als nächste Evolutionsstufe. EU Clean Energy Package verpflichtet DSOs mittelfristig zu Flex-Beschaffung vor Netzverstärkung.",
            erloesmodell: "Capex-Vermeidung (indirekt) + regulatorisch anerkannte Smart-Grid-RAB",
            regulierung: "EnWG §14a, BNetzA BK6-22-300, MsbG",
            kundensegment: "Prosumer / Haushaltskunden mit sVE (EV, WP, Speicher)",
            differenzierung: "CLS-Rollout, SMGW-Anbindungsquote, Koordination mit Aggregatoren",
            status: "aktiv",
            radar: { regulierung:4, skalierbarkeit:3, marktrisiko:1, digitalisierung:5, wettbewerb:1, nachhaltigkeit:4 },
            erloesTyp: "Reguliert", akteure: ["Bayernwerk Netz","Netze BW","Stromnetz Berlin","E.DIS"]
          }
        ]
      }
    ]
  },

  // ══════════════════════════════════════════════════════════
  // L1: GAS & WASSERSTOFFNETZ
  // ══════════════════════════════════════════════════════════
  {
    id: "L1-GAS", title: "Gas & Wasserstoffnetz", icon: "🔵", color: "#6366F1",
    description: "FNB Gas im strategischen Transformationsprozess: Erdgas-Infrastruktur wird zur Wasserstoff-Backbone-Infrastruktur Europas.",
    capabilities: [
      {
        id: "L2-GAS-FNB", title: "Fernleitungsnetzbetreiber Gas (FNB)",
        description: "Reguliertes Hochdruckgasnetz mit H2-Transformationsperspektive.",
        actors: ["Open Grid Europe (OGE)","Gascade","Bayernets","Terranets BW","Ontras","Thyssengas"],
        items: [
          {
            id: "L3-GAS-FNB-01", title: "Reguliertes Gastransportnetz",
            definition: "FNB Gas betreiben ~40.000 km Hochdruckfernleitungsnetz (16–100 bar) unter ARegV-Regulierung (GasNEV). Struktur analog Strom-ÜNBs: BNetzA-genehmigte EOG auf Basis RAB + Effizienzvergleich. Kapazitätsbuchungen über PRISMA-Plattform (EU). Technische Basis: Kompressorstationen alle 150–200 km, SCADA/EMS, Pipelineintegrität. Entry/Exit-Netzentgelte getrennt.",
            wertschoepfung: "Regulierter Return auf RAB – gesichert, aber mit Transformationsrisiko. FNBs, die früh in H2-Readiness investieren (Stahlgütenachweis, Verdichterumbau) positionieren sich für regulatorisch anerkannte H2-Kernnetz-Investitionen. Grenzüberschreitende Kapazitäten (ICs) erzielen höhere Buchungspreise durch internationalen Gashandel.",
            herausforderungen: "Fundamentale Geschäftsmodellunsicherheit bei vollständiger Dekarbonisierung: Erdgas-Durchleitung sinkt auf null. Stranded-Asset-Risiko für nicht H2-geeignete Rohre. Investitionsdilemma: Erdgas-Infrastruktur modernisieren oder auf H2 wechseln? Regulatorischer Übergangszeitraum noch nicht vollständig definiert.",
            ausblick: "H2-Kernnetz (9.700 km, BNetzA 2024 genehmigt) transformiert die FNB-Branche. ~60% Repurposing bestehender Gasleitungen – FNBs mit geeignetem Rohrnetz haben strukturellen Vorteil. Amortisationsmodell: staatliche Anschubfinanzierung bis H2-Markt reif. European Hydrogen Backbone (EHB: 53.000 km bis 2040) als europäische Einbettung.",
            erloesmodell: "Regulierte Entry/Exit-Entgelte (GasNEV, ARegV)",
            regulierung: "EnWG §21, GasNEV, ARegV, BNetzA, EU-Gasmarkt-VO, EnWG H2-Novelle",
            kundensegment: "Gaslieferanten, Industrie, VNB Gas, H2-Erzeuger (zukünftig)",
            differenzierung: "H2-Readiness (Rohrmaterial), Repurposing-Kompetenz, Netzlage (Nordsee-Ruhrgebiet)",
            status: "aktiv",
            radar: { regulierung:5, skalierbarkeit:1, marktrisiko:1, digitalisierung:2, wettbewerb:1, nachhaltigkeit:2 },
            erloesTyp: "Reguliert", akteure: ["OGE","Gascade","Bayernets","Terranets BW","Ontras"]
          },
          {
            id: "L3-GAS-FNB-02", title: "Wasserstoff-Kernnetz (H2-Backbone)",
            definition: "BNetzA-genehmigtes H2-Kernnetz (2024): 9.700 km verbinden Erzeuger (Nordsee-Elektrolyse, LNG/H2-Import-Terminals) mit Abnehmern (Ruhrgebiet, Bayern, Baden-Württemberg). Finanzierung: Amortisationskontomodell – FNBs investieren vorab, Rückfluss über H2-Netzentgelte nach Markt-Ramp-up; staatliche Absicherung für Restrisiken. ~60% Repurposing (bestehende Gasleitungen), ~40% Neubau. Betrieb voraussichtlich durch bestehende FNB Gas.",
            wertschoepfung: "Infrastrukturmonopol auf einzigem nationalen H2-Transportnetz – wer das H2-Kernnetz betreibt, kontrolliert den zentralen Engpass für den deutschen H2-Markt der 2030er. Langfristige Kapitalrendite analog Erdgas-Netz, aber mit staatlicher Rückendeckung in der Ramp-up-Phase. First-Mover-Advantage für FNBs, die früh Repurposing-Kompetenz aufbauen.",
            herausforderungen: "Vollständig abhängig von H2-Marktentwicklung – wenn H2-Nachfrage hinter Erwartungen bleibt, entstehen massive Stranded Assets. Technische Unsicherheiten: H2-Embrittlement bei höherfestem Stahl. Verdichtertechnologie für H2 noch nicht vollständig industrialisiert. Marktentwicklung europaweit heterogen.",
            ausblick: "H2-Kernnetz vollständig operativ bis 2032. Internationale Vernetzung über EHB. Import-H2 aus Nordafrika, Naher Osten, Australien über Rotterdam/Hamburg. Bis 2030 erste Korridore (Nordsee–Ruhrgebiet) operativ. Schrittweiser H2-Preisverfall durch Skaleneffekte in Elektrolyse.",
            erloesmodell: "Regulierte H2-Netzentgelte (geplant) + staatliche Anschubfinanzierung",
            regulierung: "EnWG H2-Novelle, EU-Wasserstoffverordnung (2024), BNetzA H2-Regulierung",
            kundensegment: "H2-Erzeuger (Elektrolyseure), H2-Abnehmer (Stahl, Chemie, Mobilität)",
            differenzierung: "Netzlage (Nordsee-Achse), Repurposing-Kompetenz, Verdichtertechnologie H2",
            status: "emerging",
            radar: { regulierung:5, skalierbarkeit:2, marktrisiko:2, digitalisierung:3, wettbewerb:1, nachhaltigkeit:5 },
            erloesTyp: "Reguliert", akteure: ["OGE","Gascade","Bayernets","Ontras","Thyssengas"]
          }
        ]
      }
    ]
  },

  // ══════════════════════════════════════════════════════════
  // L1: ENERGIEHANDEL & PORTFOLIOMANAGEMENT
  // ══════════════════════════════════════════════════════════
  {
    id: "L1-HANDEL", title: "Energiehandel & Portfoliomanagement", icon: "📊", color: "#8B5CF6",
    description: "Börsen, proprietäre Trader und Portfolio-Manager – hochdigitalisiertes Segment, das durch EE-Volatilität strukturell wächst.",
    capabilities: [
      {
        id: "L2-HANDEL-BOERSE", title: "Börsenhandel & Clearing",
        description: "Marktplätze für standardisierte Energieprodukte.",
        actors: ["EPEX SPOT","EEX","Nasdaq Commodities","ECC (European Commodity Clearing)"],
        items: [
          {
            id: "L3-HANDEL-BOERSE-01", title: "Energiebörse (Exchange-Modell)",
            definition: "EPEX SPOT (Day-Ahead, Intraday kontinuierlich, Intraday-Auktionen) und EEX (Futures, Optionen, CO₂) betreiben regulierte Marktplätze. Erlös = Transaktionsgebühren (0,03–0,15 €/MWh je Produkt) + Clearinggebühren (via ECC) + Mitgliedsbeiträge. Netzwerkeffekte sind fundamental: Liquidität zieht Liquidität. Kein Marktpreisrisiko – reine Infrastrukturrolle. EPEX SPOT: >500 TWh Day-Ahead-Handel/Jahr in Deutschland.",
            wertschoepfung: "Plattform-Netzwerkeffekt: Jeder neue Teilnehmer erhöht Liquidität und damit den Wert für alle. Skaleneffekte in IT-Infrastruktur: marginale Kosten pro Transaktion sinken mit Volumen. Produktausweitung (Intraday-15-Minuten-Produkte seit 2018) schafft neue Erlösquellen bei wachsender EE-Volatilität.",
            herausforderungen: "Regulatorisches Umfeld: MiFID II, REMIT, EMIR erhöhen Compliance-Kosten. Technologische Disruption durch dezentralen Peer-to-Peer-Handel (Blockchain-basiert, noch marginal). Konsolidierungsdruck auf europäischer Ebene.",
            ausblick: "Volumen wächst mit EE-Anteil (mehr Intraday-Handel für Prognoseausgleich). 15-Minuten-Produkte werden Standard. H2-Futures und Flexibilitätsprodukte als neue Märkte. Echtzeit-Clearing als nächste Evolutionsstufe.",
            erloesmodell: "Transaktionsgebühren (€/MWh) + Clearing + Mitgliedsbeiträge",
            regulierung: "MiFID II, REMIT (ACER), EnWG §26, EMIR",
            kundensegment: "Erzeuger, Lieferanten, Trader, ÜNBs, Industrie",
            differenzierung: "Liquidität, Produktpalette, Clearing-Sicherheit, Technologie-Latenz",
            status: "aktiv",
            radar: { regulierung:3, skalierbarkeit:5, marktrisiko:1, digitalisierung:5, wettbewerb:2, nachhaltigkeit:2 },
            erloesTyp: "Fee-based", akteure: ["EPEX SPOT","EEX","ECC"]
          }
        ]
      },
      {
        id: "L2-HANDEL-PORTFOLIO", title: "Proprietärer Handel & Portfolio-Optimierung",
        description: "Handel auf eigene Rechnung und Kundenportfolio-Management.",
        actors: ["Axpo","Alpiq","BKW Trading","Vitol","Statkraft Markets","RWE Supply & Trading"],
        items: [
          {
            id: "L3-HANDEL-PORTFOLIO-01", title: "Proprietärer Energiehandel (Prop Trading)",
            definition: "Handel auf eigene Rechnung mit dem Ziel, Marktpreisrisiken in Gewinne umzuwandeln. Strategien: (1) Spot-Arbitrage zwischen Märkten und Zeitpunkten. (2) Spread Trading: Clean Spark Spread (Strom vs. Gas + CO₂), Clean Dark Spread (Strom vs. Kohle + CO₂). (3) Strukturelles Trading: Baseload-Futures günstig, Peak-Futures teuer verkaufen. (4) Meteorologisches Trading: Positionsnahme auf Basis proprietärer EE-Prognosemodelle. Alle Positionen unterliegen REMIT-Meldepflicht an ACER und MiFID II-Compliance.",
            wertschoepfung: "Informationsvorsprung als einzige nachhaltige Alpha-Quelle: bessere EE-Prognosemodelle, schnellere Datenpipelines, erfahrenere Trader. Skaleneffekte: Größere Bücher bewirtschaften Bid-Ask-Spreads effizienter. Risikomanagement-Disziplin ermöglicht höhere Positionsnahme bei gleichem VAR-Budget.",
            herausforderungen: "REMIT II (ab 2024): erweiterte Meldepflichten, schärfere Insider-Trading-Definitionen. ML-Algorithmen nivellieren Informationsvorsprünge zwischen Marktteilnehmern. EMIR-Clearing-Anforderungen erhöhen Eigenkapitalbindung. Talentknappheit: Quantitative Trader und Data Scientists sind teuer und mobil.",
            ausblick: "Volatilität steigt strukturell mit EE-Anteil – mehr Handelsmöglichkeiten und Risiken. KI-gestützte Prognosemodelle werden Standard. Neue Produkte: H2-Derivate, Long-Duration-Storage-Kontrakte, Flex-Produkte für Aggregatoren. EU-Marktintegration (PICASSO, MARI, TERRE) schafft größere Arbitrage-Räume.",
            erloesmodell: "Handelsmarge (P&L aus Proprietary-Positionen, VAR-kontrolliert)",
            regulierung: "REMIT II, MiFID II, EMIR, EnWG §5, ACER-Überwachung",
            kundensegment: "Eigenbuch (kein externer Kunde)",
            differenzierung: "ML-Prognosegüte, Datenvorteil, Reaktionsgeschwindigkeit, Risikodisziplin",
            status: "aktiv",
            radar: { regulierung:2, skalierbarkeit:4, marktrisiko:5, digitalisierung:5, wettbewerb:4, nachhaltigkeit:1 },
            erloesTyp: "Merchant", akteure: ["Axpo","Alpiq","Vitol","RWE S&T","Trafigura"]
          },
          {
            id: "L3-HANDEL-PORTFOLIO-02", title: "Direktvermarktung & EE-Portfoliomanagement",
            definition: "Direktvermarktungsdienstleister bündeln EE-Anlagen und optimieren deren gemeinsame Vermarktung. Kerngeschäft: Prognosedienstleistung – bessere Einspeiseprognosen als Referenzmarktwert = Outperformance. Next Kraftwerke (jetzt RWE): >14 GW in 17 Ländern, europäischer Marktführer. Technologiebasis: ML-Wettermodelle (0,5–1 km Auflösung), SCADA-Anbindung aller Anlagen, automatisierter Intraday-Handel. Erlös: Managementfee (0,15–0,50 ct/kWh) + Outperformance-Split (20–40% des Mehrerlöses).",
            wertschoepfung: "Portfolioeffekte bei >10 GW: Prognosefehler sinkt durch Diversifikation auf ~2–3%. Outperformance von 2 €/MWh bei 10 GW × 2.000 h = 40 Mio. MWh × 2 €/MWh = 80 Mio. € Outperformance-Pool p.a. First-Mover-Vorteile: Wechselhürde nach SCADA-Integration ist hoch. Technologiekostenreduktion schafft steigende Margen.",
            herausforderungen: "ÜNBs verbessern Referenzmarktwerte kontinuierlich – Outperformance-Potenzial sinkt strukturell. Markt konsolidiert: Top 5 Direktvermarkter haben >70% Marktanteil. Interessenkonflikte nach RWE-Übernahme von Next Kraftwerke (vermarktet auch Wettbewerberanlagen). EinsMan-Abrechnungskomplexität (Ausfallarbeit) belastet Prozesse.",
            ausblick: "Direktvermarktung entwickelt sich zu 'Energy-as-a-Service': EE + Speicher + H2-Elektrolyse-Steuerung + Demand Response. Internationalisierung: Europäischer EE-Boom schafft Wachstumsmärkte außerhalb Deutschland.",
            erloesmodell: "Managementfee (ct/kWh) + Outperformance-Share (% über RMW)",
            regulierung: "EEG §21b, MaBiS, REMIT, regelleistung.net",
            kundensegment: "EE-Anlagenbetreiber (B2B), Projektentwickler",
            differenzierung: "Prognosegüte, Portfoliogröße (Skaleneffekte), SCADA-Anbindungstiefe",
            status: "aktiv",
            radar: { regulierung:2, skalierbarkeit:5, marktrisiko:2, digitalisierung:5, wettbewerb:3, nachhaltigkeit:4 },
            erloesTyp: "Fee-based", akteure: ["Next Kraftwerke (RWE)","Statkraft","Axpo","BKW","Enspired"]
          },
          {
            id: "L3-HANDEL-ZERTIF-01", title: "Herkunftsnachweise (HKN) & EU ETS",
            definition: "HKN/GO (Guarantees of Origin): Handelbare Zertifikate, die 1 MWh EE-Strom aus spezifischer Quelle bescheinigen. Separater Markt vom physischen Strom (RECS-System). Preise: 0,10–5 €/MWh je nach Qualität (Zusätzlichkeit, Jahrgang, Technologie, Regionalität). EU ETS: Pflichtmarkt für Stromerzeugung und Industrie >20 MW. EUAs (EU Allowances) bei >80 €/t CO₂ (2023) wesentlicher Kostentreiber. Händler arbitrieren Spot-Futures-Spread, Auktionstermine, saisonale Nachfragemuster.",
            wertschoepfung: "HKN: Marge aus Ankauf (EE-Erzeuger) und Verkauf (Lieferanten für Stromkennzeichnung/CSRD). Premium-Segmente (24/7 Matching, regionale HKN, Neuanlagen-Zertifikate) wachsen durch CSRD-Druck. EU ETS: Händler mit besseren CO₂-Preisprognosen erzielen strukturelle Überrenditen.",
            herausforderungen: "HKN-Markt: Überangebot aus wasserkraftreichen Ländern drückt Preise. Regulatorisches Risiko: Strengere Zusätzlichkeits-Anforderungen könnten Markt fragmentieren. EU ETS: CBAM (vollständige Implementierung ab 2026) verändert Nachfragedynamik für europäische Industrie.",
            ausblick: "24/7 CFE (Carbon-Free Energy): stündliches HKN-Matching statt Jahresbilanz. Google, Microsoft, BASF treiben Standard. Neues EU-Marktdesign für hochauflösende HKN entsteht. EU ETS Phase 5 (ab 2031): Ausweitung auf Gebäude und Transport.",
            erloesmodell: "HKN: Handelsmarge (ct/MWh). EU ETS: Tradinggewinne + Compliance-Beratung",
            regulierung: "EnWG §42, EU RED II/III, RECS, EU ETS-RL (2003/87/EG), TEHG",
            kundensegment: "Lieferanten, Industrie (ESG/CSRD), Finanzinvestoren",
            differenzierung: "Zusätzlichkeit (Additionality), Jahrgangspremium, ETS-Preisprognose",
            status: "aktiv",
            radar: { regulierung:3, skalierbarkeit:5, marktrisiko:3, digitalisierung:3, wettbewerb:3, nachhaltigkeit:4 },
            erloesTyp: "Merchant", akteure: ["EEX","RECS International","Axpo","DZ-4","Naturstrom"]
          }
        ]
      }
    ]
  }

  // (continued)

  // ══════════════════════════════════════════════════════════
  // L1: VERTRIEB & ENERGIELIEFERUNG
  // ══════════════════════════════════════════════════════════
  {
    id: "L1-VERTRIEB", title: "Vertrieb & Energielieferung", icon: "🏠", color: "#EF4444",
    description: "Höchste Geschäftsmodell-Diversität aller Segmente – vom Massenmarkt-Grundversorger bis zum App-first Neolieferanten.",
    capabilities: [
      {
        id: "L2-VERTRIEB-VOLL", title: "Integrierter Vollversorger",
        description: "Großkonzerne unter Margendruck – im Transformationsprozess zum Energiedienstleister.",
        actors: ["E.ON Energie Deutschland","EnBW","RWE/innogy","Vattenfall"],
        items: [
          {
            id: "L3-VERTRIEB-VOLL-01", title: "Massenmarkt B2C – Grundversorgung & Sondertarife",
            definition: "Grundversorger (§36 EnWG: günstigster Anbieter nach Kundenzahl) beliefern Haushalte ohne expliziten Vertrag zum Grundversorgungstarif (GVT). GVT nicht staatlich reguliert, aber transparent kalkulierbar (StromGVV). Wettbewerbliche Sondertarife mit 12–24 Monaten Preisbindung konkurrieren über Vergleichsportale (Verivox, Check24). Erlösstruktur: Retail Margin = Endkundenpreis minus Beschaffungskosten minus Netzentgelte minus Umlagen minus Steuern. Typische Marge: 0,5–2 ct/kWh.",
            wertschoepfung: "Skaleneffekte: bessere Beschaffungskonditionen, effizienterer Kundenservice, IT-Infrastruktur amortisiert über Millionen Kunden. Cross-Selling: Ein Stromkunde generiert im Schnitt 4+ Produkte (Gas, Wärme, Solar, Wallbox). Grundversorgungsstatus sichert Kundenbasis ohne Akquisitionsaufwand. Daten: Jahresverbrauchsdaten als Basis für personalisierte Produktangebote.",
            herausforderungen: "Margenkompression durch Vergleichsportale und Neolieferanten. Energiepreiskrise 2021–2023 hat Discounter-Lieferanten in Insolvenz getrieben – GV als Auffangbecken ohne Marge. IT-Altlasten (SAP IS-U): teure Migration zu SAP S/4HANA. §41b-Pflicht (dynamische Tarife ab 2025) erfordert vollständige IT-Neuarchitektur.",
            ausblick: "Grundversorger müssen sich zu Energiedienstleistern transformieren: Smart-Home-Pakete, EV-Ökosystem, Wärmecontracting, PV-Komplettlösung als Margentreiber. Dynamische Tarife zwingen zur stündlichen Abrechnungsinfrastruktur. Konsolidierung: kleinere Stadtwerke-Vertriebe werden an Konzerne verkauft.",
            erloesmodell: "Einzelhandelsspanne (ct/kWh) auf Strom und Gas",
            regulierung: "EnWG §36/§38, StromGVV, GasGVV, Preistransparenz-VO",
            kundensegment: "B2C Haushalte, B2B Gewerbe",
            differenzierung: "Marke, Bundling, Treueprogramme, Servicenetz, IT-Reife für dyn. Tarife",
            status: "aktiv",
            radar: { regulierung:3, skalierbarkeit:4, marktrisiko:2, digitalisierung:2, wettbewerb:5, nachhaltigkeit:2 },
            erloesTyp: "Merchant", akteure: ["E.ON Energie","EnBW","RWE/innogy","Vattenfall"]
          }
        ]
      },
      {
        id: "L2-VERTRIEB-NEO", title: "Digitale Neolieferanten",
        description: "Fundamentale Geschäftsmodell-Innovationen – Strom als Plattform statt Commodity.",
        actors: ["Tibber","Ostrom","Fünf Grad","aWATTar"],
        items: [
          {
            id: "L3-VERTRIEB-NEO-01", title: "Tibber – Dynamic Pricing & Energie-Ökosystem",
            definition: "Tibber (gegründet 2016, Norwegen; Deutschland ab 2019) hat das Versorger-Modell fundamental umgedreht: Statt kWh-Marge verdient Tibber ein Software-Abo (9,95 €/Monat). Strom kostet den stündlichen EPEX-Spot + Netzentgelte + Steuern ohne Aufschlag. Wert liegt in der App: automatische Steuerung von EV-Ladung, Wärmepumpe, Heimspeicher in günstige Stunden. Tibber Pulse-Dongle (~30 €) liest Zähler aus. Community-Feature: Nutzer vergleichen Einsparungen, Gamification. Ökosystem-Partnerschaften mit Wallbox-Herstellern (Easee), WP-OEMs.",
            wertschoepfung: "SaaS-Marge: 10 €/Monat × 500.000 Kunden = 60 Mio. €/Jahr – stabil, unabhängig vom Energiepreis. Netzwerkeffekte: Mehr Tibber-Nutzer mit steuerbaren Assets → attraktiver für §14a-VNB-Kooperation und VPP-Aggregation → neue B2B-Einnahmen. Ökosystem-Plattform: Wallbox-/WP-OEMs zahlen Integrations-Fees für Tibber-Zertifizierung.",
            herausforderungen: "Setzt Smart Meter voraus (für dynamische Tarife nach §41b). In Deutschland Rollout erst ab 2025 verpflichtend – begrenzte Nutzerbasis für volle Automatisierung bisher. CAC ~100 €/Kunde = 1-Jahr-Payback – funktioniert nur bei sehr niedrigem Churn. Markt-Educating teuer: stündliche Preislogik ist noch nicht Mainstream.",
            ausblick: "§41b EnWG (Pflicht für Versorger >200k Kunden, dynamische Tarife, ab 2025) validiert Tibbers Modell für den Massenmarkt. EV-Boom ist Hauptwachstumstreiber: jeder EV-Halter mit Wallbox hat 2–3 €/Tag Einsparpotenzial durch intelligentes Laden. Tibber könnte zur Plattform-Infrastruktur des 'Prosumer-Internet der Energie' werden.",
            erloesmodell: "Subscription (9,95 €/Monat) + Ökosystem-Partnergebühren",
            regulierung: "EnWG §41b (dynamische Tarife), MsbG (Smart Meter als Voraussetzung)",
            kundensegment: "B2C Tech-affine Prosumer: EV-Halter, WP-Besitzer, PV-Anlagenbetreiber",
            differenzierung: "App-UX, Automatisierungstiefe, Community, Smart-Home-Ökosystem-Breite",
            status: "aktiv",
            radar: { regulierung:1, skalierbarkeit:5, marktrisiko:1, digitalisierung:5, wettbewerb:3, nachhaltigkeit:4 },
            erloesTyp: "Subscription", akteure: ["Tibber"]
          },
          {
            id: "L3-VERTRIEB-NEO-02", title: "Fünf Grad – Klimainvestitionsmodell",
            definition: "Fünf Grad (2020, Berlin) hat einen dritten Weg entwickelt: weder günstigster Anbieter noch Standard-Ökostromvertrieb, sondern direkte messbare Klimawirkung als Produktkern. Pro verbrauchter kWh fließt ein fixer Betrag (~0,5 ct/kWh) in zertifizierte Naturschutzprojekte in Deutschland (Torfmoor-Renaturierung, Agroforstwirtschaft, Gewässerrenaturierung). Kritischer Unterschied: Investition in neue, zusätzliche Projekte auf deutschem Boden – nicht internationaler HKN-Zertifikatehandel. Wirkungsreporting: Kunden erhalten Jahresbericht mit konkreter Flächengröße und gemessener CO₂-Bindung.",
            wertschoepfung: "Premium-Aufschlag (2–3 ct/kWh über Marktpreis) von klimabewussten Kunden mit Zahlungsbereitschaft. Kernthese: Anti-Greenwashing-Positioning schafft Glaubwürdigkeitspremium. Strukturell: Klimaprojekte kosten ~0,3–0,5 ct/kWh – Rest ist Retail Margin. Geringe CAC durch Word-of-Mouth in Purpose-Zielgruppe.",
            herausforderungen: "Zielgruppe ist eng: klimabewusst + zahlungsbereit + nicht preissensitiv. Glaubwürdigkeitsrisiko: Klimaprojekte müssen regelmäßig auditiert werden (VCS, Gold Standard). Anzahl geeigneter Naturschutzprojekte in Deutschland ist limitiert – Skalierungshürde. CSRD-Anforderungen an Scope-2-Emissionen könnten Produktdefinition schärfen.",
            ausblick: "CSRD-Berichtspflichten schaffen B2B-Markt für 'High-Integrity Energy' mit nachgewiesener Zusätzlichkeit. Fünf Grad entwickelt B2B-Segment für KMU mit CSRD-Pflicht. 24/7 CFE-Standard als nächster Qualitätsschritt: stündliche Zusätzlichkeit statt Jahresbilanz.",
            erloesmodell: "Retail Margin + Klimaaufschlag (fixer ct/kWh, zweckgebunden)",
            regulierung: "EnWG, UBA-Anerkennungsstandards, EU-Taxonomieverordnung",
            kundensegment: "B2C klimabewusste Haushalte; B2B KMU (CSRD-getrieben)",
            differenzierung: "Messbare Zusätzlichkeit, Antigreenwashing-Positioning, Impact Reporting",
            status: "aktiv",
            radar: { regulierung:1, skalierbarkeit:4, marktrisiko:2, digitalisierung:3, wettbewerb:3, nachhaltigkeit:5 },
            erloesTyp: "Merchant", akteure: ["Fünf Grad"]
          },
          {
            id: "L3-VERTRIEB-NEO-03", title: "Ostrom – Radikale Kostentransparenz",
            definition: "Ostrom (2020, Berlin) verfolgt extremste Preistransparenz: Tarif = exakt ausgewiesener Börsenstrompreis (Monatsdurchschnitt EPEX) + Netzentgelte + staatliche Abgaben + fixe Marge (~1 ct/kWh). Keine Lockangebote, keine Preisgarantien, keine Boni. Kommunikation: 'Wir sind nicht der günstigste – aber immer fair.' Kunden sollen verstehen, wie sich ihr Strompreis zusammensetzt. Positionierung explizit gegen Vergleichsportale, die Lockangebote bevorzugen.",
            wertschoepfung: "Niedrige CAC durch Word-of-Mouth in transparenz-orientierten Zielgruppen (keine Check24-Gebühren). Sehr niedriger Churn durch Kundenzufriedenheit (~5%/Jahr vs. 20–30% bei Discount-Anbietern). Fixe absolute Marge: bei steigendem Preisniveau bleibt Marge stabil. Strukturell geringe Komplexität senkt Betriebskosten.",
            herausforderungen: "Marktsegment limitiert: preisbewusste Kunden ohne Transparenz-Bedürfnis wechseln trotzdem zu billigstem Angebot. Kein Bundling-Potenzial (keine Solar, EV, Wärme-Angebote geplant). Wachstumslimitierung durch Nischenpositioning.",
            ausblick: "EU EMD-Preistransparenz-Anforderungen werden Markt in Richtung Ostroms Modell schieben. Tibber und Ostrom repräsentieren komplementären 'Anti-Commodity'-Trend: Kunden zahlen für Automatisierung (Tibber) oder Vertrauen (Ostrom).",
            erloesmodell: "Fixer Aufschlag (~1 ct/kWh) auf transparenten Großhandelspreis",
            regulierung: "EnWG §41 (Preistransparenzpflicht)",
            kundensegment: "B2C preisbewusste, vertrauensorientierte Digital-Natives",
            differenzierung: "Radikale Transparenz, Einfachheit, keine Lockangebote, Anti-Greenwashing",
            status: "aktiv",
            radar: { regulierung:1, skalierbarkeit:4, marktrisiko:2, digitalisierung:3, wettbewerb:4, nachhaltigkeit:3 },
            erloesTyp: "Merchant", akteure: ["Ostrom"]
          },
          {
            id: "L3-VERTRIEB-NEO-04", title: "aWATTar – Stundentarif für DIY-Automatisierer",
            definition: "aWATTar (2012, Österreich; Deutschland ab 2017) war DACH-Pionier des dynamischen Stundentarifs. Kunden zahlen exakt den stündlichen EPEX-Spot + fixe Aufschläge (Netzentgelte, Abgaben + ~0,3 ct/kWh). Alleinstellungsmerkmal: öffentliche API – Preise 24h im Voraus kostenlos verfügbar. Entwickler-Community baut Home-Assistant-, ioBroker-, openHAB-Integrationen. Explizit keine eigene App – maximale Offenheit, keine Vendor-Lock-in.",
            wertschoepfung: "Sehr niedrige Betriebskosten durch Community-Support statt Call Center. Open-API-Ansatz generiert organisches Wachstum ohne Marketing-Budget. Unterschied zu Tibber: kein Abo-Erlös, kein proprietäres Ökosystem – reine Software-als-Infrastruktur-Philosophie.",
            herausforderungen: "Kein Abo-Erlös: Skalierung nur durch höheres Volumen. DIY-Techniker-Zielgruppe ist per Definition begrenzt. Tibber hat aWATTar durch stärkeres Marketing und Ökosystem überholt. Frage der strategischen Weiterentwicklung: Nischenprodukt bleiben oder expandieren?",
            ausblick: "Mit vollständigem Smart-Meter-Rollout entsteht echter Massenmarkt für Stundentarife. §41b EnWG zwingt alle großen Versorger, dynamische Tarife anzubieten – aWATTar-Modell wird Standard. Frage: Wird aWATTar zum Infrastrukturanbieter für andere Lieferanten?",
            erloesmodell: "Fixer Aufschlag (ct/kWh) auf stündliche EPEX-Spotpreise",
            regulierung: "EnWG §41b, MsbG (Smart Meter als Enabler)",
            kundensegment: "B2C Entwickler, DIY-Automatisierer, Smart-Home-Enthusiasten",
            differenzierung: "Open API, keine Vendor-Lock-in, maximale Transparenz, Entwickler-Community",
            status: "aktiv",
            radar: { regulierung:1, skalierbarkeit:4, marktrisiko:2, digitalisierung:5, wettbewerb:3, nachhaltigkeit:3 },
            erloesTyp: "Merchant", akteure: ["aWATTar"]
          }
        ]
      },
      {
        id: "L2-VERTRIEB-OEKO", title: "Ökostrom-Spezialisten & Genossenschaften",
        description: "Glaubwürdigkeit, Herkunft und Gemeinschaft als primäre Differenzierungsmerkmale.",
        actors: ["Naturstrom AG","EWS Schönau","Green Planet Energy","BürgerEnergie Berlin"],
        items: [
          {
            id: "L3-VERTRIEB-OEKO-01", title: "Premium-Ökostrom mit Zusatzkriterien",
            definition: "Naturstrom AG und Green Planet Energy (ex Greenpeace Energy) verfolgen strikten Ökostrom-Standard: (1) Direktlieferverträge ausschließlich mit Neuanlagen (max. 10 Jahre alt) – keine HKN von 30-Jahre-alten Wasserkraftwerken. (2) Konzernunabhängigkeit: kein Atom/Kohle-Strom im Mutterkonzern. (3) Ausbauförderung: Teil des Erlöses fließt in neue EE-Anlagen. Diese Kriterien schließen alle großen Versorger strukturell aus. Naturstrom: ~200.000 Kunden bundesweit.",
            wertschoepfung: "Glaubwürdigkeitsprämie: Kunden zahlen 1–3 ct/kWh mehr als für Standard-Ökostrom. Strukturell niedriger Churn (<5%/Jahr). Direktlieferverträge mit EE-Anlagen sind proprietäres Asset – nicht kopierbar. 24/7-CFE-Standard als nächste Differenzierungsstufe: stündliches Matching von Verbrauch und Erzeugung.",
            herausforderungen: "HKN-System ermöglicht Greenwashing durch Großkonzerne – Vertrauensverlust im Gesamtmarkt schadet auch seriösen Anbietern. Kommunikationskomplexität: Warum ist Naturstrom besser als E.ON Ökopower? Schwer zu erklären in 30 Sekunden. Nischenmarkt begrenzt Skalierung.",
            ausblick: "CSRD-Anforderungen an Scope-2-Emissionen schaffen B2B-Markt für High-Integrity Ökostrom. 24/7 CFE wird sich als Standard durchsetzen (Google/Microsoft als Treiber). Naturstrom und Green Planet Energy gut positioniert für diesen Standard.",
            erloesmodell: "Retail Margin + Nachhaltigkeits-Premium (1–3 ct/kWh über Standard-Ökostrom)",
            regulierung: "EnWG §42 (Stromkennzeichnung), RECS/HKN, EU RED III",
            kundensegment: "B2C werteorientierte Privatkunden; B2B KMU mit ESG-Anforderungen",
            differenzierung: "Direktlieferverträge (Neuanlagen), Konzernunabhängigkeit, Impact-Transparenz",
            status: "aktiv",
            radar: { regulierung:1, skalierbarkeit:3, marktrisiko:2, digitalisierung:2, wettbewerb:3, nachhaltigkeit:5 },
            erloesTyp: "Merchant", akteure: ["Naturstrom AG","Green Planet Energy","EWS Schönau"]
          }
        ]
      },
      {
        id: "L2-VERTRIEB-STADTWERK", title: "Stadtwerke & regionale Versorger",
        description: "Das Rückgrat der deutschen Energieversorgung – strukturell stark, unter digitalem Transformationsdruck.",
        actors: ["SWM","ENTEGA","badenova","enercity","Stadtwerke Köln"],
        items: [
          {
            id: "L3-VERTRIEB-STADTWERK-01", title: "Kommunales Mehrsparten-Modell",
            definition: "Stadtwerke sind die institutionelle Besonderheit der deutschen Energieversorgung: kommunale Unternehmen, die Strom, Gas, Wärme, Wasser und oft ÖPNV aus einer Hand liefern. Finanzierungslogik: profitable Energie-/Netzsparten quersubventionieren defizitären ÖPNV (steuerlich optimiert via Querverbund §4 Abs. 6 KStG). SWM: >7 Mrd. € Umsatz, 10.000 Mitarbeiter, betreiben U-Bahn + Hallenbäder + Kraftwerke. Lokale Kundenbindung durch 30–50 Jahre Kundenbeziehungen und kommunale Identität.",
            wertschoepfung: "Struktureller Vorteil: Querverbund + kommunale Bürgschaft senken Kapitalkosten. Wechselquote deutlich niedriger als bei nicht-kommunalen Versorgern. Wärmenetz als wachsendes Alleinstellungsmerkmal (WPG schützt Fernwärme-Investitionen). Daten: vollständige lokale Energie-/Mobilitäts-/Wasserdaten als Basis für Smart-City-Angebote.",
            herausforderungen: "Entscheidungsprozesse durch Aufsichtsrat, Gemeinderat, Gesellschafterversammlung strukturell langsam. ÖPNV-Defizite wachsen (Corona-Nachwirkungen, Investitionsstau). IT-Altlasten: SAP IS-U, selbstentwickelte Systeme. §41b-Pflicht (dynamische Tarife) erfordert vollständige IT-Erneuerung.",
            ausblick: "Stadtwerke werden zu 'lokalen Energiehubs': WPG-Wärmeplanung, Ladeinfrastruktur, PV-Pachtmodelle, HEMS-Integration. Konsolidierung unvermeidlich: 900+ Stadtwerke werden auf 200–300 bis 2040 konsolidieren. Digitale Transformation als Überlebensfrage der mittelgroßen Stadtwerke.",
            erloesmodell: "Multi-Sparten-Bundling; Quersubvention ÖPNV ↔ Energie (§4 Abs. 6 KStG)",
            regulierung: "EnWG, GemO der Bundesländer, §102 GemO, KStG §4 Abs. 6",
            kundensegment: "B2C lokal + B2B Gewerbe + kommunale Einrichtungen",
            differenzierung: "Lokale Identität, Full-Service (Strom/Gas/Wärme/Wasser), Wärmenetz, ÖPNV",
            status: "aktiv",
            radar: { regulierung:3, skalierbarkeit:2, marktrisiko:2, digitalisierung:2, wettbewerb:2, nachhaltigkeit:3 },
            erloesTyp: "Merchant", akteure: ["SWM","enercity","Stadtwerke Köln","badenova","ENTEGA"]
          }
        ]
      }
    ]
  },

  // ══════════════════════════════════════════════════════════
  // L1: AGGREGATION & FLEXIBILITÄT
  // ══════════════════════════════════════════════════════════
  {
    id: "L1-AGG", title: "Aggregation & Flexibilität", icon: "🔋", color: "#06B6D4",
    description: "Softwaregetriebene Bündelung dezentraler Ressourcen – eines der am schnellsten wachsenden Segmente.",
    capabilities: [
      {
        id: "L2-AGG-VPP", title: "Virtual Power Plants (VPP)",
        description: "Aggregation von EE-Anlagen, Speichern und flexiblen Lasten zu virtuellen Kraftwerken.",
        actors: ["Next Kraftwerke (RWE)","Sonnen (Shell)","Enspired","Sympower","Statkraft"],
        items: [
          {
            id: "L3-AGG-VPP-01", title: "EE-Direktvermarktungs-VPP",
            definition: "Next Kraftwerke (2009, jetzt RWE): >14 GW in 17 Ländern – europäischer Marktführer. Technologiebasis: Proprietäres EMS (Netlantis), 0,5 km-Wettermodell-Ensemble, ML-Prognosesystem, SCADA-Anbindung jeder Anlage. Entscheidungslogik: Stündlich wird für jede Anlage berechnet, ob Day-Ahead oder Intraday-Vermarktung optimal ist. Erlös: Managementfee (0,15–0,45 ct/kWh) + Outperformance-Split (20–40% Mehrerlös über RMW).",
            wertschoepfung: "Skalenökonomie ist fundamental: 10 GW Portfolio reduziert Prognosefehler durch Diversifikation auf ~2–3% (vs. 15–25% Einzelanlage). Outperformance von 2 €/MWh × 10 GW × 2.000 h = 40 Mio. MWh = 80 Mio. € Pool. Wechselbarriere nach SCADA-Integration hoch (Umprogrammierung, Datenmigration). Technologiekosten sinken, Margen steigen strukturell.",
            herausforderungen: "RWE-Übernahme schafft potenzielle Interessenkonflikte (Next vermarktet auch Wettbewerberanlagen). ÜNBs verbessern Referenzmarktwerte – Outperformance-Potenzial sinkt langfristig. Regulatorisches Risiko bei Direktvermarktungsmarkt-Veränderungen.",
            ausblick: "VPP 2.0: EE + Speicher + H2-Elektrolyse-Steuerung + Demand Response + V2G als integriertes Portfolio. Europäische Optimierung über Ländergrenzen (unterschiedliche Markpreise) schafft neue Arbitrage. KI-Echtzeit-Optimierung als nächster Entwicklungsschritt.",
            erloesmodell: "Direktvermarktungsfee (ct/kWh) + Outperformance-Share",
            regulierung: "EEG §21b, MaBiS, REMIT, regelleistung.net",
            kundensegment: "EE-Anlagenbetreiber (B2B), Projektentwickler",
            differenzierung: "Portfoliogröße (Skaleneffekte), ML-Prognosegüte, SCADA-Tiefe, Reaktionsgeschwindigkeit",
            status: "aktiv",
            radar: { regulierung:2, skalierbarkeit:5, marktrisiko:2, digitalisierung:5, wettbewerb:3, nachhaltigkeit:4 },
            erloesTyp: "Fee-based", akteure: ["Next Kraftwerke (RWE)","Statkraft","Axpo","BKW","Vattenfall"]
          },
          {
            id: "L3-AGG-VPP-02", title: "Demand-Response-Aggregation (Industrie)",
            definition: "Industrielle Lasten (Elektrolyseure, Aluminiumschmelzen, Chloralkali-Elektrolyse, Kühlhäuser, Rechenzentren) werden flexibilisiert und als virtuelles Regelenergie-Asset am Markt angeboten. Unabhängiger Aggregator (EU Clean Energy Package SOGL Art. 182) kann Regelenergie verkaufen ohne Energielieferant zu sein. Schema: Industriekunde signalisiert 'Ich kann in 5 Minuten 10 MW reduzieren' → Aggregator präqualifiziert für aFRR-Down → bei ÜNB-Aktivierung wird Last reduziert → Revenue-Share.",
            wertschoepfung: "Industriekunde erhält Zusatzerlös für Flexibilität, die er ohnehin hat. Aggregator verdient Revenue-Share (20–40%) ohne eigene Asset-Investition. Einzige Investition: Steuerungssoftware + SCADA-Anbindung. Skalierung durch mehr Industriekunden ist margenkonstant.",
            herausforderungen: "Industriekunden zögern wegen Produktionsunterbrechung – Reliability-Nachweis >99% der Präqualifikationsstunden nötig. Technische Anbindung (SPS, ERP) bei jedem Kunden individuell. Deutschland noch restriktiver als andere EU-Länder bei unabhängigen Aggregatoren. aFRR-Marktzugang erfordert aufwendige Präqualifikation.",
            ausblick: "Markt wächst durch steigendes aFRR/mFRR-Volumen (mehr Regelenergiebedarf durch EE) und Industrieflexibilisierung. H2-Elektrolyse als perfekter Demand-Response-Asset: kann in Sekunden hoch- oder runterregeln, ideal für FCR/aFRR. §64-EEG-Reform fördert Lastflexibilität energieintensiver Industrien.",
            erloesmodell: "Revenue-Share (40–80% der Regelenergiemärkte) mit Industriekunden",
            regulierung: "SOGL Art. 182 (unabhängige Aggregatoren), EnWG §12g, regelleistung.net",
            kundensegment: "B2B Industrie (Chemie, Metall, Papier, Rechenzentren)",
            differenzierung: "Reaktionszeit, Industriekunden-Portfolio, SCADA-Anbindungstiefe, Präqualifikationszuverlässigkeit",
            status: "aktiv",
            radar: { regulierung:2, skalierbarkeit:4, marktrisiko:2, digitalisierung:5, wettbewerb:2, nachhaltigkeit:3 },
            erloesTyp: "Fee-based", akteure: ["Sympower","Enspired","E.ON Demand Response","VOLTARIS"]
          }
        ]
      }
    ]
  },

  // ══════════════════════════════════════════════════════════
  // L1: PROJEKTENTWICKLUNG & EPC
  // ══════════════════════════════════════════════════════════
  {
    id: "L1-PROJ", title: "Projektentwicklung & EPC", icon: "🏗️", color: "#0EA5E9",
    description: "Entwicklung, Bau und Betrieb von Energieprojekten – kapitalleichte Projektierer bis zum kapitalintensiven EPC-Contractor.",
    capabilities: [
      {
        id: "L2-PROJ-WIND", title: "Wind- & Solar-Projektentwicklung",
        description: "Develop-to-Sell und Develop-to-Own als strategische Alternativen.",
        actors: ["ABO Wind","Baywa r.e.","wpd","juwi","Encavis","Notus Energy","PNE"],
        items: [
          {
            id: "L3-PROJ-WIND-01", title: "Develop-to-Sell (Projektrechte-Handel)",
            definition: "Projektierer sichern Flächen (Pacht/Kauf), holen alle Genehmigungen ein (BImSchG-Genehmigung, Netzverknüpfungspunkt-Anmeldung, Artenschutzgutachten, Schall-/Schattenwurf-Gutachten) und verkaufen fertig genehmigtes Projekt an Investor. Kernasset ist die Genehmigung. Entwicklungskosten: 100.000–500.000 €/Anlage. Projektverkaufspreis bei fertiger BImSchG: 150.000–400.000 €/MW. Serienentwicklung: Know-how aus 100+ Projekten senkt Kosten je Projekt.",
            wertschoepfung: "Kapitalleichte Strategie: wenig Eigenkapital gebunden (nur Entwicklungskosten). Hebelwirkung: Flächennetzwerk × Genehmigungskompetenz = überproportionaler Erlös. Proprietäres Flächennetzwerk (10.000–50.000 ha exklusiv gepachtet) als struktureller Schutzwall gegenüber Wettbewerbern. Repowering (Austausch alter Anlagen) als wachsendes Feld.",
            herausforderungen: "BImSchG-Verfahren: 4–8 Jahre, Klagen durch Anwohner/NABU verzögern oder verhindern Projekte. Flächenwettbewerb: Bodenwert und Pachtzins steigen. Netzverknüpfungspunkte als realer Engpass. WindBG-2%-Ziel verbessert Rahmenbedingungen, aber Umsetzung durch Länder stockt.",
            ausblick: "WindBG und beschleunigte BImSchG-Verfahren (EU-Notverordnung 2022/2577) senken Hürden schrittweise. Repowering dominiert mittelfristig (erste Anlagen aus 2000–2005 laufen ab 2025 aus EEG). Agri-PV und Floating-PV eröffnen neue Flächenkategorien.",
            erloesmodell: "Einmaliger Projektverkaufserlös (Development Margin: 50.000–150.000 €/MW)",
            regulierung: "BImSchG, BauGB, WindBG, EEG 2023",
            kundensegment: "Infrastrukturfonds, Energieversorger, Stadtwerke",
            differenzierung: "Flächennetzwerk, Genehmigungskompetenz, Artenschutz-Know-how, Tempo",
            status: "aktiv",
            radar: { regulierung:2, skalierbarkeit:2, marktrisiko:3, digitalisierung:2, wettbewerb:4, nachhaltigkeit:5 },
            erloesTyp: "Fee-based", akteure: ["ABO Wind","wpd","juwi","PNE","Notus Energy"]
          },
          {
            id: "L3-PROJ-EPC-01", title: "EPC-Contractor & O&M-Dienstleistungen",
            definition: "EPC (Lump Sum Turnkey): Totalunternehmer übernimmt gesamte Projektrealisierung zu Festpreis. Risiken: Baukosten-Überschreitung, Lieferkette, Termintreue. Marge typisch 8–15% auf Baukosten. O&M (Operation & Maintenance): Hersteller (Siemens Gamesa Full-Service, Vestas AOM) oder unabhängige Dienstleister (Deutsche Windtechnik) übernehmen Betrieb. Full-Service-O&M garantiert Verfügbarkeit >97%, deckt alle Wartungs-/Reparaturkosten. Jährliche Pauschale: 40.000–80.000 €/Anlage (3–5 MW).",
            wertschoepfung: "EPC: Festpreis-Optimierung (günstiger einkaufen als kalkuliert), Skaleneffekte in Beschaffung, Montage-Standardisierung. O&M: 80–90% Wiederkehrumsatz, hohe Wechselhürden durch proprietäre SCADA-Systeme, wachsende installierte Basis als strukturelles Wachstum. Predictive Maintenance (KI-basierte Ausfallprognose) als Differenzierungsmerkmal.",
            herausforderungen: "EPC: Festpreisverträge in inflationärem Umfeld riskant (Siemens Gamesa-Verluste 2022–2023). Lieferkettenengpässe bei Turbinen, Transformatoren, Kabeln. O&M: Unabhängige Drittanbieter konkurrieren mit Herstellern durch niedrigere Stundensätze. Fachkräftemangel bei Servicetechnikern.",
            ausblick: "O&M-Markt wächst mit installierter Basis: 100 GW Wind Deutschland bis 2030 = ~3 Mrd. €/Jahr O&M-Marktvolumen. Datengetriebene Predictive Maintenance verbessert Verfügbarkeit. Offshore-O&M als eigenständige Sparte mit maritimen Anforderungen (CTVs, SOVs, Jack-up-Vessels).",
            erloesmodell: "EPC: Festpreis-Vertragssumme. O&M: Jahrespauschale (€/Anlage) + Performancebonus",
            regulierung: "VOB/B, FIDIC, BImSchG, CE-Kennzeichnung, IEC-Standards (IEC 61400)",
            kundensegment: "Projektentwickler, Infrastrukturfonds, Betreiber",
            differenzierung: "EPC: Lieferkettensicherheit, Termintreue. O&M: Verfügbarkeitsgarantie, Predictive Maintenance, Ersatzteillogistik",
            status: "aktiv",
            radar: { regulierung:1, skalierbarkeit:4, marktrisiko:2, digitalisierung:4, wettbewerb:3, nachhaltigkeit:4 },
            erloesTyp: "Fee-based", akteure: ["Siemens Gamesa","Vestas","Enercon","Deutsche Windtechnik","Fichtner"]
          }
        ]
      }
    ]
  },

  // ══════════════════════════════════════════════════════════
  // L1: ENERGIEFINANZIERUNG & INVESTOREN
  // ══════════════════════════════════════════════════════════
  {
    id: "L1-FINANZ", title: "Energiefinanzierung & Investoren", icon: "💰", color: "#10B981",
    description: "Kapitalstrukturen, die die Energiewende finanzieren – Bedarf bis 2030: >1.000 Mrd. € in Europa.",
    capabilities: [
      {
        id: "L2-FINANZ-PROJEKT", title: "Projektfinanzierung & Eigenkapital",
        description: "Non-Recourse-Finanzierung, Green Bonds und Infrastrukturfonds.",
        actors: ["KfW","EIB","DZ Bank","Commerzbank","ING","Aquila Capital","Copenhagen Infrastructure Partners"],
        items: [
          {
            id: "L3-FINANZ-PROJEKT-01", title: "Non-Recourse Projektfinanzierung",
            definition: "Standardfinanzierungsform für EE-Projekte >20 MW: Darlehen ausschließlich durch Projekt-Cashflows besichert, kein Rückgriff auf Sponsoren. Struktur: SPV als Darlehensnehmer; Sicherheiten = Genehmigungen, EEG/PPA-Ertragsverträge, Versicherungen, Anlagen. Leverage: 70–80% FK, 20–30% EK. DSCR typisch >1,25x. Zinssatz 2024: EURIBOR + 100–200 bps. KfW-Programme (Erneuerbare Energien Standard) mit Sonderkonditionen.",
            wertschoepfung: "Bank: Zinsmarge bei geringem Ausfallrisiko (EEG-Cashflows = stabiles Rating). Sponsor: EK-Hebelwirkung bei 25% EK und 10% Projektrendite → ~40% EK-IRR. EIB: Mission-driven – Förderung durch subventionierte Zinsen. Versicherungsmarkt verdient an Betriebsunterbrechungs- und Garantieversicherungen.",
            herausforderungen: "Steigende Zinsen (2022–2024) haben Project Finance teurer gemacht. Viele Projekte mit 2021er Kalkulation nicht mehr finanzierbar. Refinanzierungsrisiko bei kurzen Zinsbindungen. Basel IV-Kapitalanforderungen erhöhen Bankkosten für Infrastrukturfinanzierungen.",
            ausblick: "EU-Taxonomie-konforme Projekte erhalten günstigen Kapitalzugang ('Greenium'). Institutional Infrastructure Debt (Pensionsfonds als direkte Kreditgeber) wächst als Banken-Alternative. Blended Finance (EIB + private Banken) für risikoreiche Märkte.",
            erloesmodell: "Zinsmarge (EURIBOR + Spread) + Arrangierungsgebühren + Commitment Fees",
            regulierung: "KWG, CRR/Basel IV, EU-Taxonomie, EEG (Cashflow-Absicherung)",
            kundensegment: "EE-Projektgesellschaften (SPV), Projektentwickler, Infrastrukturfonds",
            differenzierung: "Zinssatz, Covenant-Flexibilität, Sektorexpertise, Abschlussgeschwindigkeit",
            status: "aktiv",
            radar: { regulierung:3, skalierbarkeit:4, marktrisiko:1, digitalisierung:2, wettbewerb:3, nachhaltigkeit:3 },
            erloesTyp: "Fee-based", akteure: ["KfW","EIB","DZ Bank","ING","Commerzbank","LBBW"]
          },
          {
            id: "L3-FINANZ-PROJEKT-02", title: "Green Bonds & Sustainability-Linked Bonds",
            definition: "Green Bonds: Anleihen, deren Erlöse ausschließlich für grüne Projekte verwendet werden (ICMA Green Bond Principles, EU Green Bond Standard EuGB seit 2024). Sustainability-Linked Bonds (SLBs): Kupon an ESG-KPIs geknüpft (z.B. installierte EE-Kapazität, CO₂-Intensität). 'Greenium': Green Bonds erzielen 2–10 bps niedrigeren Zinssatz als konventionelle Bonds – durch ESG-Investorenbasis (Pensionsfonds, Versicherungen mit Grün-Mandaten).",
            wertschoepfung: "Emittent: Zinsersparnis durch Greenium + Zugang zu ESG-Investorenbasis + Reputationsgewinn. Investitionsbank: Arrangierungsgebühr (0,1–0,3% des Emissionsvolumens) + Second-Party-Opinion-Koordination. SPO-Anbieter (Sustainalytics, ISS ESG): Verifizierungsgebühr.",
            herausforderungen: "Greenwashing-Risiko: ohne echte Zusätzlichkeit sind Green Bonds PR-Instrument. EU EuGB-Standard ist strenger als ICMA – schafft zwei-Klassen-Markt. Reporting-Aufwand (jährliche Impact Reports, Allokationsberichte) ist erheblich.",
            ausblick: "EU EuGB wird Marktstandard für institutionelle Investoren. SLBs unter Druck: Emittenten wählen leicht erreichbare KPIs ('SLB Washing'). Biodiversity Bonds, Transition Bonds, Nature Bonds als neue Kategorien. Green Bond-Markt: >500 Mrd. €/Jahr Neuemissionen weltweit (2024).",
            erloesmodell: "Greenium (Zinsersparnis für Emittenten) + Arrangierungsgebühren",
            regulierung: "EU Green Bond Standard (EuGB 2024), ICMA GBP, EU-Taxonomieverordnung, SFDR",
            kundensegment: "Institutionelle ESG-Investoren (Pensionsfonds, Versicherungen, SWFs)",
            differenzierung: "EU EuGB-Konformität, Second-Party-Opinion-Qualität, Impact-Transparenz",
            status: "aktiv",
            radar: { regulierung:3, skalierbarkeit:5, marktrisiko:1, digitalisierung:2, wettbewerb:3, nachhaltigkeit:5 },
            erloesTyp: "Fee-based", akteure: ["E.ON","RWE","EnBW","KfW","EIB","LBBW"]
          },
          {
            id: "L3-FINANZ-FONDS-01", title: "Infrastrukturfonds (Geschlossener EE-Fonds)",
            definition: "Geschlossene Fonds kaufen fertige EE-Projekte (Brownfield) oder co-investieren in Entwicklung (Greenfield). Anleger: institutionelle Investoren. Fondstruktur: 10–15 Jahre Laufzeit, 200–500 Mio. € Volumen, 20–30 Projekte. Renditeerwartung: 5–9% IRR netto. Attraktivität: stabile inflationsindexierte Cashflows (EEG), geringe Aktienmarkt-Korrelation, ESG-konform. Manager verdienen: Management Fee (0,8–1,5% committed capital p.a.) + Carried Interest (20% über 6–8% Hurdle Rate).",
            wertschoepfung: "Fondsmanager schafft Wert durch Dealflow-Qualität, Asset Management (O&M-Optimierung, Refinanzierung zu niedrigeren Zinsen) und Exit-Timing (Verkauf an größere Fonds zu Aufpreis). Carried Interest ist extremer Incentiv: Bei 300 Mio. € Fonds und 15% IRR vs. 7% Hurdle Rate = 60 Mio. € Carry für Manager.",
            herausforderungen: "EE-Asset-Markt: Kaufpreismultiplen gestiegen (EV/EBITDA von 10x auf 15–20x). Gute Deals werden knapper. Zinsanstieg 2022–2024 senkte IRR-Erwartungen; einige Fonds revidieren Renditeversprechen. ESG-Washing-Risiko: nicht alle 'grünen' Fonds erfüllen EU-Taxonomie.",
            ausblick: "Kapitalbedarf: >1.000 Mrd. € bis 2030 in Europa. Infrastrukturfonds unverzichtbar. Neue Asset-Klassen: Offshore-Wind, BESS, H2-Infrastruktur, EV-Ladeinfrastruktur. Impact Investing und Blended Finance für schwierigere Märkte (Emerging Markets, Frontier H2).",
            erloesmodell: "Management Fee (% AuM p.a.) + Carried Interest (% über Hurdle Rate)",
            regulierung: "AIFMD, KAGB, EU-Taxonomieverordnung, SFDR (Art. 8 / Art. 9)",
            kundensegment: "Institutionelle Investoren (Pensionsfonds, Versicherungen, SWFs, Family Offices)",
            differenzierung: "Track Record, Dealflow-Qualität, Asset-Management-Kompetenz, ESG-Rating",
            status: "aktiv",
            radar: { regulierung:3, skalierbarkeit:4, marktrisiko:1, digitalisierung:2, wettbewerb:3, nachhaltigkeit:5 },
            erloesTyp: "Fee-based", akteure: ["Aquila Capital","Copenhagen Infrastructure Partners","DWS","Blackrock","KGAL"]
          }
        ]
      }
    ]
  },

  // ══════════════════════════════════════════════════════════
  // L1: EMOBILITY & LADEINFRASTRUKTUR
  // ══════════════════════════════════════════════════════════
  {
    id: "L1-EMOB", title: "eMobility & Ladeinfrastruktur", icon: "🚗", color: "#8B5CF6",
    description: "Wachstumsmarkt mit enormem Potenzial – CPOs, eMSPs und V2G als neue Wertschöpfungsstufen der Energiewirtschaft.",
    capabilities: [
      {
        id: "L2-EMOB-CPO", title: "Charge Point Operator & eMSP",
        description: "Betrieb öffentlicher Ladeinfrastruktur und Mobilitätsdienstleistungen für EV-Fahrer.",
        actors: ["EnBW mobility+","Ionity","Allego","EWE Go","E.ON Drive","Volkswagen/Elli"],
        items: [
          {
            id: "L3-EMOB-CPO-01", title: "Öffentliches Ladenetz (HPC & AC)",
            definition: "CPOs bauen und betreiben öffentliche Ladepunkte. EnBW mobility+ führt mit >6.000 Ladepunkten in Deutschland (2024). Erlösquellen: (1) Direktladung: 45–80 ct/kWh. (2) Roaming: eMSP-Zahler laden via OCPI, CPO erhält Nettobetrag. (3) B2B-Verträge: Flotten, Hotels, Parkhäuser. Capex HPC 150 kW: 30.000–60.000 € + Netzanschluss. Auslastung 2024 Durchschnitt: 6–12% – weit von Breakeven. EU AFID: alle 60 km HPC auf TEN-T-Kernnetz ab 2025 Pflicht.",
            wertschoepfung: "Breakeven ab ~20% Auslastung. Strategischer Wert: Netzaufbau für zukünftige EV-Adoption (first-mover wins Standorte). Daten: Lademuster als wertvolle Mobilitätsdaten. Roaming-Einnahmen als passiver Stream ohne Betriebsaufwand. OEM-Kooperationen (Ionity = BMW/Mercedes/VW/Hyundai/Ford) sichern Kapital und Fahrzeugflotte.",
            herausforderungen: "Auslastung ist das Kernproblem – EV-Markt wächst, aber Ladenetz wächst schneller (Hühner-Ei). Netzanschlusskosten können >50% des Gesamtinvestments ausmachen. Eichrecht-Konformität (MessEG) komplex und teuer. Vandalismuskosten und Verfügbarkeit (Uptime-Ziel >97%) herausfordernd.",
            ausblick: "Breakeven erreichbar 2027–2030 bei linearem EV-Wachstum. Konsolidierung: 200+ CPOs heute → 20–30 relevant 2030. V2G als transformativer Zusatzerlös: bei ausreichend V2G-fähigen EV kann jeder Standort als Regelenergie-Asset dienen.",
            erloesmodell: "Ladegebühr (ct/kWh) + Roaming-Einnahmen + B2B-Pauschalen",
            regulierung: "AFID (EU-VO 2023/1804), LSV, EnWG, MessEG (Eichrecht)",
            kundensegment: "B2C EV-Fahrer, B2B Flotten",
            differenzierung: "Netzabdeckung, Ladeleistung (HPC 150–350 kW), Uptime-Zuverlässigkeit, App-UX",
            status: "aktiv",
            radar: { regulierung:3, skalierbarkeit:3, marktrisiko:2, digitalisierung:4, wettbewerb:4, nachhaltigkeit:4 },
            erloesTyp: "Merchant", akteure: ["EnBW mobility+","Ionity","EWE Go","Allego","Vattenfall InCharge"]
          },
          {
            id: "L3-EMOB-V2G-01", title: "Vehicle-to-Grid (V2G) Aggregation",
            definition: "V2G nutzt EV-Batterien bidirektional: Fahrzeuge geben bei Netzüberlastung Strom zurück ins Netz. V2G-fähige Fahrzeuge (Nissan Leaf, Hyundai Ioniq 5/6, VW ID-Serie mit V2G-Update) werden von Aggregatoren (Volkswagen/Elli, Jedlix) zu virtuellem Regelenergie-Asset gebündelt. Revenue-Share: 50–70% ÜNB-Erlöse an Fahrzeughalter, 30–50% an Aggregator. EU EMD Art. 20: V2G-Pflicht für neue Wallboxen ab 2027. Kapazitätspotenzial: 10 Mio. EV × 30 kWh V2G = 300 GWh.",
            wertschoepfung: "Aggregator verdient Revenue-Share ohne eigene Asset-Investition – reine Software-/Daten-Wertschöpfung. EV-Batterie (~60 kWh) hat 5× höhere Kapazität als Heimspeicher – enormes Flexibilitätspotenzial. EV-Halter erhält passives Einkommen für Batteriekapazität, die ohnehin vorhanden ist.",
            herausforderungen: "Batteriedegradation durch bidirektionales Laden noch nicht vollständig gelöst. OEM-Gatekeeper: VW, BMW kontrollieren Fahrzeug-API – Aggregatoren abhängig von OEM-Kooperation. Regulierung hinkt Technologie hinterher. Wenige V2G-fähige Fahrzeugmodelle verfügbar (2024).",
            ausblick: "V2G könnte 2030–2035 zu größter Flexibilitätsquelle werden: 10 Mio. EV × 30 kWh = 300 GWh – das 6-fache aller deutschen BESS (2024). EU EMD V2G-Pflicht ab 2027 für neue Wallboxen ist Game Changer. OEMs werden V2G als Revenue-Sharing-Feature vermarkten.",
            erloesmodell: "Revenue-Share Regelenergie/Arbitrage mit EV-Haltern",
            regulierung: "EnWG §14a, EU EMD Art. 20 (V2G-Pflicht ab 2027), SOGL Präqualifikation",
            kundensegment: "B2C EV-Halter; B2B Flottenbetreiber",
            differenzierung: "OEM-Partnerschaften (VW, Hyundai), Aggregationsvolumen, Regelenergie-Präqualifikation",
            status: "emerging",
            radar: { regulierung:2, skalierbarkeit:5, marktrisiko:2, digitalisierung:5, wettbewerb:2, nachhaltigkeit:5 },
            erloesTyp: "Fee-based", akteure: ["Volkswagen/Elli","Jedlix","E.ON Drive","Nissan x Nuvve","Hyundai"]
          }
        ]
      }
    ]
  },

  // ══════════════════════════════════════════════════════════
  // L1: MESSUNG, DATEN & DIGITALE SERVICES
  // ══════════════════════════════════════════════════════════
  {
    id: "L1-DIGITAL", title: "Messung, Daten & Digitale Services", icon: "📡", color: "#F97316",
    description: "Software- und datengetriebene Geschäftsmodelle – vom Smart Meter Gateway bis zur CSRD-Reporting-Plattform.",
    capabilities: [
      {
        id: "L2-DIGITAL-PLATTFORM", title: "Energie-Plattformservices & Contracting",
        description: "Software-Plattformen und investmentbasierte Modelle für Prosumer und Industrie.",
        actors: ["gridX","Thermondo","Tado","Viessmann One","Siemens Smart Infrastructure"],
        items: [
          {
            id: "L3-DIGITAL-PLATTFORM-01", title: "HEMS / EMS-Plattform (B2B2C)",
            definition: "gridX (München, 2017) verkauft ein Energy Management System: (1) Hardware-Gateway (gridBox: kommuniziert via Modbus, SunSpec, OCPP, EEBUS mit PV-Wechselrichter, Batterie, Wärmepumpe, EV-Lader). (2) Cloud-Plattform für Optimierungsalgorithmen. B2B2C: Stadtwerke, Installateure, OEMs zahlen SaaS-Lizenz; Endverbraucher nutzen das System. Erlösstruktur: Hardware-Marge (~40%) + monatliche SaaS-Lizenz (15–50 €/Gerät/Monat).",
            wertschoepfung: "Plattform-Netzwerkeffekte: Jeder neue Hersteller-Protokoll-Support erhöht den Wert für alle Nutzer. API-Ökosystem: >200 Integrationen (HEMS, MSB, VNB §14a, eMSP). VPP-Aggregation als Zusatzerlös für Betreiber. Switching-Kosten nach Installation hoch.",
            herausforderungen: "Protokoll-Fragmentierung: 50+ Standards in der Gebäudeautomation. §14a-Implementierung ist Chance und Herausforderung. DSGVO schränkt Nutzung hochauflösender Daten ein. Hardware-Marge sinkt durch Commodity-Wettbewerb.",
            ausblick: "HEMS wird Pflicht-Infrastruktur für §14a-Compliance und dynamische Tarife. gridX positioniert sich als 'Betriebssystem der Energiewende'. Konvergenz mit Smart-Home-Plattformen (Apple HomeKit, Matter) als Herausforderung.",
            erloesmodell: "Hardware-Marge + SaaS-Abo (€/Gerät/Monat) + API-Zugang",
            regulierung: "EnWG §14a, MsbG, BSI TR-03109, DSGVO",
            kundensegment: "B2B2C: Stadtwerke, Installateure → Prosumer-Endkunden",
            differenzierung: "Integrationsbreite (200+ Hersteller), API-Offenheit, VPP-Anbindung, §14a-Readiness",
            status: "aktiv",
            radar: { regulierung:1, skalierbarkeit:5, marktrisiko:1, digitalisierung:5, wettbewerb:4, nachhaltigkeit:4 },
            erloesTyp: "Subscription", akteure: ["gridX","Loxone","SMA","Solarwatt","Viessmann"]
          },
          {
            id: "L3-DIGITAL-PLATTFORM-02", title: "Wärmepumpen-Contracting (as-a-Service)",
            definition: "Thermondo (2012, Berlin) bietet Wärmepumpen auf Mietbasis an: keine Anschaffungskosten (WP: 15.000–35.000 €), stattdessen monatliche Rate (150–350 €/Monat inkl. Wartung). Thermondo trägt Investitions-, Technologie- und Wartungsrisiko. Refinanzierung über 15–20 Jahre Raten. BEG-Förderung (35–50%) wird im Kundenauftrag beantragt. Installationsnetzwerk: >1.500 zertifizierte Partnerinstallateure bundesweit.",
            wertschoepfung: "Finanzierung ist Kernwert: Kunden ohne Eigenkapital können Wärmewende vollziehen. Thermondo verdient Marge zwischen Barwert aller Raten und (Anschaffungs- + Wartungskosten). GEG Heizungsgesetz: Pflicht zur Umrüstung bei Heizungstausch ab 2026 (65% EE-Anteil) treibt Nachfrage. BEG-Förderoptimierung als Kompetenz.",
            herausforderungen: "Fachkräftemangel bei Heizungsinstallateuren ist Wachstumshürde #1. Technologierisiko: WP-Marktpreis fällt – Mietrate muss wettbewerbsfähig bleiben. Finanzierung über 15+ Jahre erfordert solide Bilanz oder Verbriefung der Forderungsportfolien.",
            ausblick: "GEG + WPG treiben Millionen Heizungstausche bis 2030. Markt für Wärme-Contracting könnte >10 Mrd. €/Jahr in Deutschland erreichen. Kombination mit Energie-Liefervertrag (Strom für WP) als Full-Service-Paket. Digitale Optimierung: automatische BEG-Antragstellung, Smart-Grid-Integration.",
            erloesmodell: "Monatliche Mietrate + Wartungsvertrag + optional Energielieferung",
            regulierung: "BGB (Mietrecht), GEG (Heizgesetz, 65% EE ab 2026), BEG-Förderung, WPG",
            kundensegment: "B2C Eigenheimbesitzer (Heizungstausch-Pflicht GEG)",
            differenzierung: "Kein Eigenkapital nötig, BEG-Optimierung, Full-Service, Installationsnetzwerk",
            status: "aktiv",
            radar: { regulierung:1, skalierbarkeit:3, marktrisiko:2, digitalisierung:3, wettbewerb:3, nachhaltigkeit:5 },
            erloesTyp: "Subscription", akteure: ["Thermondo","Viessmann","Vaillant","ista"]
          },
          {
            id: "L3-DIGITAL-BERATUNG-01", title: "ESG-Datenplattform & CSRD-Reporting",
            definition: "CSRD (Corporate Sustainability Reporting Directive): Berichtspflicht nach ESRS-Standards für >500 MA ab 2024, >250 MA ab 2025. ESRS E1 (Klimawandel): Scope 1, Scope 2 (marktbasiert + standortbasiert), Scope 3 (Lieferkette). Softwareplattformen (Engie Impact, Schneider EcoStruxure, Sphera, measurabl) aggregieren Energiedaten aus SAP/Oracle, IoT-Sensoren, Zählern und berechnen CO₂-Fußabdrücke nach GHG Protocol. Output: extern auditierbare CSRD-konforme Berichte. SaaS: 30.000–300.000 €/Jahr je Unternehmensgröße.",
            wertschoepfung: "Regulatory Push = erzwungene Nachfrage ohne freiwillige Kaufentscheidung → sehr hohe Zahlungsbereitschaft. Switching-Kosten: historische Daten in Plattform migriert, Wechsel teuer. Erweiterungspotenzial: von Reporting zu aktivem Energiemanagement und Beschaffungsoptimierung.",
            herausforderungen: "Markt hochkompetitiv: >100 Anbieter, von Excel-Add-ins bis zu SAP-Suiten. ESRS-Standards wurden spät finalisiert – Anbieter nachrüsten laufend. Abgrenzung zu SAP Sustainability Footprint Management als etabliertem Player schwierig.",
            ausblick: "CSRD-Ausweitung auf alle Unternehmen >10 MA langfristig möglich. AI-gestützte Rechnungsanalyse automatisiert Datenerfassung. EU-Datenraum Energie (Gaia-X) schafft standardisierten Datenaustausch. 24/7 CFE-Matching als neuer Scope-2-Standard treibt Plattform-Nachfrage.",
            erloesmodell: "SaaS-Jahresabo (30.000–300.000 €) + Implementierungsdienstleistung",
            regulierung: "CSRD, ESRS E1 (Klimawandel), EU-Taxonomieverordnung, GHG Protocol",
            kundensegment: "B2B Unternehmen mit CSRD-Berichtspflicht (>250 MA ab 2025)",
            differenzierung: "CSRD-Konformität, Scope-3-Datentiefe, ERP-Konnektoren, Auditierbarkeit",
            status: "aktiv",
            radar: { regulierung:4, skalierbarkeit:5, marktrisiko:1, digitalisierung:5, wettbewerb:4, nachhaltigkeit:5 },
            erloesTyp: "Subscription", akteure: ["Engie Impact","Schneider EcoStruxure","Sphera","measurabl","SAP Sustainability"]
          }
        ]
      }
    ]
  },

  // ══════════════════════════════════════════════════════════
  // L1: WÄRME & SEKTORKOPPLUNG
  // ══════════════════════════════════════════════════════════
  {
    id: "L1-WAERME", title: "Wärme & Sektorkopplung", icon: "🔥", color: "#DC2626",
    description: "Der am stärksten transformierende Sektor – Fernwärme, KWK, Power-to-Heat und grüner Wasserstoff unter WPG- und GEG-Druck.",
    capabilities: [
      {
        id: "L2-WAERME-FERN", title: "Fernwärme & KWK",
        description: "Netzgebundene Wärmeversorgung unter Dekarbonisierungspflicht.",
        actors: ["Vattenfall Wärme Berlin","E.ON Wärme","enercity","MVV Energie","Hamburg Wärme"],
        items: [
          {
            id: "L3-WAERME-FERN-01", title: "Fernwärme-Monopol & Dekarbonisierungspflicht",
            definition: "Fernwärme: natürliches Netzmonopol, ~25.000 km Netze in Deutschland, 14% Wärmebedarf gedeckt. Preisgestaltung bisher weitgehend frei (GWB §19-Missbrauchskontrolle). WPG (Wärmeplanungsgesetz 2024): Kommunen >100.000 EW müssen bis 2026, alle bis 2028 Wärmepläne erstellen. GWB §35b (ab 2024): Fernwärmeversorger müssen Dekarbonisierungsfahrplan vorlegen und bis 2030 mindestens 50% EE-Anteil nachweisen.",
            wertschoepfung: "Monopolmarge auf Wärmepreis als historische Hauptquelle. Wert liegt in Netzinfrastruktur (Replacement Value: 1.000–3.000 €/kW) und Wärmedichtegebieten. WPG schafft Planungssicherheit für Investitionen: Wo Fernwärme im Wärmeplan vorgesehen ist, sind Kapitalinvestitionen gesichert.",
            herausforderungen: "Dekarbonisierungspflicht GWB §35b erfordert massive Investitionen in neue Wärmequellen (Großwärmepumpen, Geothermie, Abwärme). Preistransparenz-Pflicht (Fernwärme-Verordnung 2024) erhöht Kundendruck. GEG macht individuelle Wärmepumpen attraktiver – Fernwärme muss preislich mithalten.",
            ausblick: "WPG-Wärmepläne definieren Investitionskorridore bis 2028. Transformationsquellen: Abwärme (Rechenzentren, Industrie), Großwärmepumpen (Flusswasser, Abwasser, Geothermie), grüner Wasserstoff. Vattenfall Berlin als Pionier: 'Kohlefreie Wärme Berlin bis 2030'. Geothermie (München: 100% Geothermie-Fernwärme bis 2040) als Vorbild.",
            erloesmodell: "Wärmepreis (Grundpreis + Arbeitspreis) + CO₂-Aufschlag",
            regulierung: "AVBFernwärmeV, GWB §19/§35b, WPG (2024), KWKG, GEG",
            kundensegment: "B2C/B2B im Fernwärmegebiet (Monopol, keine Wahlfreiheit)",
            differenzierung: "Dekarbonisierungspfad (50% EE bis 2030), Preisstabilität, Netzausdehnung",
            status: "aktiv",
            radar: { regulierung:4, skalierbarkeit:1, marktrisiko:2, digitalisierung:2, wettbewerb:1, nachhaltigkeit:3 },
            erloesTyp: "Merchant", akteure: ["Vattenfall Wärme","E.ON Wärme","enercity","MVV","Hamburg Wärme"]
          }
        ]
      },
      {
        id: "L2-WAERME-PTX", title: "Power-to-X & grüner Wasserstoff",
        description: "Sektorkopplung durch Elektrolyse – strategisch unverzichtbar, heute noch subventionsabhängig.",
        actors: ["Linde","thyssenkrupp nucera","RWE Hydrogen","Enapter","H2 Mobility","Hy2gen"],
        items: [
          {
            id: "L3-WAERME-PTX-01", title: "Grüner Wasserstoff (Elektrolyse PtH2)",
            definition: "Elektrolyseure (PEM: 60–70% Effizienz; Alkalisch: 70–80%) wandeln EE-Strom in Wasserstoff. Bei 70% Wirkungsgrad und 40 €/MWh Strom: H2-Gestehungskosten ~2,7 €/kg. Marktpreis grüner H2 (2024): 6–10 €/kg. Subventionslücke: 3–7 €/kg, gedeckt durch IPCEI Hydrogen, H2Global, Bundeshaushalt. Abnehmer: Stahl (DRI: thyssenkrupp, ArcelorMittal), Ammoniaksynthese (BASF), Raffinerien, H2-LKW (Daimler Truck, Nikola). Volllaststunden: 4.000–8.000 h/a je nach EE-Strategie.",
            wertschoepfung: "Heute: Subventions-Arbitrage – wer günstigste Fördermittel sichert, gewinnt. Langfristig (2030+): Skaleneffekte in Elektrolyse-Produktion (Lernrate ~15%/Verdopplung). Strategischer Systemwert: Elektrolyseur als flexibler Großverbraucher für Demand Response bei negativen Preisen – doppelt nutzbar.",
            herausforderungen: "Keine Wettbewerbsfähigkeit ohne Subventionen heute. Lieferkette noch nicht industrialisiert (Iridium-Knappheit für PEM). Zertifizierungsinfrastruktur (CertifHy, EU Delegated Acts zu RED III Artikel 27) noch im Aufbau. H2-Transportnetz (H2-Kernnetz) erst ab 2028–2032 verfügbar.",
            ausblick: "Kostenparität mit grauem H2 (~1,5–2 €/kg) ca. 2030–2035 bei günstigen EE-Preisen. Import-H2 aus Nordafrika/ME könnte günstiger als Inlandselektrolyse sein – Deutschland als H2-Importeur? H2 für Stahl (DRI), Chemie (Ammoniak), Schwerverkehr als Priorität-Absatzmärkte.",
            erloesmodell: "Wasserstoffverkaufspreis (€/kg) minus Stromkosten minus Capex-Annuität",
            regulierung: "EU RED III (Erneuerbarkeits-Kriterien, Art. 27), IPCEI, H2Global-Ausschreibungen",
            kundensegment: "B2B Stahlindustrie, Chemie, H2-Mobilität (LKW, Bahn, Schiff)",
            differenzierung: "Standort (nahe günstiger EE), Elektrolyseur-Effizienz, CertifHy-Zertifizierung, Netzanschluss",
            status: "emerging",
            radar: { regulierung:3, skalierbarkeit:3, marktrisiko:4, digitalisierung:3, wettbewerb:2, nachhaltigkeit:5 },
            erloesTyp: "Merchant", akteure: ["RWE Hydrogen","Linde","thyssenkrupp nucera","Hy2gen","Air Liquide"]
          }
        ]
      }
    ]
  }

];  // Ende GM_DATA


// ══════════════════════════════════════════════════════════
// AKTEURS-INDEX
// ══════════════════════════════════════════════════════════
const GM_ACTORS_INDEX = (function() {
  const index = {};
  GM_DATA.forEach(domain => {
    domain.capabilities.forEach(cap => {
      cap.items.forEach(item => {
        if (item.akteure) {
          item.akteure.forEach(a => {
            if (!index[a]) index[a] = [];
            index[a].push({ domainId: domain.id, domainTitle: domain.title, domainIcon: domain.icon, domainColor: domain.color, capId: cap.id, capTitle: cap.title, itemId: item.id, itemTitle: item.title });
          });
        }
      });
    });
  });
  return index;
})();

const GM_ERLOESTYPEN = ["Reguliert","Merchant","Fee-based","Subscription"];

// ══════════════════════════════════════════════════════════
// REGULIERUNGS-TIMELINE
// ══════════════════════════════════════════════════════════
const GM_TIMELINE = [
  { year: 2021, events: [
    { id:"TL-2021-01", title:"Redispatch 2.0 in Kraft", desc:"ÜNB-VNB-Koordination für Einspeisemanagement und Redispatch verpflichtend. Alle Anlagen >100 kW müssen fernsteuerbar sein.", domains:["L1-UNB","L1-VNB"], tags:["Netzbetrieb","Regulierung"] },
    { id:"TL-2021-02", title:"EEG 2021: 65% EE bis 2030", desc:"Direktvermarktungspflicht ab 100 kW. Neue Ausschreibungsregeln für Wind und Solar.", domains:["L1-ERZ","L1-AGG"], tags:["EEG","Markt"] }
  ]},
  { year: 2022, events: [
    { id:"TL-2022-01", title:"EU ETS Phase 4 verschärft", desc:"Linear Reduction Factor 2,2% p.a. Kostenlose Zuteilung für Stromerzeuger entfällt vollständig. CO₂-Preise >80 €/t.", domains:["L1-HANDEL"], tags:["CO₂","Emissionshandel"] },
    { id:"TL-2022-02", title:"LNG-Terminals: Notfallbeschleunigung", desc:"Nach Russland-Gaslieferstopp: FSRU-Terminals in Brunsbüttel, Wilhelmshaven, Lubmin im Schnellverfahren (LNG-BeschlG) genehmigt.", domains:["L1-GAS"], tags:["Gasversorgung","Versorgungssicherheit"] },
    { id:"TL-2022-03", title:"WindBG: 2%-Flächenziel", desc:"Windenergieflächenbedarfsgesetz verpflichtet Bundesländer, 2% Landesfläche für Windenergie auszuweisen bis 2032.", domains:["L1-ERZ","L1-PROJ"], tags:["Wind","Genehmigung"] }
  ]},
  { year: 2023, events: [
    { id:"TL-2023-01", title:"EEG 2023: 80% EE bis 2030", desc:"Solar-Ausbauziel 215 GW, Wind onshore 115 GW, Offshore 30 GW. Agri-PV und Floating-PV als neue Kategorien.", domains:["L1-ERZ"], tags:["EEG","Solar","Wind"] },
    { id:"TL-2023-02", title:"MsbG-Reform: Rollout-Beschleunigung", desc:"Rollout-Pflicht für iMSys: >6.000 kWh/a ab 2025. BSI-Zertifizierungsprozess vereinfacht. MSB-Entgelte neu geregelt.", domains:["L1-VNB","L1-DIGITAL"], tags:["Smart Meter","MSB"] },
    { id:"TL-2023-03", title:"EU AFID: Ladeinfrastruktur-Pflichten", desc:"Mindest-Ladekapazität alle 60 km auf TEN-T-Kernnetz ab 2025. HPC-Pflicht (150 kW) ab 2025.", domains:["L1-EMOB"], tags:["eMobility","Ladeinfrastruktur"] },
    { id:"TL-2023-04", title:"CSRD tritt in Kraft", desc:"Corporate Sustainability Reporting Directive: Berichtspflicht für >500 MA ab 2024, >250 MA ab 2025. Treibt ESG-Datenplattform-Markt.", domains:["L1-DIGITAL"], tags:["ESG","Reporting"] },
    { id:"TL-2023-05", title:"Wärmeplanungsgesetz (WPG) beschlossen", desc:"Kommunen >100.000 EW müssen bis 2026, alle bis 2028 kommunale Wärmepläne erstellen.", domains:["L1-WAERME"], tags:["Wärme","Kommunal"] }
  ]},
  { year: 2024, events: [
    { id:"TL-2024-01", title:"§14a EnWG: Steuerbare Verbrauchseinrichtungen", desc:"DSOs dürfen WP, EV-Lader, Speicher bei Netzengpässen auf 4,2 kW dimmen. 20% Netzentgeltnachlass für Kunden.", domains:["L1-VNB","L1-DIGITAL"], tags:["DSO","Flexibilität"] },
    { id:"TL-2024-02", title:"H2-Kernnetz genehmigt (BNetzA)", desc:"9.700 km Wasserstoff-Kernnetz genehmigt. Amortisationskontomodell als Finanzierungsrahmen.", domains:["L1-GAS"], tags:["Wasserstoff","Infrastruktur"] },
    { id:"TL-2024-03", title:"EU Green Bond Standard (EuGB) in Kraft", desc:"Einheitlicher Standard mit Taxonomie-Konformitätsprüfung und obligatorischem Impact Reporting.", domains:["L1-FINANZ"], tags:["Green Finance","Taxonomie"] },
    { id:"TL-2024-04", title:"MaBiS-Reform BK6-24-174", desc:"Neue Marktkommunikationsregeln für Bilanzkreismanagement. API-basierter Datenaustausch ersetzt EDIFACT schrittweise bis 2027.", domains:["L1-UNB","L1-VERTRIEB"], tags:["MaBiS","Marktkommunikation"] }
  ]},
  { year: 2025, events: [
    { id:"TL-2025-01", title:"Smart Meter Rollout-Pflicht (>6.000 kWh/a)", desc:"Alle Verbrauchsstellen >6.000 kWh/a müssen mit iMSys ausgestattet sein. Grundlage für dynamische Tarife.", domains:["L1-VNB","L1-DIGITAL"], tags:["Smart Meter","Rollout"] },
    { id:"TL-2025-02", title:"EnWG §41b: Dynamische Tarife Pflicht", desc:"Alle Versorger >200.000 Kunden müssen stündliche EPEX-basierte Tarife anbieten. Tibber/aWATTar-Modell wird Massenmarkt.", domains:["L1-VERTRIEB"], tags:["Dynamische Tarife","Lieferant"] },
    { id:"TL-2025-03", title:"AFID HPC-Pflicht TEN-T Kernnetz", desc:"Mindestens 150 kW Ladekapazität alle 60 km auf TEN-T-Kernnetz vollständig umgesetzt.", domains:["L1-EMOB"], tags:["eMobility","HPC"] },
    { id:"TL-2025-04", title:"CSRD: Unternehmen >250 Mitarbeiter", desc:"Erweiterung auf >250 MA. ESRS E1 Klimastandard verpflichtend. Starker Boost für ESG-Datenplattformen.", domains:["L1-DIGITAL"], tags:["CSRD","ESG"] }
  ]},
  { year: 2026, events: [
    { id:"TL-2026-01", title:"WPG: Kommunale Wärmepläne >100.000 EW (Frist)", desc:"Alle Kommunen >100.000 EW müssen Wärmepläne vorgelegt haben. Entscheidet über Fernwärme-Ausbaukorridore.", domains:["L1-WAERME"], tags:["Wärme","Kommunal"] },
    { id:"TL-2026-02", title:"EU EMD: Neues Elektrizitätsmarkt-Design", desc:"Terminkontrakte für EE-Erzeuger, stärkere Nachfrageflexibilität, V2G-Pflicht für neue Wallboxen ab 2027 verankert.", domains:["L1-AGG","L1-EMOB","L1-VERTRIEB"], tags:["Marktdesign","Flexibilität"] },
    { id:"TL-2026-03", title:"GEG: 65% EE-Pflicht bei Heizungstausch", desc:"Beim Heizungsaustausch muss die neue Anlage zu mindestens 65% mit EE betrieben werden. Wärmepumpen-Boom.", domains:["L1-WAERME","L1-DIGITAL"], tags:["GEG","Wärmepumpe"] }
  ]},
  { year: 2027, events: [
    { id:"TL-2027-01", title:"V2G-Pflicht: Neue Wallboxen bidirektional", desc:"EU EMD Art. 20: Alle neu installierten privaten und gewerblichen Wallboxen müssen V2G-fähig sein.", domains:["L1-EMOB","L1-AGG"], tags:["V2G","eMobility"] },
    { id:"TL-2027-02", title:"MaBiS 2.0: API-Vollbetrieb", desc:"Vollständige Umstellung des Bilanzkreismanagements auf API-basierte Echtzeitkommunikation. EDIFACT abgelöst.", domains:["L1-UNB","L1-VERTRIEB"], tags:["MaBiS","IT"] }
  ]},
  { year: 2028, events: [
    { id:"TL-2028-01", title:"WPG: Alle Kommunen Wärmepläne (Frist)", desc:"Alle deutschen Kommunen müssen Wärmepläne vorliegen haben. Umsetzungsphase beginnt.", domains:["L1-WAERME"], tags:["Wärme","WPG"] },
    { id:"TL-2028-02", title:"SuedLink & SuedOstLink: Inbetriebnahme", desc:"Beide HGÜ-Corridore (SuedLink 5 Mrd. €, SuedOstLink 3 Mrd. €) sollen bis 2028 operativ sein. Löst Nord-Süd-Engpass.", domains:["L1-UNB"], tags:["Netzausbau","HGÜ"] },
    { id:"TL-2028-03", title:"EEG-Auslauf erste Altanlagen (Repowering-Welle)", desc:"Erste Windanlagen aus 2000–2005 laufen aus 20-j. EEG-Förderung aus. Repowering oder Merchant-Betrieb.", domains:["L1-ERZ","L1-PROJ"], tags:["EEG-Auslauf","Repowering"] }
  ]},
  { year: 2030, events: [
    { id:"TL-2030-01", title:"80% Erneuerbare im Strommix (Ziel)", desc:"Nationales Ziel: 215 GW Solar, 115 GW Wind onshore, 30 GW Wind offshore.", domains:["L1-ERZ","L1-PROJ"], tags:["Energiewende","Ziel"] },
    { id:"TL-2030-02", title:"CBAM: Vollständige Implementierung", desc:"Carbon Border Adjustment Mechanism vollständig in Kraft. Emissionsintensive Importe zahlen CO₂-Preis.", domains:["L1-HANDEL"], tags:["CBAM","CO₂"] },
    { id:"TL-2030-03", title:"H2-Kernnetz: Erste Korridore operativ", desc:"Nordsee-Ruhrgebiet H2-Korridor operativ. H2-Netzentgelte greifen. Europäische EHB-Verknüpfung in Aufbau.", domains:["L1-GAS","L1-WAERME"], tags:["Wasserstoff","H2-Netz"] }
  ]},
  { year: 2032, events: [
    { id:"TL-2032-01", title:"H2-Kernnetz vollständig operativ", desc:"9.700 km H2-Kernnetz vollständig in Betrieb. Verknüpfung mit European Hydrogen Backbone.", domains:["L1-GAS","L1-WAERME","L1-PROJ"], tags:["Wasserstoff","H2-Backbone"] },
    { id:"TL-2032-02", title:"WindBG: 2%-Flächenziel aller Länder (Frist)", desc:"Alle Bundesländer müssen 2% Landesfläche für Windenergie ausgewiesen haben.", domains:["L1-ERZ","L1-PROJ"], tags:["Wind","Fläche"] }
  ]}
];
