# ⚡ Energiewirtschaft Geschäftsmodell-Wiki — Projektordner

> **Dies ist der vollständige Projektordner.** Er enthält die lauffähige Anwendung, die gesamte Projektdokumentation und ein Archiv älterer Versionen. Gedacht zur Ablage in Claude Cowork oder einem vergleichbaren Projekt-Workspace, damit jede neue Session sofort vollen Kontext hat.

---

## 🗂 Ordnerstruktur

```
Energiewirtschaft-GM-Wiki/
├── README.md                          ← diese Datei (Einstiegspunkt)
│
├── app/                                ← die lauffähige Anwendung (v2.3)
│   ├── index.html
│   ├── style.css
│   ├── app.js
│   └── data.js
│
├── dokumentation/                      ← Projektkontext & Konzepte
│   ├── 00_PROJEKTKONTEXT.md            ← Start hier für vollen Kontext
│   ├── 01_PERSONAS.md
│   ├── 02_ENTWICKLUNGSHISTORIE.md
│   ├── 03_DATENMODELL_TECHNIK.md
│   ├── 04_BUSINESS_MODEL_CANVAS.md
│   └── 05_QUELLEN_KONZEPT.md
│
└── archiv-aeltere-versionen/           ← frühere ZIP-Stände (v1.1–v1.9)
```

---

## 🚀 Schnellstart

**Anwendung öffnen:** `app/index.html` im Browser öffnen — läuft komplett lokal, kein Server nötig.

**Mit Claude weiterarbeiten:** Neue Session/Projekt eröffnen mit:
> „Lies `dokumentation/00_PROJEKTKONTEXT.md`, dann arbeiten wir weiter an [Thema]."

Claude hat damit sofort: aktuellen inhaltlichen Stand, technische Architektur, Designkonventionen, Personas und offene Roadmap-Punkte.

---

## 📊 Aktueller Stand (v2.4, Juni 2026)

| Kennzahl | Wert |
|---|---|
| Wertschöpfungsstufen (Domänen) | 19 |
| Capability-Gruppen | 32 |
| Geschäftsmodelle (Steckbriefe) | 71 |
| Vernetzte Akteure | 222 |
| Glossarbegriffe | ~106 |
| Praxisbeispiele (Deep Dive) | 69 (alle unternehmensförmigen Steckbriefe) |
| Belegte Quellen (Pilot) | 12 (Quellenregister + Inline-Marker + Quellen-Seite) |

Features: Steckbriefe mit Tiefenanalyse (Wertschöpfung/Herausforderungen/Ausblick), vollständiger Business Model Canvas pro Steckbrief (alle 9 Bausteine für 69/71 unternehmensförmige Steckbriefe explizit befüllt, Toggle „Fließtext | Canvas", mit Typ-Markierung für Nicht-Unternehmen), optionales Feld „Angreifbarkeit/Disruptionsrisiko" (Pilot, 5 Steckbriefe), Feld „Praxisbeispiel/Deep Dive" mit einem konkreten Mechanik-Beispiel anhand eines realen Akteurs für alle 69 unternehmensförmigen Steckbriefe, Glossar mit ~106 Fachbegriffen/Abkürzungen (eigene Seite + klickbare Inline-Hervorhebung mit Definitions-Popover im Fließtext), Radar-Charts, Vergleichsmatrix, Akteursnetz, Regulierungs-Timeline, Methodik-/Onboarding-Seite, Volltext-Suche, Markdown-/CSV-Export, Print-Layout.

**Neu in v2.4 (Quellen-Pilot):** Neues Feld der Belegbarkeit — ein zentrales **Quellenregister** (`GM_QUELLEN` in `data.js`, analog zum Glossar) plus klickbare **Inline-Marker** `[[Q:id]]` an Schlüsselzahlen im Fließtext (hochgestelltes „Q", Klick öffnet Popover mit Herausgeber, **Stand-Datum** und Link) und eine eigene **Quellen-Seite** (Tab, such-/filterbar nach Typ). Pilot mit 12 belegten Primär-/Behördenquellen, bewusst an den in v2.3 korrigierten Kennzahlen (BNetzA-EK-Zins, SuedLink, Shell/Next Kraftwerke, CSRD-Omnibus, AFIR, §41a, §42b, Mieterstromzuschlag, Redispatch, Tibber, Enpal, §51 EEG). Schließt Roadmap-Punkt 4. Reused die bestehende Glossar-Mechanik; Konzept/Pflege in `dokumentation/05_QUELLEN_KONZEPT.md`.

**Neu in v2.3 (Faktenkorrektur-Release):** Vollständige fachlich-inhaltliche Prüfung aller 71 Steckbriefe, des Glossars und der Timeline. Korrigiert wurden u.a.: **Next Kraftwerke** gehört **Shell** (nicht RWE — durchgängig falsch); **SuedLink**-Vorhabenträger sind **TenneT/TransnetBW** (nicht Amprion), Kosten ~10 Mrd. €; ARegV-**Eigenkapitalzinssatz** 4. Periode korrekt **5,07 % Neu / 3,51 % Alt**; **EWS Schönau** ~224.000 Kunden (interner Widerspruch behoben); **RWE/innogy** als B2C-Vollversorger ersetzt (innogy-Privatkunden → E.ON); **CSRD** um EU-Omnibus-Verschiebung (Welle 2 → frühestens GJ 2027) aktualisiert; **GGV §42b EnWG** seit Mai 2024 (Solarpaket I, nicht 2023); **§41a** statt §41b für dynamische Tarife, Schwelle >100.000 Kunden (ab 2025 alle Lieferanten); **V2G**-Pflicht ab 2027 korrekt der **AFIR** zugeordnet (keine Nutzungspflicht); **H2-Kernnetz** ~9.040 km genehmigt; **Redispatch**-Kosten 2023 ~3,1 Mrd. € (2022 ~4,2 Mrd.); **Tibber** 5,99 €/Monat; **Enpal** ~100.000 Kunden/300.000 Einheiten; **Mieterstromzuschlag** ~1,6–2,6 ct/kWh; **discovergy → inexogy**. Details siehe `02_ENTWICKLUNGSHISTORIE.md` (Session 15). Keine strukturellen oder funktionalen Änderungen an der App.

**Neu in v2.2:** Feld „Praxisbeispiel" (Deep Dive) von 8 Pilot-Steckbriefen auf alle 69 unternehmensförmigen Steckbriefe ausgerollt. Jeder Eintrag zeigt anhand eines realen, im Steckbrief bereits genannten Akteurs konkret durchgerechnet, wie das Geschäftsmodell mechanisch funktioniert (z.B. welche Zahlen wo herkommen, welcher Stellhebel den Erlös treibt) — bewusst keine Unternehmenschronologie oder Wikipedia-Zusammenfassung, sondern eine Beschreibung der Funktionsweise anhand von Beispielen (Korrektur aus v2.1, siehe `02_ENTWICKLUNGSHISTORIE.md`, Session 13/14).

**Neu in v2.1:** Neues Feld „Praxisbeispiel" (Deep Dive) — an 8 bewusst diversen Steckbriefen (Tibber, Next Kraftwerke, WEMAG-Batteriespeicher, Stromnetz Hamburg, Check24, Ionity, EWS Schönau, 50Hertz) ergänzt um ein recherchiertes, faktengeprüftes Fallbeispiel mit echten Zahlen und einer praktischen Lehre. Eigenes, optisch abgehobenes Lehrbuch-Sidebar-Design ("Deep Dive"-Badge).

**Neu in v2.0:** Die drei BMC-Lückenfelder (Kanäle, Kundenbeziehungen, Kostenstruktur) sind jetzt für alle 69 unternehmensförmigen Steckbriefe redaktionell befüllt statt heuristisch geraten. Zusätzlich: Glossar-Feature (eigene Seite, durchsuchbar/filterbar nach 8 Themenkategorien, plus klickbare Inline-Begriffe im gesamten Fließtext mit Definitions-Popover). Außerdem zwei sachliche Korrekturen nach kritischem Nutzerfeedback: ista war fälschlich als Akteur bei Wärmepumpen-Contracting und Energieeinkaufs-Optimierung gelistet (korrigiert) und fehlte beim tatsächlich richtigen Modell (Messstellenbetrieb iMSB/gMSB), wo es jetzt ergänzt ist.

**Neu in v1.9:** Typ-Markierung `istUnternehmen` ergänzt — Steckbriefe, die Institutionen statt Unternehmen beschreiben (BNetzA, ENTSO-E), zeigen statt des Canvas-Buttons den Hinweis „📋 Canvas n/a", statt den BMC irreführend zu befüllen.

**Neu in v1.8:** Business Model Canvas als zuschaltbare Ansicht je Steckbrief — automatisch aus bestehenden Feldern abgeleitet, keine separate Pflege. Bewusst als Pilot gekennzeichnet: Kanäle/Kundenbeziehungen/Kostenstruktur sind nicht für jeden Steckbrief belegbar (offene Datenlücken werden angezeigt), und der Baustein „Schlüsselpartner" ist eine Näherung. Details und Einschätzung in `dokumentation/04_BUSINESS_MODEL_CANVAS.md`, Abschnitt 6.

**Neu in v1.7:** Betreiber- & Eigentumsmodelle für Verteilnetzbetreiber (Rekommunalisierung, gemischtwirtschaftliche Modelle, Konzessionsmodelle ohne Eigentum) als eigene Capability-Gruppe; neue Analyse-Persona „B6 — Disruptor/Markteindringling"; Pilotfeld „Angreifbarkeit" für 5 exponierte Geschäftsmodelle (Vollversorger, CPO, Mieterstrom, VPP, Vergleichsplattformen).

---

## 🧭 Wegweiser — wer sollte was lesen?

| Frage | Antwort in |
|---|---|
| Was ist das Projekt überhaupt? | `dokumentation/00_PROJEKTKONTEXT.md` |
| Für wen ist das Wiki gemacht? | `dokumentation/01_PERSONAS.md` |
| Was wurde bereits entschieden/verworfen? | `dokumentation/02_ENTWICKLUNGSHISTORIE.md` |
| Wie ändere ich Inhalte technisch? | `dokumentation/03_DATENMODELL_TECHNIK.md` |
| Was ist der Business-Model-Canvas-Plan? | `dokumentation/04_BUSINESS_MODEL_CANVAS.md` |
| Wie funktioniert das Quellen-Feature? | `dokumentation/05_QUELLEN_KONZEPT.md` |

---

## 🏗 Wichtigste Konventionen (Kurzfassung)

- **Sprache:** Deutsch, fachlich-präzise
- **Architektur:** 4 statische Dateien, kein Server, kein Build, kein localStorage
- **Design:** hell/editorial (DM Serif Display + DM Sans), **kein Dark Mode**
- **Versionierung:** `GM_WIKI_VERSION` in `data.js` hochzählen, ZIPs mit Bindestrich-Versionsnummer
- **Status:** Inhaltlich weitgehend vollständig — Fokus liegt auf Nutzbarkeit & Verteilung, nicht auf weiterem Inhaltsausbau

---

## 🔜 Offene nächste Schritte (siehe auch Projektkontext, Abschnitt 6)

1. **Verteilung an Kollegen** — Hosting-Weg klären (SharePoint als Verteilstelle vs. internes Static-Hosting)
2. ~~Business Model Canvas-Ansicht pro Steckbrief~~ — als Pilot in v1.8 umgesetzt; 3 BMC-Zusatzfelder in v2.0 vollständig nachgepflegt
3. ~~Glossar für Abkürzungen/Fachbegriffe~~ — in v2.0 umgesetzt (Seite + Inline-Popover)
4. ~~Quellenangaben an Schlüsselzahlen ergänzen~~ — Pilot in v2.4 umgesetzt (Quellenregister + Inline-Marker + Quellen-Seite, 12 belegte Schlüsselzahlen; Ausweitung als nächster Schritt)
5. ~~Fallbeispiele/Case Studies pro Geschäftsmodell~~ — Pilot an 8 Steckbriefen in v2.1, Vollrollout auf alle 69 unternehmensförmigen Steckbriefe in v2.2 umgesetzt (siehe `02_ENTWICKLUNGSHISTORIE.md`, Session 13/14)
6. Ggf. Changelog-Mechanismus in der App selbst
