# Projektkontext — Energiewirtschaft Geschäftsmodell-Wiki

> **Zweck dieser Datei:** Vollständiger Projektkontext, damit Claude (oder andere Mitwirkende) in einer neuen Session sofort den Stand, die Ziele und die Arbeitsweise verstehen. Diese Datei gehört in den Projektordner und sollte bei jeder größeren Änderung aktualisiert werden.

---

## 1. Was ist das Projekt?

Das **Energiewirtschaft Geschäftsmodell-Wiki** ist eine lokal lauffähige Single-Page-Webanwendung (HTML/CSS/JS, keine Server-Abhängigkeit), die einen strukturierten, tiefgehenden Überblick über die Geschäftsmodelle der deutschen und europäischen Energiewirtschaft bietet.

Es ist ein **internes Arbeits- und Referenzinstrument für Beratungszwecke** — gedacht für die Energy-Transition-&-Utilities-Praxis, mit Anwendungsfällen von der Pitch-Vorbereitung über Marktüberblicke bis zur Regulierungsrecherche.

**Aktuelle Version:** v1.6 (Juni 2026)

---

## 2. Aktueller inhaltlicher Stand (v1.6)

| Kennzahl | Wert |
|----------|------|
| Wertschöpfungsstufen (L1-Domänen) | 19 |
| Capability-Gruppen (L2) | 31 |
| Geschäftsmodelle (L3-Steckbriefe) | 66 |
| Vernetzte Akteure | 213 |

### Die 19 Domänen

1. ⚡ **Erzeugung & Speicherung** — Konventionell, Erneuerbare, Speicher/BESS, Offshore-Wind
2. 🔌 **Übertragungsnetz (ÜNB/TSO)** — Netzbetrieb, Redispatch 2.0, Bilanzkreismanagement
3. 🏘️ **Verteilnetz (VNB/DSO)** — Klassischer Netzbetrieb, §14a, Messstellenbetrieb
4. 🔵 **Gas & Wasserstoffnetz** — FNB Gas, H2-Kernnetz
5. 📊 **Energiehandel & Portfoliomanagement** — Börse, Prop Trading, Direktvermarktung, Zertifikate/EU ETS
6. 🏠 **Vertrieb & Energielieferung** — Vollversorger, Neolieferanten (Tibber/Ostrom/Fünf Grad/aWATTar), Ökostrom, Stadtwerke
7. 🔋 **Aggregation & Flexibilität** — VPP, Demand Response
8. 🏗️ **Projektentwicklung & EPC** — Develop-to-Sell/Own, EPC, O&M
9. 💰 **Energiefinanzierung & Investoren** — Projektfinanzierung, Green Bonds, Infrastrukturfonds
10. 🚗 **eMobility & Ladeinfrastruktur** — CPO, eMSP, V2G
11. 📡 **Messung, Daten & Digitale Services** — HEMS/EMS, Wärmepumpen-Contracting, ESG/CSRD-Plattformen
12. 🔥 **Wärme & Sektorkopplung** — Fernwärme/KWK, Power-to-X/H2
13. 🔍 **Vergleichsplattformen & digitaler Vertrieb** — Verivox/Check24, Auto-Switch, B2B-Ausschreibung
14. 🧭 **Beratung, Strategie & Management Consulting** — Strategie (McKinsey/BCG), IT/Digital (Capgemini Invent), Regulierungsberatung
15. ⚖️ **Energierecht & Rechtsberatung** — Energierechtskanzleien (BBH), §46-Konzessionsrecht
16. 🛡️ **Versicherung & Risikomanagement** — Anlagenversicherung, Cyber/KRITIS
17. 🏭 **Energiebeschaffung & Contracting (Industrie)** — Procurement, EPC-Contracting, Eigenversorgung
18. ☀️ **Prosumer & dezentrale Energieversorgung** — PV-Eigenverbrauch, Balkonkraftwerk, Mieterstrom §42a, GGV §42b, Enpal/1KOMMA5°, Energy Communities
19. 🏛️ **Energiemärkte & Market Design** — BNetzA, ENTSO-E, Kapazitätsmechanismus, lokale Flexmärkte, H2-Marktdesign

---

## 3. Technische Architektur

Vier-Datei-Architektur, lokal lauffähig (kein Server, keine Build-Pipeline). Liegt im Projektordner unter `app/`:

```
app/
├── index.html    — Struktur, Tabs, View-Container
├── style.css     — Editorial/Refined-Ästhetik, Print-CSS, Methodik-Styles
├── app.js        — Navigation, Rendering, Suche, Matrix, Akteure, Timeline, Methodik, Export
└── data.js       — Alle Inhalte: GM_DATA[], GM_ACTORS_INDEX, GM_TIMELINE, GM_ERLOESTYPEN
```

### Datenmodell (data.js)

```
GM_DATA = [
  {
    id, title, icon, color, description,
    capabilities: [
      {
        id, title, description, actors[],
        items: [
          {
            id, title, definition,
            wertschoepfung,      // 💡 Wertschöpfungslogik
            herausforderungen,   // ⚠ Strategische Herausforderungen
            ausblick,            // → Markttrends & Ausblick
            erloesmodell, regulierung, kundensegment, differenzierung,
            status,              // "aktiv" | "emerging" | "planned"
            radar: { regulierung, skalierbarkeit, marktrisiko,
                     digitalisierung, wettbewerb, nachhaltigkeit },  // je 1–5
            erloesTyp,           // "Reguliert"|"Merchant"|"Fee-based"|"Subscription"
            akteure[]            // verlinkt in Akteurs-Index
          }
        ]
      }
    ]
  }
]
```

### Funktionen / Ansichten (Tabs)

- **Wiki** — L1→L2→L3-Navigation, Steckbriefe mit Radar-Charts
- **Matrix** — Filterbare Vergleichstabelle (nach Erlöstyp + Status)
- **Akteure** — Akteurs-Vernetzung (wer ist wo aktiv)
- **Timeline** — Regulierungs-Timeline 2021–2032
- **Methodik** — Onboarding-/Erklärseite (seit v1.6)
- **Export** — Markdown + CSV-Download, Steckbrief-Kopierfunktion

Zusätzlich: Volltext-Suche über alle Felder, Print-CSS (Strg+P pro Steckbrief).

---

## 4. Designprinzipien & Konventionen

**Architektur**
- Lokale Single-Page-App, vier Dateien, keine Server-/Build-Abhängigkeit
- Kein localStorage/sessionStorage (Inhalte in data.js)
- Versionsnummern in Dateinamen mit Bindestrich (z.B. `gm-wiki-v1.6.zip`), Version intern als `GM_WIKI_VERSION`

**Inhaltliche Konventionen**
- Alle Inhalte auf **Deutsch**
- Jeder Steckbrief: Definition + die drei Tiefenfelder (Wertschöpfung, Herausforderungen, Ausblick) + Meta-Felder
- Zahlen als qualitative Orientierungswerte (mit Disclaimer in Methodik)
- Regulatorische Bezüge konkret (EnWG-Paragraphen, EEG, ARegV, EU-Direktiven)

**Design-Ästhetik**
- Editorial/Refined-Look: DM Serif Display (Headlines) + DM Sans (Body)
- Helle, professionelle Farbgebung (kein Dark Mode — wurde früher explizit verworfen)
- Zurückhaltende Formatierung, viel Weißraum
- Pro Domäne eine Akzentfarbe (im `color`-Feld)

**Auslieferung**
- Immer als ZIP, damit alle vier Dateien gemeinsam heruntergeladen werden können
- Bei jeder Version: ZIP + Vorschau index.html

---

## 5. Entwicklungshistorie (Versionsverlauf)

| Version | Inhalt |
|---------|--------|
| v1.0 | Grundgerüst: 7 Domänen, ~35 GMs, Navigation, Steckbriefe, Suche |
| v1.1 | Inhalt erweitert; Radar-Charts, Vergleichsmatrix, Akteursgraph |
| v1.2 | +Projektentwicklung, +Finanzierung, +eMobility; Regulierungs-Timeline, Export (MD/CSV) |
| v1.3 | Tiefenausbau aller Steckbriefe: Wertschöpfung, Herausforderungen, Ausblick |
| v1.4 | +Vergleichsplattformen, +Beratung, +Energierecht, +Versicherung, +Contracting |
| v1.5 | +Prosumer & dezentrale Versorgung, +Energiemärkte & Market Design |
| v1.6 | Kollegentauglichkeit: Methodik-Seite, Volltext-Suche über alle Felder, Print-CSS |

---

## 6. Offene Punkte / Roadmap

**Kurzfristig (nächste sinnvolle Schritte)**
- **Business Model Canvas-Ansicht** pro Steckbrief (siehe separate Datei `04_BUSINESS_MODEL_CANVAS.md`)
- Quellenangaben an Schlüsselzahlen (z.B. „Quelle: BNetzA Monitoringbericht 2023")
- Changelog-Mechanismus innerhalb der App

**Mittelfristig**
- Hosting-Entscheidung: lokal (ZIP) vs. Team-Asset (GitHub Pages als einfachster Weg)
- Ownership/Pflege klären, wenn das Wiki an Kollegen geht
- Ggf. weitere Nischen-GMs (z.B. Bilanzkreis-Dienstleister, White-Label-Stadtwerk-Plattformen)

**Bewusst offen gelassen**
- Inhaltlich gilt das Wiki als weitgehend vollständig — Fokus sollte jetzt auf Nutzbarkeit/Verteilung liegen, nicht auf mehr Steckbriefen.

---

## 7. Wie weiterarbeiten? (Hinweise für Claude in neuer Session)

1. **Bei Inhalts-Änderungen:** immer `data.js` editieren, Datenmodell-Schema einhalten (alle Felder pro Item ausfüllen, inkl. radar + erloesTyp + akteure).
2. **Nach Änderungen an data.js:** Syntax via Node prüfen (Bracket-Balance, valides Array), Akteurs-Index wird automatisch aufgebaut.
3. **Immer als ZIP ausliefern**, Version hochzählen, `GM_WIKI_VERSION` aktualisieren.
4. **Stil:** Deutsch, editorial, sachlich-fundiert. Keine Übervereinfachung — die Zielgruppe ist fachkundig.
5. **Große data.js:** Bei Schreiben via Shell die 100KB-Argumentgrenze beachten → in Teilen schreiben oder anhängen.
